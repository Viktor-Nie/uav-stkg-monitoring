"""Verify the saved 25-statement refusal check using the Python standard library."""

from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import sys
import unicodedata


KINDS = {'Requirement', 'SafetyRequirement', 'ProcessRequirement'}
DESCRIPTOR = {'signal_id': '', 'template_id': '', 'formula_structure': '', 'parameter_roles': []}
RESPONSE_FIELDS = {'id', 'scope', 'refusal_reason', *DESCRIPTOR}
RESPONSE_NAMES = tuple(f'responses/run_{number:02d}.txt' for number in range(1, 6))
SOURCE_NAME = 'source/V1-simplified.json'
LICENSE_NAME = 'source/LICENSE'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def index(records):
    result = {row['id']: row for row in records}
    require(len(result) == len(records) == 25, 'Expected exactly 25 distinct response identifiers')
    return result


def normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def source_statements(snapshot):
    statements = {}

    def visit(node, kind=None):
        if isinstance(node, list):
            for item in node:
                visit(item, kind)
        elif isinstance(node, dict):
            if kind in KINDS and 'id' in node and 'name' in node:
                issue, title, desc = node['id'], node['name'], node['description']
                if normalized(title) == normalized(desc):
                    text = desc
                elif not desc.strip():
                    text = title
                else:
                    text = f'Title: {title}\nDescription: {desc}'
                require(statements.setdefault(issue, text) == text, f'Conflicting source copies for {issue}')
            for key, value in node.items():
                if key == 'children':
                    for category, children in value.items():
                        visit(children, category)
                else:
                    visit(value, kind)

    visit(snapshot)
    return statements


def read_response(path):
    raw = path.read_text(encoding='utf-8-sig').strip()
    if raw.startswith('```json\n') and raw.endswith('\n```'):
        raw = raw[len('```json\n'):-len('\n```')]
    response = json.loads(raw)
    require(set(response) == {'records'} and isinstance(response['records'], list), f'Invalid response in {path.name}')
    return response


def count_clean(response, reference):
    rows = index(response['records'])
    require(rows.keys() == reference.keys(), 'Response identifiers differ from reference')
    clean = 0
    for item_id, row in rows.items():
        require(set(row) == RESPONSE_FIELDS and isinstance(row['refusal_reason'], str), f'Invalid response fields for {item_id}')
        require(row['scope'] == reference[item_id]['scope'] == 'out_of_scope', f'Non-refusal on {item_id}')
        require(all(row[field] == empty for field, empty in DESCRIPTOR.items()), f'Nonempty descriptor for {item_id}')
        clean += 1
    return clean


def verify(root):
    for name, expected in load(root / 'sha256.json').items():
        member = PurePosixPath(name)
        require(not member.is_absolute() and '..' not in member.parts and '\\' not in name and ':' not in name, 'Unsafe checksum path')
        require(sha256((root / member).read_bytes()).hexdigest() == expected, f'Checksum mismatch for {name}')

    source = load(root / 'source_provenance.json')
    for name in (SOURCE_NAME, LICENSE_NAME):
        require(sha256((root / name).read_bytes()).hexdigest() == source['files'][name]['sha256'], f'Pinned source mismatch for {name}')
    statements = source_statements(load(root / SOURCE_NAME))
    inputs = index(load(root / 'public_request.json')['records'])
    reference = index(load(root / 'scope_reference.json')['records'])
    require(inputs.keys() == reference.keys(), 'Request identifiers differ from reference')
    source_ids = {row['source_requirement_id'] for row in reference.values()}
    require(source_ids == statements.keys(), 'Reference differs from deduplicated source inventory')
    require(len({row['text'] for row in inputs.values()}) == 25, 'Request includes duplicate text')
    for item_id, row in reference.items():
        require(inputs[item_id]['text'] == statements[row['source_requirement_id']], f'Pinned source text mismatch for {item_id}')

    runs = [count_clean(read_response(root / name), reference) for name in RESPONSE_NAMES]
    baseline = {'records': [dict(id=item_id, scope='out_of_scope', refusal_reason='', **DESCRIPTOR) for item_id in inputs]}
    return dict(unique_inputs=len(inputs), source_projects=1, completed_sessions=len(runs),
                item_session_opportunities=len(runs) * len(inputs), clean_refusals_by_session=runs,
                clean_refusals=sum(runs), raw_false_acceptances=0, structurally_admitted_false_acceptances=0,
                missing_or_malformed=0, always_refuse_clean_refusals=count_clean(baseline, reference))


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parent), indent=2))
