# Dronology scope-refusal check

Extract the archive and run `python verify_scope25.py` from the extracted directory.
The verifier checks the source files and statement assembly, the identifiers in each
saved response, and the clean refusal count for each session and for always refusing.
It uses only the Python standard library and runs offline.

The exact public request and response schema are saved alongside the five model
responses. The scope reference contains the archived decisions confirmed by the
study author. Individual reviewer confirmations were reported by the author. Their
original replies and dates were outside the verification record.

The five sessions repeat the same 25 out-of-scope texts from one source project.
This check measures refusal on that set. Positive recognition and timed recovery
require separate evidence. All five saved responses contain zero false proposals,
leaving no cases for the structural gate to intercept.

The source snapshot is redistributed with its upstream MIT license. The companion
is separate from the frozen v35 release.
