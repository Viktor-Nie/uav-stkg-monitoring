# v55完整回放来源覆盖核查

本附件只检查三段既有RflyMAD日志的原始记录与20Hz回放点之间的对应、记录年龄和原始间隔。3段日志、9个原始数据流、3713个回放行、11139个点与数据流对应。不会运行监测器、更新阈值、训练模型或下载数据，也不增加独立飞行或语义样本。

记录年龄=回放时刻减去被选原始消息的timestamp，不是传感器真实测量年龄。100ms为描述刻度，不是新校准安全阈值。原始topic支持范围从首网格点选中行至末网格点选中行，包含其间所有行。两个406用SciPy四元数变换，407沿用其冻结直接变换，避免更换历史适配器。

## 所需外部输入

提供已有materials目录，其中含external_datasets/rflymad/Real-Minimal-406_1、Real-Motor-Extension/406_2及Real-Motor-Raw-Official/Real-Motor.zip。精确文件名、9个整文件SHA/大小及407原始CSV成员SHA在results/source_inputs.json；原始获取指针仍见引用的RflyMAD材料和v35研究包research/real_replay/SOURCE_INPUTS.md。附件不带原始飞行归档、状态数值或新模型输出。

## 从原始输入完整重算

用Python运行，材料目录用你自己的绝对路径替换：

```powershell
python audit_sources.py --input-root 'D:/your-materials' --reference-fingerprints frozen_replay_fingerprints.json --protocol protocol.json --output fresh_results
python verify_source_audit.py --audit fresh_results --input-root 'D:/your-materials'
```

第一条拒绝覆盖已有目录，并核所有原始整文件SHA、重建六份历史CSV SHA。坐标查找采用两个实现相互核对。第二条只用Python标准库读取原始CSV，用独立二分查找及有理数分位数复核全部坐标和九行统计。results中保留本轮实际结果；point_source_coordinates.csv只有索引和时间坐标，不含状态测量值。

原CSV指纹来自Windows的UTF-8 BOM/CRLF序列化，脚本明确保留这一字节边界，不能仅因系统换行差异就放宽SHA。实际运行版本在requirements.txt；普通标准库检查器不需要这些第三方包。重算相同协议不是一批新实验样本。
