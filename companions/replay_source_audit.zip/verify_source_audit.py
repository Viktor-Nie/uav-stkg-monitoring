"""Independently check record coordinates and summaries using the standard library."""
import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
from fractions import Fraction
from hashlib import sha256
import io
import json
from pathlib import Path
from statistics import median
import zipfile

def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def quantile95(values):
    ordered = sorted(values)
    location = Fraction(len(values)-1) * Fraction(95, 100)
    left = location.numerator // location.denominator
    right = min(left+1, len(values)-1)
    return float(Fraction(ordered[left]) + (location-left)*(ordered[right]-ordered[left]))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--input-root', type=Path, required=True)
    args = parser.parse_args()
    sources = json.loads((args.audit/'source_inputs.json').read_text(encoding='utf-8'))
    coordinates = rows(args.audit/'point_source_coordinates.csv')
    summaries = rows(args.audit/'topic_summary.csv')
    grouped = defaultdict(list)
    for row in coordinates:
        grouped[row['case_id'], row['topic']].append(row)
    assert len(grouped) == len(summaries) == 9 and len(coordinates) == 11139
    summary = {(r['case_id'],r['topic']):r for r in summaries}
    archive = None
    try:
        for member in sources['native_members']:
            key = member['case_id'], member['topic']
            if member['member']:
                if archive is None:
                    archive = zipfile.ZipFile(args.input_root/member['path'])
                data = archive.read(member['member'])
            else:
                data = (args.input_root/member['path']).read_bytes()
            assert sha256(data).hexdigest() == member['sha256'], key
            native = list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
            times = [int(r['timestamp']) for r in native]
            assert all(a<b for a,b in zip(times,times[1:])),key
            selected = []; ages = []; grids = []
            for j,row in enumerate(grouped[key]):
                grid = int(row['grid_timestamp_us'])
                index = bisect_right(times,grid)-1
                assert int(row['grid_index']) == j
                assert index+2 == int(row['source_csv_line'])
                assert times[index] == int(row['source_timestamp_us'])
                assert grid-times[index] == int(row['record_age_us']) >= 0
                grids.append(grid);selected.append(index);ages.append(grid-times[index])
            assert all(b-a==50000 for a,b in zip(grids,grids[1:]))
            support = times[selected[0]:selected[-1]+1]
            gaps = [b-a for a,b in zip(support,support[1:])]
            expected = {'grid_observations':len(grids),'native_support_records':len(support),
                'distinct_used_records':len(set(selected)), 'reused_grid_observations':len(grids)-len(set(selected)),
                'age_median_us':median(ages), 'age_p95_us':quantile95(ages),'age_max_us':max(ages),
                'age_at_least_100ms_count':sum(x>=100000 for x in ages),
                'native_gap_max_us':max(gaps),'native_gap_gt_100ms_count':sum(x>100000 for x in gaps)}
            for field,value in expected.items():
                assert abs(float(summary[key][field])-value)<1e-7,(key,field)
            assert summary[key]['native_100ms_event_gap_pass'] == str(all(x<=100000 for x in gaps))
            assert summary[key]['native_20hz_jitter_profile_pass'] == str(all(abs(x-50000)<=2500 for x in gaps))
    finally:
        if archive is not None: archive.close()
    result = {'status':'passed','independent_method':'stdlib csv, bisect_right, statistics and rational linear quantile',
              'native_streams_checked':9,'all_point_coordinates_checked':len(coordinates),
              'all_summary_fields_checked':True,'raw_member_fingerprints_checked':9,
              'not_new_monitor_or_semantic_validation':True}
    (args.audit/'independent_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))

if __name__ == '__main__':
    main()
