"""Rebuild the training-composition diagnostic from explicit external raw inputs."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-state-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=1)
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    if not args.raw_state_root.is_dir():raise FileNotFoundError(args.raw_state_root)
    if args.workers<1:raise ValueError('workers must be positive')
    root=Path(__file__).resolve().parent
    output=args.output.resolve()
    adapter=output/'_work/threshold_reproduction'
    shutil.copytree(root/'threshold_reproduction',adapter)
    command=[sys.executable,'-B',str(adapter/'reproduce_thresholds.py'),
             '--raw-state-root',str(args.raw_state_root.resolve()),
             '--reference-split',str(adapter/'frozen_case_split.csv'),
             '--catalogue',str(adapter/'catalogue.csv'),
             '--workers',str(args.workers),'--output',str(output/'raw_recomputed')]
    with (output/'raw_reconstruction.log').open('w',encoding='utf-8') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run([sys.executable,'-B',str(root/'analyze_composition.py'),
                    '--stage-root',str(output)],check=True)

if __name__=='__main__':main()
