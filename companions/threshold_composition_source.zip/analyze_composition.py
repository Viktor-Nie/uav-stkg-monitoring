"""Train-only, exploratory composition sensitivity; no alternative limit adoption."""
from hashlib import sha256
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

OUT = Path.cwd()
RAW_RESULT = OUT/'raw_recomputed'
UNIT = {'speed_3d_mps':'m/s', 'height_m':'m', 'abs_roll_rad':'rad',
        'abs_pitch_rad':'rad', 'ang_rate_norm_rps':'rad/s'}
ZH = {'speed_3d_mps':'三维速度模', 'height_m':'高度绝对值', 'abs_roll_rad':'横滚角绝对值',
      'abs_pitch_rad':'俯仰角绝对值', 'ang_rate_norm_rps':'角速度向量模'}


def sha(path):
    value = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            value.update(block)
    return value.hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage-root', type=Path, default=OUT)
    args = parser.parse_args()
    OUT = args.stage_root.resolve()
    RAW_RESULT = OUT/'raw_recomputed'
    assert not (OUT/'diagnostic_receipt.json').exists(), 'Do not overwrite an analysis'
    repro = json.loads((RAW_RESULT/'reproduction_receipt.json').read_text(encoding='utf-8'))
    assert repro['complete_historical_population'] and repro['input_mode'] == 'raw_excel'
    assert repro['case_split_reconstructed_exact'] is True
    if repro['endpoint_projection_comparison'] is not None:
        assert repro['endpoint_projection_comparison']['keys_exact'] is True
        assert repro['endpoint_projection_comparison']['numeric_array_exact'] is True
    assert repro['threshold_maximum_absolute_difference'] <= 1e-12
    split = pd.read_csv(RAW_RESULT/'reconstructed_case_split.csv')
    frame = pd.read_parquet(RAW_RESULT/'reconstructed_threshold_window_endpoints.parquet')
    ordered = frame.sort_values(['case_root','window_end_index']).reset_index(drop=True)
    projection = sha256()
    for row in ordered[['case_root','split','window_end_index']].itertuples(index=False,name=None):
        projection.update(json.dumps(row,separators=(',',':')).encode()+b'\n')
    columns = ['speed_3d__last','altitude_estimated__last','roll__last','pitch__last',
               'ang_rate_x__last','ang_rate_y__last','ang_rate_z__last']
    projection.update(ordered[columns].to_numpy(dtype='<f8').tobytes())
    expected_projection = json.loads((OUT/'_work/threshold_reproduction/raw_reproduction_receipt.json').read_text(encoding='utf-8'))['endpoint_projection_comparison']['raw_sha256']
    assert projection.hexdigest() == expected_projection
    assert split['case_root'].str.startswith('HIL-NoFault/').equals(split['official_11_class'].eq('normal'))
    assert not split['case_root'].duplicated().any()
    assert not frame[['case_root','window_end_index']].duplicated().any()
    joined = frame.merge(split[['case_root','split','official_11_class','flight_status']],
                         on=['case_root','split'], how='left', validate='many_to_one', indicator=True)
    assert joined['_merge'].eq('both').all()
    train = joined.loc[joined['split'].eq('train')].copy()
    assert len(train) == 141508 and train['case_root'].nunique() == 1841
    assert set(train['split']) == {'train'}
    # Deliberately independent of the frozen derive_quantiles implementation:
    # NumPy quantile over the reconstructed raw numeric arrays, aligned by keys.
    arrays = {
        'speed_3d_mps': np.abs(train['speed_3d__last'].to_numpy()),
        'height_m': np.abs(train['altitude_estimated__last'].to_numpy()),
        'abs_roll_rad': np.abs(train['roll__last'].to_numpy()),
        'abs_pitch_rad': np.abs(train['pitch__last'].to_numpy()),
        'ang_rate_norm_rps': np.linalg.norm(train[['ang_rate_x__last','ang_rate_y__last','ang_rate_z__last']].to_numpy(), axis=1),
    }
    classes = train['official_11_class'].to_numpy()
    masks = {'all_train_windows':np.ones(len(train),dtype=bool),
             'normal_case_train_windows':classes == 'normal'}
    for label in sorted(set(classes)):
        masks['leave_out_case_class_'+label] = classes != label
    assert masks['normal_case_train_windows'].sum() == 8296
    records = []
    for group, mask in masks.items():
        subset = train.loc[mask]
        for signal, full_array in arrays.items():
            selected = full_array[mask]
            finite = selected[np.isfinite(selected)]
            assert len(finite) > 0
            for percentile in [.95,.99]:
                value = float(np.quantile(finite,percentile,method='linear'))
                records.append({'group':group,'signal_id':signal,'signal_zh':ZH[signal],
                                'percentile':percentile,'value':value,'unit':UNIT[signal],
                                'case_count':int(subset['case_root'].nunique()),
                                'window_count':len(subset),'finite_window_count':len(finite),
                                'nonfinite_window_count':len(selected)-len(finite),
                                'uses_validation_or_test':False})
    result = pd.DataFrame(records)
    result.to_csv(OUT/'training_composition_quantiles.csv',index=False,encoding='utf-8-sig')
    baseline = result[result['group'].eq('all_train_windows')]
    catalogue = pd.read_csv(OUT/'_work/threshold_reproduction/catalogue.csv',float_precision='round_trip')
    catalogue['percentile'] = catalogue['policy'].str.extract(r'quantile_(\d+)')[0].astype(int)/100
    assert not catalogue[['signal_id','percentile']].duplicated().any()
    check = baseline.merge(catalogue,on=['signal_id','percentile'],validate='one_to_one',suffixes=('_independent','_catalogue'))
    assert len(check) == 10
    check['absolute_difference'] = abs(check['value_independent']-check['value_catalogue'])
    assert np.allclose(check['value_independent'],check['value_catalogue'],rtol=0,atol=1e-12)
    check[['signal_id','percentile','value_independent','value_catalogue','absolute_difference']].to_csv(
        OUT/'independent_numpy_catalogue_comparison.csv',index=False,encoding='utf-8-sig')
    normal = result[result['group'].eq('normal_case_train_windows')]
    loo = result[result['group'].str.startswith('leave_out_case_class_')]
    summary = []
    for row in baseline.to_dict('records'):
        signal, percentile = row['signal_id'], row['percentile']
        other = normal[(normal.signal_id == signal)&(normal.percentile == percentile)].iloc[0]
        values = loo[(loo.signal_id == signal)&(loo.percentile == percentile)]
        low, high = values.loc[values['value'].idxmin()], values.loc[values['value'].idxmax()]
        summary.append({'signal_id':signal,'signal_zh':row['signal_zh'],'percentile':percentile,'unit':row['unit'],
                        'all_train_value':row['value'],'normal_case_value':float(other['value']),
                        'all_to_normal_ratio':row['value']/float(other['value']) if other['value'] else None,
                        'absolute_difference':row['value']-float(other['value']),
                        'leave_class_out_min':float(low['value']),'min_excluded_class':str(low['group']).removeprefix('leave_out_case_class_'),
                        'leave_class_out_max':float(high['value']),'max_excluded_class':str(high['group']).removeprefix('leave_out_case_class_')})
    pd.DataFrame(summary).to_csv(OUT/'threshold_sensitivity_summary.csv',index=False,encoding='utf-8-sig')
    lengths = train.groupby(['official_11_class','case_root'],sort=True).size().rename('windows').reset_index()
    composition = lengths.groupby('official_11_class',sort=True).agg(
        train_cases=('case_root','size'),train_windows=('windows','sum'),
        minimum_windows_per_case=('windows','min'),median_windows_per_case=('windows','median'),
        maximum_windows_per_case=('windows','max')).reset_index()
    composition['fraction_of_train_windows'] = composition['train_windows']/len(train)
    composition['fraction_of_train_cases'] = composition['train_cases']/1841
    composition.to_csv(OUT/'training_case_composition.csv',index=False,encoding='utf-8-sig')
    receipt = {'date_local':'2026-11-04','analysis_status':'exploratory_not_adopted',
               'raw_case_count':2613,'total_reconstructed_windows':201026,'train_cases':1841,'train_windows':141508,
               'normal_train_cases':168,'normal_train_windows':8296,
               'normal_window_fraction':8296/141508,'case_classes':len(set(classes)),
               'diagnostic_populations':len(masks),'quantile_rows':len(result),
               'nonfinite_counts_by_signal_all_train':{s:int((~np.isfinite(v)).sum()) for s,v in arrays.items()},
               'independent_numpy_catalogue_maximum_difference':float(check['absolute_difference'].max()),
               'canonical_endpoint_projection_sha256':projection.hexdigest(),
               'normal_directory_matches_recorded_class':True,
               'all_train_reproduction_receipt_sha256':sha(RAW_RESULT/'reproduction_receipt.json'),
               'raw_endpoint_parquet_sha256':sha(RAW_RESULT/'reconstructed_threshold_window_endpoints.parquet'),
               'split_sha256':sha(RAW_RESULT/'reconstructed_case_split.csv'),
               'numpy':np.__version__,'pandas':pd.__version__,
               'formal_thresholds_changed':False,'new_engineering_limits':False,
               'uses_validation_or_test_for_sensitivity':False,'confidence_intervals_or_pvalues':False,
               'interpretation':'Window-pooled descriptive quantiles. Changes with case composition are not isolated causal effects of fault injection. Normal-case-only quantiles remain research references, not safety limits. No independence or cross-platform calibration claim.'}
    (OUT/'diagnostic_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False,indent=2))
    for row in summary:
        print(json.dumps(row,ensure_ascii=False))
