# v52 training-composition diagnostic

This is a separate, exploratory diagnostic companion. The public v35 research archive remains unchanged. No raw HIL telemetry or historical feature Parquet is bundled. The ten adopted research reference values are unchanged.

Use Python with the recorded NumPy/pandas/PyArrow versions in requirements.txt. Acquire the same external Kaggle RflyMAD-HIL version 2 state-only layout identified by the manuscript and v35 acquisition instructions. Supply its parent directory containing the HIL-* case groups, and choose a NEW output path:

    python -B reproduce_composition.py --raw-state-root "PATH/TO/HIL-Complete-StateOnly" --workers 4 --output "PATH/TO/NEW-RUN"

The driver rebuilds the split and seven endpoint columns, checks the frozen split and catalogue, checks the canonical endpoint projection fingerprint, then computes all five observables at p95 and p99 for the full training population, normal cases, and eleven class deletions. Window values receive equal weight. Validation/test data do not construct the quantiles. Each case-class deletion is a repeated view of the same data, not an independent new sample. A recorded fault-type case is not an assertion that every window is fault-active.

The original adapter and its historical reference receipt retain their v35 provenance. New results go only into the chosen output directory; the driver refuses to overwrite it. Raw-state reconstruction can take several minutes. raw_reconstruction.log records the command output. No model calls, training, hidden downloads or flight-controller access occur.

The bundled aggregate CSV files are the complete diagnostic results, with case/window/finite-value counts and all class deletions. Normal-case quantiles are not engineering safety limits; differences cannot be causally assigned to fault injection alone. No graph binding is changed. Internal-configuration counts are separately checked against the frozen 24-row graph inputs and retained bindings.
