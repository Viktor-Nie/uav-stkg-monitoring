# v62本地可选数值入口修复

只用Python标准库。本包保留原v35入口与修订入口，不修改、不替代公共v35标签或其历史结果。实际使用修订版时运行：
python fixed_entry/validate_candidate.py examples/matching_deadline.json
python fixed_entry/validate_candidate.py examples/unicode_minus.json

前者应返回accepted=true，后者应在explicit_numeric_text阶段拒绝、stkg_checked=false，且不提供绑定值。输入JSON中的目录绑定必须是真实已核的冻结绑定，不能以这个词法检查替代完整图验证、整句理解或物理标定。

回归检查：
python run_guard_controls.py --module-dir legacy_v35 --protocol guard_protocol.json --output rerun_legacy --mode legacy
python run_guard_controls.py --module-dir fixed_entry --protocol guard_protocol.json --output rerun_fixed --mode fixed
进入legacy_v35和fixed_entry分别运行python -m unittest test_numeric_text_guard，各有7个原测试。

24个针对性词法控制在发现缺陷后构造：16个预定不支持的写法，8个支持的格式/无显式数值控制。它们是围绕冻结N06角色绑定的标量片段，不是新收集的完整需求或独立语义标签。部分正号写法在数学上等价，拒绝它们只是保守语法范围，不代表数值本身错误。未静默规范化符号，也未修改原文/目录值。未提供通用数学语言解析保证。

原v35代码可把Unicode负号、分隔ASCII负号、单位幂等忽略而接受。修订版先拒绝指定Unicode/分隔或重复符号、非十进制数字记号、Unicode无穷与近似符号、单位乘积/幂扩展；原math.isclose容差不变。原24条配置的完整返回记录逐字节保持。无模型调用、训练、监测判决、人工标签或投稿。
