"""Audit two sampled roll excursions and the onboard PX4 detector flag."""

import argparse
import json
from hashlib import sha256
from pathlib import Path

import numpy as np
from pyulog import ULog


LOG_ID = "a6ac0daa-0968-4cd6-83c1-d4c71adfe5a5"
SHA256 = "5a3a4a2aad31eb8393ed24d93bb78c3f0438627f72816b69a2ccae8b579b7afe"
REVISION = "b8c541dd7277ed735139d7d1bfb829d61fbe29fb"
PARAMETERS = {
    "FD_FAIL_R": 60,
    "FD_FAIL_R_TTRI": 0.30000001192092896,
    "CBRK_FLIGHTTERM": 121212,
    "SYS_HITL": 0,
    "SYS_FAILURE_EN": 0,
}
TOPICS = (
    "vehicle_attitude",
    "failure_detector_status",
    "vehicle_status",
    "vehicle_control_mode",
    "vehicle_land_detected",
    "vehicle_local_position",
)


def audit(log_path):
    if sha256(log_path.read_bytes()).hexdigest() != SHA256:
        raise ValueError("Unexpected ULog digest")
    log = ULog(str(log_path), message_name_filter_list=list(TOPICS))
    assert log.msg_info_dict["ver_sw"] == REVISION
    assert PARAMETERS == {key: log.initial_parameters[key] for key in PARAMETERS}
    assert not any(key in PARAMETERS for _, key, _ in log.changed_parameters)
    topic = {name: log.get_dataset(name).data for name in TOPICS}
    attitude = topic["vehicle_attitude"]
    time = attitude["timestamp"].astype(np.int64)
    q0, q1, q2, q3 = (attitude[f"q[{i}]"].astype(float) for i in range(4))
    roll = np.degrees(np.arctan2(2 * (q0 * q1 + q2 * q3), 1 - 2 * (q1**2 + q2**2)))
    outside = np.abs(roll) > PARAMETERS["FD_FAIL_R"]

    def latest(name, when):
        return int(np.searchsorted(topic[name]["timestamp"], when, side="right")) - 1

    def observation(index):
        when = int(time[index])
        status = latest("vehicle_status", when)
        control = latest("vehicle_control_mode", when)
        land = latest("vehicle_land_detected", when)
        position = latest("vehicle_local_position", when)
        state = topic["vehicle_status"]
        assert state["arming_state"][status] == 2 and state["nav_state"][status] == 2
        assert not state["is_vtol"][status] and not topic["vehicle_land_detected"]["landed"][land]
        assert topic["vehicle_control_mode"]["flag_control_attitude_enabled"][control]
        assert topic["vehicle_local_position"]["z_valid"][position]
        return {
            "attitude_row": index + 1,
            "publication_us": when,
            "sensor_sample_us": int(attitude["timestamp_sample"][index]),
            "roll_deg": round(float(roll[index]), 7),
            "local_position_row": position + 1,
            "local_z_m": float(topic["vehicle_local_position"]["z"][position]),
            "vehicle_status_row": status + 1,
            "control_mode_row": control + 1,
            "land_detection_row": land + 1,
        }

    def excursion(trigger_row, return_row):
        first = trigger_row - 1
        back = return_row - 1
        assert not outside[first - 1] and np.all(outside[first:back]) and not outside[back]
        for index in range(first - 1, back + 1):
            observation(index)
        flag = topic["failure_detector_status"]
        left = latest("failure_detector_status", int(time[first - 1]))
        right = latest("failure_detector_status", int(time[back]))
        return {
            "preceding": observation(first - 1),
            "first_outside": observation(first),
            "last_outside": observation(back - 1),
            "first_in_range": observation(back),
            "observed_return_elapsed_us": int(time[back] - time[first]),
            "bracket_span_us": int(time[back] - time[first - 1]),
            "observed_max_gap_us": int(max(np.diff(time[first - 1 : back + 1]))),
            "fd_roll_records": [
                {"row": i + 1, "publication_us": int(flag["timestamp"][i]), "value": int(flag["fd_roll"][i])}
                for i in range(left, right + 1)
            ],
        }

    long = excursion(3009, 3020)
    short = excursion(3040, 3044)
    first_flag = next(row for row in long["fd_roll_records"] if row["value"])
    assert first_flag["row"] == 300
    assert all(row["value"] == 0 for row in short["fd_roll_records"])
    return {
        "source_report": "https://discuss.px4.io/t/39488",
        "source_ulog": f"https://cdn.logs.px4.io/{LOG_ID}.ulg",
        "sha256": SHA256,
        "revision": REVISION,
        "parameters": PARAMETERS,
        "long_excursion": long,
        "short_excursion": short,
        "first_logged_roll_flag_us_after_first_exceedance": (
            first_flag["publication_us"] - long["first_outside"]["publication_us"]
        ),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    parser.add_argument("receipt", type=Path)
    options = parser.parse_args()
    options.receipt.write_text(json.dumps(audit(options.log), indent=2) + "\n", encoding="utf-8")
