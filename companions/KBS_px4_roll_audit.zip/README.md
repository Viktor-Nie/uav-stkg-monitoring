# PX4 roll detector and logged observations

Obtain the original ULog from https://cdn.logs.px4.io/a6ac0daa-0968-4cd6-83c1-d4c71adfe5a5.ulg .
Use Python with numpy and pyulog.

    python -B audit_px4_roll.py LOG.ulg comparison.json

Compare comparison.json to px4_roll_receipt.json. Topic row numbers are
one-based and the elapsed times use onboard publication timestamps.
The receipt gives status, land detection and local-position rows for the
selected observations along with the separately logged roll detector flag.
