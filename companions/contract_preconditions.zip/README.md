# Observation-contract constructor repair, v69

Local companion separate from frozen publicv35. Only fixed/monitor/sampled_data_contract.py changes: six real-valued contract fields must be finite Real values excluding Boolean, and minimum_sample_count must be an Integral>=2 excluding Boolean. Existing range checks remain. Unsupported parameter types/values raise ValueError at construction, before any trace admission or property verdict. Frozen original code remains in legacy/monitor. This does not validate arbitrary specification objects or physical gap budgets.

Requires the existing NumPy and pandas monitor dependencies; no model, raw flight logs, external services, or new library. Tested locally with the environment recorded in environment.json.58 malformed/range controls and8 supported profiles were defined after inspection; five small constructed trace audits per valid profile provide40 output-compatibility opportunities. They are not new independent requirements. Original37 unit tests run for each entry without fixture/assertion edits. Only constructor checks and two private helpers/imports change; all audit function AST and other monitor/test files remain unchanged.

Run from archive root in a new destination:
python -B run_contract_controls.py --entry fixed --output new_fixed_controls.json
For original37 tests, cd fixed and run:
python -B -m unittest monitor.test_timestamp_precision monitor.test_legacy_api_compatibility
Use legacy in place of fixed for comparison. File outputs refuse overwrites. Tagged nonfinite JSON values decode to actual floats at the control call boundary. Core numerical limitations, source freshness, parameter authenticity and full graph validation remain separate.
