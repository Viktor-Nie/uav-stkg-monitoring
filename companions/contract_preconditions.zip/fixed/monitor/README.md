# v33 formal sampled-observation monitor

This local candidate is the v33 execution entry. It adds exact-input timestamp
preparation to the frozen sampled-point FIFO monitor, with graph-bound execution.
It does not implement unrestricted STL or certify a physical safety threshold.
The study's bounded-response comparisons use `d > 0` and `0 <= dwell < d`.

## Input and compatibility

`monitor_invariant(trace, specification, contract)` and
`monitor_bounded_response(trace, specification, contract)` retain the existing
DataFrame API, specification parameters, verdicts, obligation IDs and event
field names. Exact `time_seconds` strings, `Decimal` values and integers are
processed by `timestamp_precision.py`: parse exactly, record the first source
time, subtract it in Decimal, then convert only relative times to float.
Integer clocks may pass an exact `timestamp_scale_seconds="0.000001"` for
microsecond ticks. Signals and every deadline/dwell/tolerance remain unchanged.

Previously parsed float timestamps use `legacy_absolute_float` to retain old
caller behaviour. This path explicitly records that original source precision
is unavailable; subtracting an origin later would not recover lost digits.
Do not parse a native timestamp to float before calling the exact path.

The core still uses its existing expire/recover/trigger update order. Events
retain absolute float `observed_time_seconds`, `trigger_time_seconds`,
`deadline_time_seconds` and recovery-start fields. The result additionally has
`time_mapping`, `relative_events`, `relative_created_obligations` and
`absolute_event_records`. Exact observed/trigger/recovery coordinates in those
records resolve by source indices; the exact logical deadline is source trigger
time plus the decimal spelling of the unchanged deadline setting. The actual
relative floating deadline is retained separately. Exact decimal records are
the authoritative source coordinates when large absolute floats cannot express
the small distinctions. No precision already lost upstream is restored.

The source contract audit uses the prepared relative timestamps and records
source absolute first/last coordinates in the compatibility fields. Invalid,
nonfinite, non-increasing, undersampled or out-of-contract traces remain
rejected. The adapter does not sort, fill, interpolate or widen a tolerance.
Finite relative-span floating-point rounding remains possible.

## Run

From this directory's parent (`research/`), with NumPy and pandas installed:

```text
python -B -m unittest monitor.test_timestamp_precision monitor.test_legacy_api_compatibility -v
python -B -m monitor.run_precision_regression --output ../precision_new_run
```

The frozen suite runner refuses an existing output directory. It executes the
102 cases/553 eligible prefixes/24 transformations and the separate 648-case
suite/16,134 prefixes/12 contract controls. The two Decimal references are
retained independent future-witness enumerators with no production imports.
They are not derived from the production predicates or state transitions.

To also compare the four historical event ledgers in a full research workspace:

```text
python -B -m monitor.run_precision_regression --output ../precision_new_full_run --project-root PROJECT_ROOT
```

This integration reads frozen derived CSV observations and preserves all old
results. It compares each graph-bound configuration and every retained event,
including absolute-time mapping, against the four original ledgers. It does not
reparse raw ULogs, acquire new flights or claim an independent-platform test.
Public redistribution conditions for the input datasets remain source-specific.

The standalone CSV entry always reads `time_seconds` as strings:

```text
python -B -m monitor.sampled_monitor --trace trace.csv --specification specification.json --contract contract.json --output result.json
```

The specification JSON has `kind` (`invariant` or `response`) and the unchanged
specification fields. Contract JSON has `profile` (`fixed_rate` or `event_time`)
and the corresponding existing contract fields. The result file must not exist.

## Graph execution and provenance

`monitor_from_traceability_graph.py` provides `instantiate_formula`,
`monitor_formula_from_graph`, `replay_trace` and `replay_event_ledger`. Optional
`graph_directory` and `contract` arguments select a verified frozen export and
its explicitly declared observation profile. The included CSVs are an exact
copy of the historical binding export; schema/source/role validation remains a
separate gate. The reader checks unambiguous bindings and does not replace the
full STKG gate.

`_legacy_sampled_monitor.py` is the frozen `specification/v2/sampled_monitor.py`
core with package imports adapted; `sampled_data_contract.py` is copied byte for
byte. Historical originals are preserved. Fixture source hashes, formal-entry
run signatures, all discrepancies and protected historical-file hashes are
recorded by the regression runner. Old absolute-time failures are retained as
historical findings; formal v33 outcomes are reported separately.

No new dependency, training or model-service request is introduced. The local
candidate does not assign a new public code license or publish any source/data.
