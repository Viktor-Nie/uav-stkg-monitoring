"""Post-inspection constructor controls; no language or flight evaluation."""
from pathlib import Path
from dataclasses import asdict
import argparse
import importlib
import json
import math
import sys


def decode(value):
    if isinstance(value, dict) and set(value) == {'$float'}:
        return {'nan': float('nan'), 'inf': float('inf'), '-inf': float('-inf')}[value['$float']]
    if isinstance(value, dict):
        return {k: decode(v) for k, v in value.items()}
    if isinstance(value, list):
        return [decode(v) for v in value]
    return value


def encode(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {'$float': 'nan' if math.isnan(value) else 'inf' if value > 0 else '-inf'}
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry', required=True, choices=['legacy', 'fixed'])
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    assert not args.output.exists()
    sys.path.insert(0, str(root / args.entry))
    m = importlib.import_module('monitor.sampled_data_contract')
    import pandas as pd
    protocol = json.loads((root / 'contract_protocol.json').read_text(encoding='utf-8'))
    output = []
    for case in protocol['controls']:
        cls = getattr(m, case['class'])
        record = dict(id=case['id'], expected=case['expected'], configuration=case['configuration'])
        try:
            contract = cls(**decode(case['configuration']))
        except Exception as exc:
            record.update(outcome='constructor_error', exception=type(exc).__name__, message=str(exc))
        else:
            record.update(outcome='constructed', fields=encode(asdict(contract)))
            audits = []
            for trace in protocol['audit_traces']:
                frame = pd.DataFrame(decode(trace['data']))
                function = m.audit_sampled_trace if case['class'] == 'SamplingContract' else m.audit_event_time_trace
                try:
                    audit = function(frame, signal_columns=['x'], contract=contract)
                    audits.append(dict(id=trace['id'], outcome='audit', result=encode(audit.to_dict())))
                except Exception as exc:
                    audits.append(dict(id=trace['id'], outcome='audit_error', exception=type(exc).__name__, message=str(exc)))
            record['audits'] = audits
        output.append(record)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(dict(controls=output), ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(entry=args.entry, controls=len(output), constructed=sum(r['outcome'] == 'constructed' for r in output))))


if __name__ == '__main__':
    main()
