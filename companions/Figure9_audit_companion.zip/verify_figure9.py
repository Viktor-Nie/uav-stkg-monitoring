"""Offline, standard-library audit of the supplied Figure 9 evidence extracts.

Optional original-source checks require --official-archive and/or
--training-endpoints. No inputs are downloaded or changed.
"""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import argparse
import csv
import hashlib
import io
import json
import math
import zipfile


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def event_tuple(row):
    return (row['event_type'], int(row['trace_index_0based']), float(row['time_seconds']),
            float(row['speed_3d_mps']), int(row['obligation_id_internal_0based']),
            float(row['trigger_time_seconds']), float(row['deadline_seconds']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--official-archive', type=Path)
    parser.add_argument('--training-endpoints', type=Path)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    root = args.directory
    trace = read_csv(root / '407_1_observable_trace.csv')
    points = read_csv(root / 'fig9_point_provenance_201.csv')
    flags = read_csv(root / 'fig9_velocity_quality_flags_201.csv')
    quantiles = read_csv(root / 'figure9_speed_threshold_basis.csv')
    expected = read_csv(root / 'fig9_all_N06_events_independent_536.csv')
    receipt = json.loads((root / 'point_event_audit_receipt.json').read_text(encoding='utf-8'))
    before = {p.name: sha(p) for p in root.iterdir() if p.is_file() and p.suffix in ['.csv', '.json'] and p != args.receipt}
    assert len(trace) == 1263 and len(points) == len(flags) == 201
    selected = [(i, x) for i, x in enumerate(trace) if 24 <= float(x['time_seconds']) <= 34]
    assert len(selected) == 201
    for (index, observation), point, quality in zip(selected, points, flags):
        assert index == int(point['trace_index_0based'])
        assert float(observation['time_seconds']) == float(point['time_seconds']) == float(quality['time_seconds'])
        norm = math.sqrt(sum(float(point[k]) ** 2 for k in ['source_vx', 'source_vy', 'source_vz']))
        assert abs(norm - float(observation['speed_3d_mps'])) < 2e-14
        assert float(observation['speed_3d_mps']) == float(point['plotted_speed_3d_mps'])
        grid = receipt['time_origin_us'] + index * 50000
        assert grid == int(point['grid_timestamp_us']) == int(quality['grid_timestamp_us'])
        assert grid - int(point['source_timestamp_us']) == int(point['source_age_us']) >= 0
        assert int(point['source_csv_line']) == int(quality['source_csv_line'])
        assert int(quality['v_xy_valid']) == int(quality['v_z_valid']) == 1
    assert len({p['source_csv_line'] for p in points}) == 102
    ages = [int(x['source_age_us']) for x in points]
    assert min(ages) == 28 and max(ages) == 107974
    assert sum(a >= 100000 for a in ages) == 22
    for key, value in [('vxy_reset_counter', 2), ('vz_reset_counter', 1)]:
        assert {int(x[key]) for x in flags} == {value}
    for q in quantiles:
        n = int(q['finite_speed_window_count'])
        h = Decimal(n - 1) * Decimal(q['q'])
        j = int(h)
        assert h == Decimal(q['h_zero_based_exact_decimal'])
        assert j == int(q['left_index_zero_based']) and j + 1 == int(q['right_index_zero_based'])
        assert h - j == Decimal(q['right_weight_exact_decimal'])
        a, b, weight = float(q['left_speed_mps']), float(q['right_speed_mps']), float(q['right_weight_binary_float'])
        value = a + weight * (b - a)
        assert value == float(q['frozen_catalogue_mps']) == float(q['recomputed_pandas_mps'])
    # Enumerate future witnesses independently of the archived FIFO monitor.
    times = [float(x['time_seconds']) for x in trace]
    values = [float(x['speed_3d_mps']) for x in trace]
    u, r, deadline, eps = float(receipt['monitor_trigger_threshold']), float(receipt['recovery_threshold']), 2.0, 1e-9
    events, oid = [], 0
    for i, (now, value) in enumerate(zip(times, values)):
        if value <= u:
            continue
        due = now + deadline
        events.append(('obligation_triggered', i, now, value, oid, now, due))
        witness = next((j for j in range(i + 1, len(trace)) if times[j] <= due + eps and values[j] <= r), None)
        if witness is not None:
            events.append(('obligation_recovered', witness, times[witness], values[witness], oid, now, due))
        else:
            expiry = next((j for j in range(i + 1, len(trace)) if times[j] > due + eps), None)
            if expiry is not None:
                events.append(('obligation_expired', expiry, times[expiry], values[expiry], oid, now, due))
        oid += 1
    assert Counter(events) == Counter(map(event_tuple, expected))
    assert Counter(e[0] for e in events) == {'obligation_triggered': 268, 'obligation_expired': 196, 'obligation_recovered': 72}
    later = [e for e in events if e[0] == 'obligation_recovered' and e[2] == 32.95]
    assert len(later) == 35 and {e[4] for e in later} == set(range(95, 130))
    assert not any(e[0] == 'obligation_recovered' and e[4] == 0 for e in events)
    source_checks = {'original_archive_checked_this_run': False, 'full_training_population_checked_this_run': False}
    if args.official_archive:
        member = next(x for x in receipt['source_members'] if 'vehicle_local_position' in x['member'])
        with zipfile.ZipFile(args.official_archive) as archive:
            raw = archive.read(member['member'])
        assert hashlib.sha256(raw).hexdigest() == member['sha256']
        rows = list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
        for p in points:
            index = int(p['source_csv_line']) - 2
            source = rows[index]
            timestamp = int(source['timestamp'])
            grid = int(p['grid_timestamp_us'])
            assert timestamp == int(p['source_timestamp_us']) <= grid
            assert index + 1 == len(rows) or int(rows[index + 1]['timestamp']) > grid
            for axis in ['vx', 'vy', 'vz']:
                assert float(source[axis]) == float(p['source_' + axis])
        source_checks['original_archive_checked_this_run'] = True
        source_checks['native_local_position_member_sha256'] = member['sha256']
        source_checks['whole_archive_rehashed_this_run'] = False
    if args.training_endpoints:
        import pandas as pd
        frame = pd.read_parquet(args.training_endpoints, columns=['split', 'speed_3d__last'])
        series = frame.loc[frame['split'] == 'train', 'speed_3d__last']
        assert len(series) == 141508 and all(math.isfinite(float(x)) for x in series)
        sorted_values = sorted(float(x) for x in series)
        for row in quantiles:
            assert sorted_values[int(row['left_index_zero_based'])] == float(row['left_speed_mps'])
            assert sorted_values[int(row['right_index_zero_based'])] == float(row['right_speed_mps'])
            assert float(series.quantile(float(row['q']), interpolation='linear')) == float(row['frozen_catalogue_mps'])
        source_checks['full_training_population_checked_this_run'] = True
        source_checks['training_endpoint_parquet_sha256'] = sha(args.training_endpoints)
    assert before == {p.name: sha(p) for p in root.iterdir() if p.is_file() and p.name in before}
    result = {'status': 'passed', 'point_count': 201, 'distinct_native_velocity_rows': 102,
              'source_age_max_us': 107974, 'source_age_at_least_100ms': 22,
              'quantile_bracket_reconstructions': 2, 'future_scanning_event_count': len(events),
              'later_recovery_count': 35, 'all_extract_inputs_unchanged': True,
              'default_scope': 'Recompute locally reconstructed extracts; full-source authenticity requires optional external inputs.',
              **source_checks}
    if args.receipt:
        args.receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
