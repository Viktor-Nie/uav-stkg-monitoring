# Figure 9: local reconstruction

Obtain the official RflyMAD Real-Motor.zip from the data provider under its terms:
https://rfly-openha.github.io/documents/4_resources/dataset.html
The archive is a local input. Its three required 407_1 PX4 topic members are checked against the original SHA-256 values. No telemetry is downloaded or distributed here.

Use Python 3 with NumPy and pandas (tested with 2.3.5 and 2.3.3 respectively). From this directory, run:

    python rebuild_figure9.py --official-archive /path/to/Real-Motor.zip --output local_extracts
    python verify_figure9.py --directory local_extracts --official-archive /path/to/Real-Motor.zip

Choose a new output directory. The first command regenerates the full 1,263-row observation table, 201 point mappings, 201 quality rows, 536 events and 38 selected event records. Their expected hashes are in reconstruction.json. Verification compares the five files byte-for-byte to the original Windows CSV exports (UTF-8 BOM and CRLF). The point mapping and verifier use only causal sampled observations.

The two threshold statistics are supplied as a small derived summary. To independently check the training quantiles, append --training-endpoints /path/to/reconstructed_threshold_window_endpoints.parquet to the verifier command (pandas and PyArrow). This input is separate from the Real-Motor archive.

This distribution omits row-level flight extracts, internal manuscript-building scripts and private-machine receipts. Reconstruct the extracts locally before running the offline verifier. The local point-event receipt contains the source-member identities and monitor thresholds required by the verifier. The full source archive digest recorded by the original study is 77161c06b2c27b0827e253f4b0bdd36bb5074414e8d235da0a5b7f6aa01efab6.
