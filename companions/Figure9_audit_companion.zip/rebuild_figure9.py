"""Regenerate the Figure 9 extracts from a user-supplied RflyMAD Real-Motor archive."""
from pathlib import Path
from bisect import bisect_right
from collections import deque
from tempfile import TemporaryDirectory
import argparse
import csv
import hashlib
import io
import json
import math
import zipfile
import shutil
import numpy as np
import pandas as pd

GRID_US = 50_000
BASE = Path(__file__).resolve().parent

def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))

def write_csv(path, records):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)

def asof(grid: pd.DataFrame, source: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    return pd.merge_asof(
        grid,
        source[["timestamp", *columns]].sort_values("timestamp"),
        on="timestamp",
        direction="backward",
    )


def build_grid(archive_path, prefix):
    with zipfile.ZipFile(archive_path) as archive:
        local = pd.read_csv(archive.open(f"{prefix}vehicle_local_position_0.csv")).sort_values("timestamp")
        attitude = pd.read_csv(archive.open(f"{prefix}vehicle_attitude_0.csv")).sort_values("timestamp")
        angular = pd.read_csv(archive.open(f"{prefix}vehicle_angular_velocity_0.csv")).sort_values("timestamp")

    start = int(max(local.timestamp.min(), attitude.timestamp.min(), angular.timestamp.min()))
    end = int(min(local.timestamp.max(), attitude.timestamp.max(), angular.timestamp.max()))
    grid = pd.DataFrame({"timestamp": np.arange(start, end + 1, GRID_US, dtype=np.int64)})
    state = asof(grid, local, ["x", "y", "z", "vx", "vy", "vz"])
    state = asof(state, attitude, ["q[0]", "q[1]", "q[2]", "q[3]"])
    state = asof(state, angular, ["xyz[0]", "xyz[1]", "xyz[2]"])
    quat = state[["q[1]", "q[2]", "q[3]", "q[0]"]].to_numpy(float)
    x, y, z, w = quat.T
    state["roll"] = np.arctan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    state["pitch"] = np.arcsin(np.clip(2 * (w * y - z * x), -1, 1))
    state["yaw"] = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    state = state.rename(columns={
        "x": "pos_n", "y": "pos_e", "z": "pos_d", "vx": "vel_n", "vy": "vel_e", "vz": "vel_d",
        "xyz[0]": "ang_rate_x", "xyz[1]": "ang_rate_y", "xyz[2]": "ang_rate_z",
    })
    online = state[[
        "pos_n", "pos_e", "pos_d", "vel_n", "vel_e", "vel_d", "roll", "pitch", "yaw",
        "ang_rate_x", "ang_rate_y", "ang_rate_z",
    ]].copy()
    online["time_seconds"] = (state.timestamp - start) / 1_000_000
    return online


def derive_observable_trace(raw: pd.DataFrame) -> pd.DataFrame:
    required = {"time_seconds", "pos_d", "vel_n", "vel_e", "vel_d", "roll", "pitch", "ang_rate_x", "ang_rate_y", "ang_rate_z"}
    missing = required - set(raw.columns)
    if missing:
        raise ValueError(f"raw multi-log input misses fields: {sorted(missing)}")
    return pd.DataFrame({
        "time_seconds": raw["time_seconds"],
        "speed_3d_mps": (raw["vel_n"] ** 2 + raw["vel_e"] ** 2 + raw["vel_d"] ** 2) ** 0.5,
        "height_m": raw["pos_d"].abs(),
        "abs_roll_rad": raw["roll"].abs(),
        "abs_pitch_rad": raw["pitch"].abs(),
        "ang_rate_norm_rps": (raw["ang_rate_x"] ** 2 + raw["ang_rate_y"] ** 2 + raw["ang_rate_z"] ** 2) ** 0.5,
    })



def reconstruct(archive_path, out, config):
    grid = build_grid(archive_path, config['source_prefix'])
    # Preserve the original pandas CSV read-back before deriving the six signals.
    csv_grid = grid.to_csv(index=False, lineterminator='\r\n')
    state = pd.read_csv(io.StringIO(csv_grid))
    trace_file = out / '407_1_observable_trace.csv'
    derive_observable_trace(state).to_csv(trace_file, index=False, encoding='utf-8-sig', lineterminator='\r\n')
    trace = read_csv(trace_file)
    raw = list(csv.DictReader(io.StringIO(csv_grid)))
    prefix = config['source_prefix']
    member_records, native = [], {}
    with zipfile.ZipFile(archive_path) as archive:
        for topic in ('vehicle_local_position', 'vehicle_attitude', 'vehicle_angular_velocity'):
            name = prefix + topic + '_0.csv'
            payload = archive.read(name)
            info = archive.getinfo(name)
            parsed = list(csv.DictReader(io.StringIO(payload.decode('utf-8-sig'))))
            for i, row in enumerate(parsed):
                row['_source_csv_line'] = i + 2
            parsed.sort(key=lambda r: int(r['timestamp']))
            native[topic] = parsed
            member_records.append(dict(member=name, sha256=hashlib.sha256(payload).hexdigest(),
                                       bytes=len(payload), crc32=f'{info.CRC:08x}', row_count=len(parsed),
                                       first_timestamp_us=int(parsed[0]['timestamp']),
                                       last_timestamp_us=int(parsed[-1]['timestamp'])))
    if {r['member']:r['sha256'] for r in member_records} != config['native_sha256']:
        raise ValueError('Unexpected source member hash')
    start = max(int(v[0]['timestamp']) for v in native.values())
    end = min(int(v[-1]['timestamp']) for v in native.values())
    assert start == config['time_origin_us']
    assert end == config['end_us']
    local = native['vehicle_local_position']
    times = [int(r['timestamp']) for r in local]
    quality_fields = ['timestamp_sample', 'v_xy_valid', 'v_z_valid', 'xy_valid', 'z_valid',
                      'vxy_reset_counter', 'vz_reset_counter', 'xy_reset_counter', 'z_reset_counter',
                      'heading_reset_counter', 'delta_vxy[0]', 'delta_vxy[1]', 'delta_vz',
                      'evh', 'evv']
    point_records, quality_records, all_diff = [], [], []
    for i, (plot, state) in enumerate(zip(trace, raw)):
        grid_us = start + i * 50_000
        t = (grid_us - start) / 1_000_000
        j = bisect_right(times, grid_us) - 1
        source = local[j]
        vx, vy, vz = (float(source[k]) for k in ('vx', 'vy', 'vz'))
        speed = math.sqrt(vx*vx + vy*vy + vz*vz)
        pv = float(plot['speed_3d_mps'])
        assert float(plot['time_seconds']) == float(state['time_seconds']) == t
        assert all(float(state[k]) == v for k, v in zip(('vel_n','vel_e','vel_d'), (vx, vy, vz)))
        all_diff.append(abs(speed-pv))
        assert abs(speed-pv) <= 2e-14
        if 24 <= t <= 34:
            point_records.append(dict(plot_point_1based=len(point_records)+1, trace_index_0based=i,
                trace_csv_line=i+2, raw_grid_csv_line=i+2, time_seconds=repr(t), grid_timestamp_us=grid_us,
                source_topic='vehicle_local_position', source_member=prefix+'vehicle_local_position_0.csv',
                source_csv_line=source['_source_csv_line'], source_timestamp_us=int(source['timestamp']),
                source_age_us=grid_us-int(source['timestamp']), source_vx=source['vx'], source_vy=source['vy'],
                source_vz=source['vz'], speed_definition='sqrt(vx^2+vy^2+vz^2)',
                recomputed_speed_3d_mps=repr(speed), plotted_speed_3d_mps=plot['speed_3d_mps'],
                absolute_difference_mps=abs(speed-pv), alignment='backward causal zero-order hold on 20 Hz grid'))
            quality_records.append(dict(plot_point_1based=len(point_records), time_seconds=repr(t),
                source_csv_line=source['_source_csv_line'], source_timestamp_us=int(source['timestamp']),
                grid_timestamp_us=grid_us, grid_age_from_timestamp_sample_us=grid_us-int(source['timestamp_sample']),
                **{key:source[key] for key in quality_fields if key in source}))
    assert len(point_records) == 201
    assert point_records[0]['trace_index_0based'] == 480 and point_records[-1]['trace_index_0based'] == 680
    write_csv(out / 'fig9_point_provenance_201.csv', point_records)
    write_csv(out / 'fig9_velocity_quality_flags_201.csv', quality_records)


    u, r, d = config['trigger'], config['recovery'], config['deadline_seconds']
    # Independent direct finite-sample evaluator; no project monitor function is called.
    pending, rebuilt, ident = deque(), [], 0
    for i, sample in enumerate(trace):
        now, value = float(sample['time_seconds']), float(sample['speed_3d_mps'])
        while pending and now > pending[0][2] + 1e-9:
            oid, ti, deadline = pending.popleft()
            rebuilt.append(('obligation_expired', i, now, value, oid, ti, deadline))
        if value <= r:
            while pending:
                oid, ti, deadline = pending.popleft()
                rebuilt.append(('obligation_recovered', i, now, value, oid, ti, deadline))
        if value > u:
            pending.append((ident, now, now+d))
            rebuilt.append(('obligation_triggered', i, now, value, ident, now, now+d))
            ident += 1
    assert not pending
    write_csv(out / 'fig9_all_N06_events_independent_536.csv', [dict(event_type=e[0],trace_index_0based=e[1],
        time_seconds=e[2],speed_3d_mps=e[3],obligation_id_internal_0based=e[4],trigger_time_seconds=e[5],deadline_seconds=e[6]) for e in rebuilt])

    # This N06 block starts at the recorded line in the multi-case ledger.
    first_line = config['ledger_first_line']
    selected = []
    for line, (kind, index, now, value, oid, triggered, due) in enumerate(rebuilt, first_line):
        if oid != 0 and not (kind == 'obligation_recovered' and now == 32.95):
            continue
        selected.append(dict(kind='observed_monitor_event', ledger_csv_line=line, event_type=kind,
                             obligation_id_internal_0based=oid, observed_trace_index_0based=index,
                             observed_time_seconds=str(now), observed_value_mps=str(value),
                             trigger_time_seconds=str(triggered), logical_deadline_seconds=str(due),
                             relation_to_O1='O1' if oid == 0 else 'later obligation, not O1'))
    selected.insert(1, dict(kind='derived_logical_deadline', ledger_csv_line='',event_type='logical_deadline',
                            obligation_id_internal_0based=0, observed_trace_index_0based='', observed_time_seconds='',
                            observed_value_mps='', trigger_time_seconds='26.2', logical_deadline_seconds='28.2',
                            relation_to_O1='O1; 26.2 + 2.0; not an observed expiry event'))
    write_csv(out / 'fig9_selected_event_provenance_38.csv', selected)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--official-archive', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='New local output directory')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Choose a new output directory')
    config = json.loads((BASE / 'reconstruction.json').read_text(encoding='utf-8'))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=args.output.parent) as work:
        out = Path(work) / 'extracts'
        out.mkdir()
        reconstruct(args.official_archive, out, config)
        for name, expected in config['output_sha256'].items():
            actual = hashlib.sha256((out / name).read_bytes()).hexdigest()
            if actual != expected:
                raise ValueError(f'{name}: expected {expected}, obtained {actual}')
        for name in ('figure9_speed_threshold_basis.csv', 'point_event_audit_receipt.json'):
            shutil.copyfile(BASE / name, out / name)
        out.rename(args.output)
    print('Verified all five regenerated CSV files against the archived SHA-256 values.')

if __name__ == '__main__':
    main()
