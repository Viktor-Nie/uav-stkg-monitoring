# Core validation and event checks

Use Python 3.11 or newer with pandas. The recorded run used Python 3.13.9
and pandas 2.3.3. Run `python -B -X utf8 reproduce.py` from the extracted
folder to reproduce the paired, compound, graph/CSV consistency and finite
event checks. The fixtures and expected results are included. The check
requires no network, external logs or language model. Generated results
are written into the extracted directory.

The historical checks are retained. The two added checks verify that the
graph and flat source-audit export match and that the original 17 finite
fixtures return the expected ordered event records at two clock origins.
