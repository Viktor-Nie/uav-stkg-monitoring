"""Check that the graph inspected at execution agrees with the source-audit export."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

import pandas as pd

from run_paired_checks import change_node, load_graph_checkers, load_module

FIELDS = {
    "binding_id", "formula_id", "template_id", "monitor_id", "signal_id", "role", "parameter_id", "value",
    "unit", "source_type", "source_reference", "source_version", "adoption_status", "platform_context",
    "vehicle_context", "flight_mode_context", "firmware_context", "applicability_status", "binding_version",
}


def check_views(snapshot, source_dir, binding_file, output):
    frozen, extension, _ = load_graph_checkers(snapshot)
    source = load_module("source_binding_verifier", source_dir / "source_binding_verifier.py")
    data = snapshot / "data"
    nodes = pd.read_csv(data / "frozen_graph_nodes.csv", dtype=str, keep_default_na=False)
    edges = pd.read_csv(data / "frozen_graph_relationships.csv", dtype=str, keep_default_na=False)
    bindings = pd.read_csv(binding_file, keep_default_na=False, float_precision="round_trip")
    if set(bindings.columns) != FIELDS:
        raise ValueError("flat binding export must supply all fields in the frozen schema")
    accepted = extension.validate_extended(nodes, edges)
    reconciled = source.run(binding_file)
    try:
        frozen.validate_flat_binding_export(nodes, edges, bindings)
        cross_view = {"matches": True}
    except (AssertionError, KeyError, TypeError, ValueError) as error:
        cross_view = {"matches": False, "reason": str(error)}
    results = {"graph_accepts": accepted["accepted"], "source_accepts": reconciled["status"] == "passed",
               "cross_view": cross_view}
    results["accepts"] = results["graph_accepts"] and results["source_accepts"] and cross_view["matches"]
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return results


def regression(root):
    snapshot = root / "snapshot/neo4j"
    source_dir = root / "source_audit"
    bindings = snapshot / "data/frozen_formula_parameter_bindings.csv"
    nodes = pd.read_csv(snapshot / "data/frozen_graph_nodes.csv", dtype=str, keep_default_na=False)
    threshold_ids = ("speed_3d_p99_train", "height_p99_train", "abs_roll_p99_train",
                     "abs_pitch_p99_train", "ang_rate_norm_p99_train")
    frozen, _, _ = load_graph_checkers(snapshot)
    properties = frozen.properties(nodes)
    controls, faults = [], []
    with TemporaryDirectory(prefix="kbs-view-check-") as temporary:
        work = Path(temporary)
        local_snapshot = work / "neo4j"
        shutil.copytree(snapshot, local_snapshot)
        local_nodes = local_snapshot / "data/frozen_graph_nodes.csv"
        result = work / "result.json"
        for i, parameter in enumerate(threshold_ids):
            key = f"parameter:{parameter}"
            control = nodes.sample(frac=1, random_state=i)
            control.to_csv(local_nodes, index=False)
            controls.append({"parameter": parameter, **check_views(local_snapshot, source_dir, bindings, result)})
            fault = control.copy()
            change_node(fault, key, value=properties[key]["value"] + .001)
            fault.to_csv(local_nodes, index=False)
            faults.append({"parameter": parameter, **check_views(local_snapshot, source_dir, bindings, result)})
    assert all(row["accepts"] for row in controls), controls
    assert all(row["graph_accepts"] and row["source_accepts"] and not row["accepts"]
               and row["cross_view"]["reason"] == "flat binding export differs in column value" for row in faults), faults
    report = {"binding_rows": len(pd.read_csv(bindings)), "tested_binding_fields": len(pd.read_csv(bindings, nrows=0).columns),
              "controls": controls, "faults": faults}
    (root / "binding_view_results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"{len(controls)} consistent exports accepted; {len(faults)} stale pairs rejected by cross-view comparison.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, help="Graph directory containing validator modules and data/")
    parser.add_argument("--source-audit", type=Path, help="Source verifier directory with source_inputs/")
    parser.add_argument("--bindings", type=Path, help="Flat binding CSV to compare")
    parser.add_argument("--output", type=Path, help="JSON receipt for the supplied snapshot")
    args = parser.parse_args()
    paths = (args.snapshot, args.source_audit, args.bindings, args.output)
    if any(paths):
        if not all(paths):
            parser.error("provide all four paths, or omit them to run the fixture regression")
        raise SystemExit(0 if check_views(*paths)["accepts"] else 1)
    regression(Path(__file__).resolve().parent)
