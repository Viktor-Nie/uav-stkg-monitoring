"""Check hand-enumerated finite-trace verdicts and event positions."""
from hashlib import sha256
from pathlib import Path
import json
import sys

import pandas as pd

HERE = Path(__file__).resolve().parent
MONITOR = HERE / "monitor"
sys.path.insert(0, str(MONITOR.parent))
from monitor import sampled_monitor as monitor

S = "satisfied"
V = "violated"
I = "inconclusive_end_of_trace"
R = "rejected_input_contract"
REC = "obligation_recovered"
EXP = "obligation_expired"
PEN = "obligation_pending_at_end"
INV = "invariant_violation"

# Each row fixes the expected result without calling any monitor or reference evaluator.
# Default response: trigger > 2, recovery <= 1, deadline 1 s, zero tolerance.
FIXTURES = [
    ("trigger_equality", "0 .5 1", "2 2 2", 0, S, []),
    ("recovery_equality_at_deadline", "0 .5 1", "3 1.5 1", 0, S, [(REC, 0, 2)]),
    ("recovery_just_after_deadline", "0 .5 1.000001", "3 1.5 1", 0, V, [(EXP, 0, 2)]),
    ("pending_at_deadline_equality", "0 .5 1", "3 1.5 1.5", 0, I, [(PEN, 0, 2)]),
    ("pending_before_deadline", "0 .5 .75", "3 1.5 1.5", 0, I, [(PEN, 0, 2)]),
    ("pending_at_final_trigger", "0 .5 1", "1.5 1.5 3", 0, I, [(PEN, 0, 2)]),
    ("dwell_completes_at_deadline", "0 .25 .5 1", "3 1.5 1 1", .5, S, [(REC, 0, 3)]),
    ("dwell_completes_late", "0 .25 .75 1.25", "3 1.5 1 1", .5, V, [(EXP, 0, 3)]),
    ("dwell_breaks", "0 .25 .5 .75 1 1.25", "3 1 1.5 1 1 1", .5, V, [(EXP, 0, 5)]),
    ("irregular_two_triggers", "0 .125 .875 1", "3 3 1.5 1", 0, S, [(REC, 0, 3), (REC, 1, 3)]),
    ("expiry_before_later_recovery", "0 .5 1.125", "3 3 1", 0, V, [(EXP, 0, 2), (REC, 1, 2)]),
    ("violation_with_pending", "0 .5 1.25", "3 1.5 3", 0, V, [(EXP, 0, 2), (PEN, 1, 2)]),
    ("missing_observation_gap", "0 .25 1.125", "3 1.5 1", 0, R, []),
    ("missing_value", "0 .5 1", "3 NaN 1", 0, R, []),
    ("duplicate_timestamp", "0 .5 .5", "3 1.5 1", 0, R, []),
    ("invariant_equality", "0 .25 .75", "2 1.5 2", None, S, []),
    ("invariant_exceedance", "0 .25 .75", "2 2.000001 2", None, V, [(INV, None, 1)]),
]

def run():
    contract = monitor.EventTimeObservationContract(.75, timestamp_epsilon_seconds=0)
    rows = []
    for name, times, values, dwell, verdict, events in FIXTURES:
        trace = pd.DataFrame({"time_seconds": times.split(), "signal": list(map(float, values.split()))})
        if dwell is None:
            got = monitor.monitor_invariant(trace, monitor.InvariantSpecification("signal", 2), contract)
        else:
            definition = monitor.BoundedResponseSpecification("signal", 2, 1, 1, dwell)
            got = monitor.monitor_bounded_response(trace, definition, contract)
        actual = [(e.event_type, e.obligation_id, e.observed_index) for e in got.events
                  if e.event_type != "obligation_triggered"]
        rows.append(dict(case=name, times=times, values=values, dwell=dwell, expected=verdict,
                         actual=got.verdict.value, expected_events=events, observed_events=actual,
                         contract_reasons=got.sampling_audit.reasons,
                         matched=actual == events and got.verdict.value == verdict))
    output = HERE / "boundary_verification.json"
    files = ("sampled_monitor.py", "_legacy_sampled_monitor.py", "sampled_data_contract.py", "timestamp_precision.py")
    proof = {
        "cases": len(rows), "matches": sum(row["matched"] for row in rows),
        "method": "manually enumerated verdict and event expectations, authored in this study",
        "source_sha256": {name: sha256((MONITOR / name).read_bytes()).hexdigest() for name in files},
        "rows": rows,
    }
    output.write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        if not row["matched"]:
            print(row)
    print(f"{proof['matches']}/{proof['cases']} verdict and event expectations matched")
    assert all(row["matched"] for row in rows)

if __name__ == "__main__":
    run()

