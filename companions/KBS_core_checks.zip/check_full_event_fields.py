"""Check complete event order and exact source coordinates for the 17 retained traces."""
from decimal import Decimal
import json
from pathlib import Path

import pandas as pd

from check_finite_cases import FIXTURES, EXP, INV, PEN, REC, monitor


# Tuples are (event kind, obligation ID, observation index, trigger index,
# recovery-start index). Expectations are listed independently of monitor output.
TRG = "obligation_triggered"
EXPECTED = {
    "trigger_equality": [],
    "recovery_equality_at_deadline": [(TRG, 0, 0, 0, None), (REC, 0, 2, 0, 2)],
    "recovery_just_after_deadline": [(TRG, 0, 0, 0, None), (EXP, 0, 2, 0, None)],
    "pending_at_deadline_equality": [(TRG, 0, 0, 0, None), (PEN, 0, 2, 0, None)],
    "pending_before_deadline": [(TRG, 0, 0, 0, None), (PEN, 0, 2, 0, None)],
    "pending_at_final_trigger": [(TRG, 0, 2, 2, None), (PEN, 0, 2, 2, None)],
    "dwell_completes_at_deadline": [(TRG, 0, 0, 0, None), (REC, 0, 3, 0, 2)],
    "dwell_completes_late": [(TRG, 0, 0, 0, None), (EXP, 0, 3, 0, None)],
    "dwell_breaks": [(TRG, 0, 0, 0, None), (EXP, 0, 5, 0, None)],
    "irregular_two_triggers": [(TRG, 0, 0, 0, None), (TRG, 1, 1, 1, None),
                              (REC, 0, 3, 0, 3), (REC, 1, 3, 1, 3)],
    "expiry_before_later_recovery": [(TRG, 0, 0, 0, None), (TRG, 1, 1, 1, None),
                                    (EXP, 0, 2, 0, None), (REC, 1, 2, 1, 2)],
    "violation_with_pending": [(TRG, 0, 0, 0, None), (EXP, 0, 2, 0, None),
                               (TRG, 1, 2, 2, None), (PEN, 1, 2, 2, None)],
    "missing_observation_gap": [],
    "missing_value": [],
    "duplicate_timestamp": [],
    "invariant_equality": [],
    "invariant_exceedance": [(INV, None, 1, None, None)],
}


def to_decimal(value):
    return None if value is None else Decimal(value)


def verify():
    contract = monitor.EventTimeObservationContract(.75, timestamp_epsilon_seconds=0)
    results = []
    assert set(EXPECTED) == {fixture[0] for fixture in FIXTURES}
    # Absolute timestamps are supplied as decimal strings. The second epoch
    # also exercises origin subtraction and exact restoration of event times.
    for origin in (Decimal(0), Decimal("1760000000.000000123")):
        for name, raw_times, raw_values, dwell, verdict, previous_events in FIXTURES:
            times = [origin + Decimal(t) for t in raw_times.split()]
            values = [float(value) for value in raw_values.split()]
            trace = pd.DataFrame({"time_seconds": [str(t) for t in times], "signal": values})
            if dwell is None:
                result = monitor.monitor_invariant(trace, monitor.InvariantSpecification("signal", 2), contract)
            else:
                spec = monitor.BoundedResponseSpecification("signal", 2, 1, 1, dwell)
                result = monitor.monitor_bounded_response(trace, spec, contract)
            assert result.verdict.value == verdict, (name, origin, result.verdict)
            expected = EXPECTED[name]
            assert [(kind, obligation, observed) for kind, obligation, observed, _, _ in expected
                    if kind != TRG] == previous_events, name
            assert len(result.absolute_event_records) == len(expected), (name, origin)
            for record, (kind, obligation, observed, trigger, recovery) in zip(result.absolute_event_records, expected, strict=True):
                actual = (record["event_type"], record["obligation_id"], record["observed_index"], record["trigger_index"],
                          to_decimal(record["absolute_observed_time_seconds_decimal"]),
                          to_decimal(record["absolute_trigger_time_seconds_decimal"]),
                          to_decimal(record["absolute_deadline_time_seconds_decimal"]),
                          to_decimal(record["absolute_recovery_segment_start_seconds_decimal"]), record["observed_value"])
                wanted = (kind, obligation, observed, trigger, times[observed],
                          None if trigger is None else times[trigger],
                          None if trigger is None else times[trigger] + 1,
                          None if recovery is None else times[recovery], values[observed])
                assert actual == wanted, (name, origin, actual, wanted)
            results.append({"fixture": name, "origin_seconds": str(origin), "verdict": verdict,
                            "events": expected})
    count = sum(len(row["events"]) for row in results)
    output = {"distinct_fixtures": len(FIXTURES), "runs": len(results), "event_rows_checked": count, "details": results}
    Path(__file__).with_name("full_event_fields_results.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(f"All {len(results)} verdicts and {count} ordered event rows match the enumerated references.")


if __name__ == "__main__":
    verify()
