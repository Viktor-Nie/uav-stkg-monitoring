from pathlib import Path
import csv
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
for command in (
    ["run_paired_checks.py", "--snapshot", "snapshot", "--source-audit", "source_audit",
     "--output", "recheck"],
    ["check_combined_faults.py"],
    ["check_finite_cases.py"],
):
    subprocess.run([sys.executable, "-B", "-X", "utf8", *command], cwd=root, check=True)
for name in ("excluded_alternatives.csv", "fixture_inventory.csv", "matched_pairs.csv", "summary.csv"):
    assert (root / "recheck" / name).read_bytes() == (root / "reference" / name).read_bytes(), name
receipt = json.loads((root / "recheck/receipt.json").read_text(encoding="utf-8"))
reference = json.loads((root / "reference/receipt.json").read_text(encoding="utf-8"))
assert receipt == reference
with (root / "reference/fixture_inventory.csv").open(newline="", encoding="utf-8") as stream:
    assert len(list(csv.DictReader(stream))) == 76
for name in ("combined_fault_verification.json", "boundary_verification.json"):
    result = json.loads((root / name).read_text(encoding="utf-8"))
    baseline = json.loads((root / "reference" / name).read_text(encoding="utf-8"))
    # Paths to the inputs are relative to this portable bundle.
    if "inputs_sha256" in result:
        assert sorted(result.pop("inputs_sha256").values()) == sorted(baseline.pop("inputs_sha256").values())
    assert result == baseline, name
print("76 single-fault pairs, nine compound pairs and 17 finite traces match the retained records.")

for name in ("check_binding_views.py", "check_full_event_fields.py"):
    subprocess.run([sys.executable, "-B", "-X", "utf8", name], cwd=root, check=True)
    evidence = {"check_binding_views.py": "binding_view_results.json",
                "check_full_event_fields.py": "full_event_fields_results.json"}[name]
    assert (root / evidence).read_bytes() == (root / "reference" / evidence).read_bytes(), evidence
