"""Run constructed compound configuration faults and legal reorder controls."""
from hashlib import sha256
from pathlib import Path
import csv
import json
import tempfile

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE
PAIRED = HERE / "reference"
SNAPSHOT = HERE / "snapshot"
SOURCE_AUDIT = HERE / "source_audit"
from run_paired_checks import change_node, load_graph_checkers, load_module, rebind

def inputs(snapshot):
    base = snapshot / "neo4j/data"
    n = pd.read_csv(base / "frozen_graph_nodes.csv", dtype=str, keep_default_na=False)
    e = pd.read_csv(base / "frozen_graph_relationships.csv", dtype=str, keep_default_na=False)
    b = pd.read_csv(base / "frozen_formula_parameter_bindings.csv")
    return n, e, b

def run():
    frozen, extension, _ = load_graph_checkers(SNAPSHOT / "neo4j")
    source = load_module("source_binding_verifier", SOURCE_AUDIT / "source_binding_verifier.py")
    nodes, edges, bindings = inputs(SNAPSHOT)
    meta = frozen.properties(nodes)
    cases = []
    with (PAIRED / "fixture_inventory.csv").open(newline="", encoding="utf-8") as stream:
        inventory = list(csv.DictReader(stream))
    candidates = [r for r in inventory if r["check"] == "signal_scope" and
                  r["site"].endswith(":upper_bound")]
    for i, candidate in enumerate(candidates):
        row = next(r for r in bindings.itertuples(index=False) if r.binding_id == candidate["site"])
        wrong_signal = candidate["alternative"]
        wrong_pointer = source.RUNTIME_REF
        assert meta[wrong_signal]["source_reference"] != wrong_pointer
        permuted = (nodes.sample(frac=1, random_state=i).reset_index(drop=True),
                    edges.sample(frac=1, random_state=i+100).reset_index(drop=True),
                    bindings.sample(frac=1, random_state=i+200).reset_index(drop=True))
        faulty = rebind(*permuted, row, wrong_signal, meta[wrong_signal])
        n, e, b = faulty
        change_node(n, wrong_signal, source_reference=wrong_pointer)
        b.loc[b["parameter_id"] == wrong_signal.removeprefix("parameter:"), "source_reference"] = wrong_pointer
        cases.append((row.binding_id, "signal_and_pointer", permuted, faulty))

    for candidate in (r for r in inventory if r["check"] == "source_pointer"):
        if not candidate["site"].endswith("_p99_train"):
            continue
        parameter = candidate["site"]
        affected = parameter.removeprefix("parameter:")
        n, e, b = nodes.copy(), edges.copy(), bindings.copy()
        value = meta[parameter]["value"]
        # A small positive change to an upper threshold keeps the numerical order.
        new_value = value + .001
        change_node(n, parameter, source_reference=candidate["alternative"], value=new_value)
        b.loc[b["parameter_id"] == affected, "source_reference"] = candidate["alternative"]
        b.loc[b["parameter_id"] == affected, "value"] = new_value
        cases.append((affected, "value_and_pointer", (nodes, edges, bindings), (n,e,b)))

    results = []
    with tempfile.TemporaryDirectory(prefix="v79-compound-") as tmp:
        input_csv = Path(tmp) / "bindings.csv"
        for name, kind, control, fault in cases:
            for side, (n,e,b) in (("legal", control), ("fault", fault)):
                graph = extension.validate_extended(n,e)
                b.to_csv(input_csv, index=False)
                upstream = source.run(input_csv)
                graph_ok, source_ok = graph["accepted"], upstream["status"] == "passed"
                results.append(dict(id=name, kind=kind, side=side, graph=graph_ok, source=source_ok,
                                    combined=graph_ok and source_ok, graph_errors=graph["errors"],
                                    source_errors=upstream["errors"]))
    for row in results:
        print(row["kind"],row["id"],row["side"],row["graph"],row["source"])
        assert row["combined"] == (row["side"] == "legal"), row
    assert cases and len({c[1] for c in cases}) == 2
    inputs_hashes = {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in
                     [PAIRED / "fixture_inventory.csv", HERE / "run_paired_checks.py",
                      SNAPSHOT / "neo4j/frozen_validator_reference.py", SNAPSHOT / "neo4j/validation_extension.py",
                      SOURCE_AUDIT / "source_binding_verifier.py"]}
    report = dict(pairs=len(cases), inputs_sha256=inputs_hashes, rows=results)
    (HERE / "combined_fault_verification.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")

if __name__ == "__main__":
    run()

