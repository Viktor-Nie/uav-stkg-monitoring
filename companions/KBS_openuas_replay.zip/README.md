# OpenUAS research requirement replay

OpenUAS Version 1.0, Section V.C, Figures 11-13.
https://doi.org/10.1109/ICUAS51884.2021.9476814

Download the authors' 18_57_19.ulg file from the fixed revision below.
https://media.githubusercontent.com/media/Open-UAS/Open-UAS.github.io/16c560e0c18cc02337851c9188c7b757b73d715c/docs/Legacy/Flight_Procedures/Flight_Logs/2020-11-13/18_57_19.ulg

With Python and pyulog 1.2.2, run

    python -B replay_openuas.py 18_57_19.ulg receipt.json

Compare receipt.json to openuas_replay_receipt.json. The verifier checks the
source file against the LFS SHA-256 and uses native integer microsecond times.
