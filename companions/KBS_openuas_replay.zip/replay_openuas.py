"""Recheck the OpenUAS altitude acquisition example on the published native log."""

from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from hashlib import sha256
from pathlib import Path
import json

from pyulog import ULog


COMMIT = "16c560e0c18cc02337851c9188c7b757b73d715c"
MEMBER = "docs/Legacy/Flight_Procedures/Flight_Logs/2020-11-13/18_57_19.ulg"
SHA256 = "f165ccddb2f74349770c63b2fd319d5c4277c954baa34962c809fb54265899db"
FIRMWARE = "9fcbf18d82b84ac57ee13782b3e501fa077d4d97"
TARGET_M = 300
DEADLINES_S = (10, 15)


def records(log, topic, field):
    data = log.get_dataset(topic).data
    times = list(map(int, data["timestamp"]))
    assert all(first < second for first, second in zip(times, times[1:]))
    return times, data[field].tolist()


def check_altitude(times, heights, scale, anchor):
    first = bisect_left(times, anchor)
    witness = next((i for i in range(first, len(times)) if heights[i] > TARGET_M * scale), None)
    assert witness is not None and witness > first
    result = {"rows": len(times), "seconds_from_anchor": (times[witness] - anchor) / 1_000_000,
              "verdicts": {}}
    for key, index in (("last_at_or_below_threshold", witness - 1), ("first_above_threshold", witness)):
        result[key] = {"row": index + 1, "timestamp_us": times[index], "altitude_msl_m": heights[index] / scale}
    for seconds in DEADLINES_S:
        deadline = anchor + seconds * 1_000_000
        through = bisect_right(times, deadline)
        assert first < through < len(times)
        result["verdicts"][str(seconds)] = {
            "deadline_us": deadline, "verdict": "satisfied" if witness < through else "violated",
            "last_observation_before_or_at_deadline_us": times[through - 1],
            "first_observation_after_deadline_us": times[through],
        }
    return result


def replay(path):
    payload = path.read_bytes()
    digest = sha256(payload).hexdigest()
    assert len(payload) == 9_972_638 and digest == SHA256
    log = ULog(str(path), ["vehicle_land_detected", "vehicle_gps_position", "vehicle_global_position"])
    assert log.msg_info_dict["ver_sw"] == FIRMWARE
    times, landed = records(log, "vehicle_land_detected", "landed")
    edges = [i for i in range(1, len(times)) if landed[i - 1] and not landed[i]]
    assert len(edges) == 1
    takeoff = edges[0]
    anchors = {"first_not_landed": times[takeoff], "last_landed": times[takeoff - 1]}
    signals = {"vehicle_gps_position.alt": 1000, "vehicle_global_position.alt": 1}
    results = {}
    for channel, scale in signals.items():
        observations, heights = records(log, channel.split(".")[0], "alt")
        results[channel] = {name: check_altitude(observations, heights, scale, anchor)
                            for name, anchor in anchors.items()}
    assert all({key: value["verdict"] for key, value in item["verdicts"].items()}
               == {"10": "violated", "15": "satisfied"}
               for channel in results.values() for item in channel.values())
    return {
        "paper_doi": "10.1109/ICUAS51884.2021.9476814", "paper_location": "Section V.C, Figures 11-13",
        "source_commit": COMMIT, "source_member": MEMBER, "source_sha256": digest, "firmware_commit": FIRMWARE,
        "target": "altitude > 300 m above mean sea level", "start_event": "vehicle_land_detected.landed: true to false",
        "method": "Native integer-microsecond sample times. No interpolation. The window is inclusive at the deadline.",
        "scope": "Published takeoff-to-altitude example. The trigger is the discrete takeoff event.",
        "land_detector_rows": len(times),
        "takeoff": {"last_landed_row": takeoff, "last_landed_us": times[takeoff - 1],
                    "first_not_landed_row": takeoff + 1, "first_not_landed_us": times[takeoff]},
        "results": results,
    }


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(replay(args.source), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
