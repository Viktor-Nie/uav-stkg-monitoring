# External replay event provenance

The audit starts with the frozen verified-v34 profile reproduced by public software release v35, commit `640a0f8b09a38b7c3b14e3c38b63cc37411431df`. It checks the three external event-time replay routes against their archived inputs. The existing 864-event RflyMAD native-coordinate audit is separate.

## Results

| Route | Recomputed signal observations | Event observations located | Trigger coordinates | Recovery-start coordinates | Distinct native records across the three coordinate roles |
| --- | ---: | ---: | ---: | ---: | ---: |
| PX4 Flight Review | 6,774 | 88 | 66 | 0 | 12 |
| IDF_DS | 25,783 | 27,250 | 18,504 | 885 | 3,198 |
| INSANE | 62,135 | 8 | 6 | 3 | 2 |
| Total | 94,692 | 27,346 | 18,576 | 888 | 3,212 |

For each event, the observed sample index and exact retained decimal time identify the same replay observation. The logged value agrees with the reconstructed observation value within an absolute tolerance of `2e-14`. Trigger coordinates also resolve to the corresponding obligation's trigger event. Recovery-start coordinates resolve by exact retained time on the same strictly ordered observation stream. Logical deadline times are arithmetic boundaries, so the audit only maps timestamps recorded as observations, triggers or recovery starts.

The audit re-reads the authenticated inputs and independently recalculates all retained signal values using standard-library norms and quaternion formulas. Maximum event-value differences against these raw recalculations are `1.78e-15` for Flight Review, `7.11e-15` for IDF_DS and `8.89e-16` for INSANE, in their respective signal units. The CSV and the JSON receipt summarize replay bookkeeping and reuse of raw records. Physical fault counts, sensor ground truth, between-observation behavior and flight safety limits require separate evidence.

## Coordinate definitions

- **Flight Review.** The ULog UUID and SHA identify the file. The native coordinates are topic name, instance 0, zero-based decoded topic record index and integer `timestamp_sample` in microseconds. Attitude uses `q[0]` through `q[3]`, normalized before Euler conversion. Angular rate uses the norm of `xyz[0]` through `xyz[2]`. The coordinate reaches the decoded ULog record. Binary byte offsets and a physical attitude reference frame were outside this audit.
- **IDF_DS.** The v35 repository includes the three complete official `lap_120` CSV members from `Holybro Pixhawk.zip`, with attribution. Each member's SHA, CRC and size are matched to the source manifest. The coordinates are member path, one-based source CSV line (header is line 1) and integer PX4 `timestamp` in microseconds. Speed uses `vx`, `vy`, `vz`; attitude uses `q[0]` through `q[3]` in the historical unnormalized conversion; rate uses `xyz[0]` through `xyz[2]`. This resolves to the published topic CSV exports.
- **INSANE.** The recorded SHA pins the exact compressed member range; local ZIP header, central-directory name/size/CRC, and the inflated CRC are checked. Native coordinates use the one-based source CSV line and original text of `t` in seconds. The norm uses `w_x`, `w_y`, `w_z`. The retained replay's epoch timestamp and elapsed timestamp differ from the independent float reconstruction by at most `2.384185791015625e-7 s`, one binary64 ULP at the epoch scale. Record identity is checked by row order plus timestamp and recomputed value, with the raw timestamp text preserved.

## Reproduction

Use Python 3.10 or newer with Git and `pyulog==1.2.2` installed. The script uses only the standard library and pyulog and makes no network requests. Place an unmodified v35 checkout at `V35`, and obtain the required flight inputs and the verified-v34 replay using `research/real_replay/SOURCE_INPUTS.md` at that checkout. The archive-level rerun command is `python V35/research/real_replay/reproduce_real_replays.py --input-root EXTERNAL_ROOT --output REPLAY_ROOT`. Use the frozen `verified_v34` profile, which is its default.

```text
python -B -X utf8 audit_external_lineage.py --checkout V35 --input-root EXTERNAL_ROOT --replay REPLAY_ROOT --insane-archive-index ORIGINAL_INDOOR_1_SENSORS_ZIP --output NEW_AUDIT
```

The v35 preparation script provides the required INSANE compressed member range and other raw inputs. `--insane-archive-index` can point either to the full original INSANE sensor ZIP or to its retained central-directory tail. If the tail is present as `EXTERNAL_ROOT/external_datasets/insane/indoor_1_sensors_tail.bin`, the option can be omitted. The IDF input directory is read from the pinned checkout. The full replay output used here matches the frozen event-ledger SHA `0f3622278edf2b026368003baea9e8bcea1328e0b8b90e3bf7b9d6f1ee31d3ba`. Each reconstructed table hash and each consumed raw-input hash is separately listed in `external_lineage_receipt.json`. The expected coordinate CSV SHA is `30819cc104e60744c404d80f197c6384fdc64ad8f795287098855375224b48f1` and contains 46,810 coordinate rows.

The distributable audit package includes the script, this method and the summary receipt. The detailed coordinate CSV is generated on demand from authorized source inputs. The package contains no raw telemetry, replay traces, detailed source-coordinate table or ZIP members. For source access and reuse conditions consult the published records.

[Pinned implementation and acquisition instructions](https://github.com/Viktor-Nie/uav-stkg-monitoring/blob/640a0f8b09a38b7c3b14e3c38b63cc37411431df/research/real_replay/SOURCE_INPUTS.md) · [Flight Review log](https://review.px4.io/plot_app?log=0000c079-6820-409a-95da-e86358b6c20f) · [IDF_DS release](https://doi.org/10.5281/zenodo.16992976) · [INSANE source](https://www.aau.at/en/smart-systems-technologies/control-of-networked-systems/datasets/insane-dataset/)
