"""Locate frozen external replay events in native inputs using an independent join."""

import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass
from decimal import Decimal
from hashlib import sha256
from importlib.metadata import version
import io
import json
import math
from pathlib import Path
import struct
import subprocess
import zipfile
import zlib


V35 = "640a0f8b09a38b7c3b14e3c38b63cc37411431df"
FLIGHT_PATH = "datasets/v2_px4_flight_review/0000c079-6820-409a-95da-e86358b6c20f.ulg"
INSANE_DIR = "external_datasets/insane"
INSANE_MEMBER = "indoor_1_sensors/px4_imu.csv"
SOURCES = {
    "FlightReview": ("external_flight_review_event_time_signal_observations.csv", "source_timestamp_sample_us"),
    "IDF_DS": ("idf_ds_lap120_event_time/native_signal_observations.csv", "timestamp_us"),
    "INSANE": ("insane_indoor1_px4_imu_event_time/native_signal_observations.csv", "source_timestamp_seconds"),
}
QUATERNION = tuple(f"q[{i}]" for i in range(4))
RATE = tuple(f"xyz[{i}]" for i in range(3))
SPEED = ("vx", "vy", "vz")
IMU = ("w_x", "w_y", "w_z")
NATIVE_VALUE_ATOL = 2e-12
EVENT_VALUE_ATOL = 2e-14


@dataclass(frozen=True)
class Native:
    member: str
    topic: str
    index: int
    csv_line: int | None
    timestamp_field: str
    timestamp: str
    fields: tuple[str, ...]
    value: float


def require(condition, description):
    if not condition:
        raise ValueError(description)


def checked_bytes(path, expected):
    data = path.read_bytes()
    require(sha256(data).hexdigest() == expected, f"SHA-256 mismatch: {path}")
    return data


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def csv_rows(payload):
    with io.StringIO(payload.decode("utf-8-sig"), newline="") as stream:
        reader = csv.DictReader(stream, skipinitialspace=True)
        for row in reader:
            require(None not in row and None not in row.values(), f"Invalid CSV line {reader.line_num}")
            yield reader.line_num, {key.strip(): value.strip() for key, value in row.items()}


def angles(values, normalize):
    w, x, y, z = (float(value) for value in values)
    if normalize:
        length = math.hypot(w, x, y, z)
        w, x, y, z = (value / length for value in (w, x, y, z))
    sine = 2 * (w * y - z * x)
    return {
        "abs_roll_rad": abs(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))),
        "abs_pitch_rad": abs(math.asin(max(-1, min(1, sine)))),
    }


def flight_records(root, sources):
    from pyulog import ULog

    item, = sources["FlightReview"]["inputs"]
    require(item["path"] == FLIGHT_PATH, "Unexpected Flight Review source")
    path = root / FLIGHT_PATH
    checked_bytes(path, item["sha256"])
    log = ULog(str(path))
    output = defaultdict(list)
    timestamps = {}
    for topic, fields in (("vehicle_attitude", QUATERNION), ("vehicle_angular_velocity", RATE)):
        dataset, = [x for x in log.data_list if x.name == topic and x.multi_id == 0]
        data = dataset.data
        timestamps[topic] = [int(t) for t in data["timestamp_sample"]]
        require(len(set(timestamps[topic])) == len(timestamps[topic]), f"Duplicate ULog sample in {topic}")
        for index, timestamp in enumerate(timestamps[topic]):
            values = [float(data[field][index]) for field in fields]
            signals = angles(values, normalize=True) if fields == QUATERNION else {"ang_rate_norm_rps": math.hypot(*values)}
            for signal, value in signals.items():
                output[signal].append(Native(path.name, topic, index, None, "timestamp_sample", str(timestamp), fields, value))
    return output, timestamps["vehicle_attitude"][0], {path.name: item["sha256"]}


def idf_records(checkout, sources):
    directory = checkout / "data/external/idf_ds_lap120_verified_v34"
    manifest = read_json(directory / "source_acquisition_manifest.json")
    output = defaultdict(list)
    hashes = {}
    for member in manifest["members"]:
        name = member["local_file"]
        topic = name.removesuffix("_0.csv")
        fields, norm_signal = {
            "vehicle_local_position": (SPEED, "speed_3d_mps"),
            "vehicle_angular_velocity": (RATE, "ang_rate_norm_rps"),
            "vehicle_attitude": (QUATERNION, None),
        }[topic]
        expected = sources["IDF_DS"]["source_files_sha256"][name]
        payload = checked_bytes(directory / name, expected)
        require(expected == member["sha256"] and len(payload) == member["zip_uncompressed_bytes"] and
                f"{zlib.crc32(payload):08x}" == member["zip_crc32"], f"IDF member mismatch: {name}")
        hashes[member["archive_member"]] = expected
        timestamps = []
        for index, (line, row) in enumerate(csv_rows(payload)):
            timestamp = int(row["timestamp"])
            timestamps.append(timestamp)
            values = tuple(float(row[field]) for field in fields)
            require(all(map(math.isfinite, values)), f"Incomplete IDF source row: {name}:{line}")
            signals = angles(values, normalize=False) if norm_signal is None else {norm_signal: math.hypot(*values)}
            for signal, value in signals.items():
                output[signal].append(Native(member["archive_member"], topic, index, line, "timestamp", str(timestamp), fields, value))
        require(all(a < b for a, b in zip(timestamps, timestamps[1:])), f"Nonmonotonic IDF source: {name}")
    return output, min(int(rows[0].timestamp) for rows in output.values()), hashes


def insane_records(root, sources, archive_index):
    directory = root / INSANE_DIR
    member = sources["INSANE"]["member_range"]
    path = directory / member["path"]
    raw = checked_bytes(path, member["sha256"])
    signature, _, flags, method, _, _, crc, compressed, size, name_length, extra_length = struct.unpack_from("<4s5H3I2H", raw)
    name = raw[30:30 + name_length].decode("utf-8")
    require(signature == b"PK\x03\x04" and flags == 0 and method == zipfile.ZIP_DEFLATED and
            name == INSANE_MEMBER == member["zip_member"], "Unexpected INSANE local ZIP header")
    with zipfile.ZipFile(archive_index) as archive:
        info = archive.getinfo(name)
        require((info.CRC, info.compress_size, info.file_size) == (crc, compressed, size), "INSANE central directory mismatch")
    require(f"{crc:08x}" == member["zip_member_crc32"] and compressed == member["zip_member_compressed_size"]
            and size == member["zip_member_uncompressed_size"], "INSANE frozen member metadata mismatch")
    data = raw[30 + name_length + extra_length:]
    payload = zlib.decompress(data, -15)
    require(len(data) == compressed and len(payload) == size and zlib.crc32(payload) == crc, "INSANE CRC or length mismatch")
    output = []
    for index, (line, row) in enumerate(csv_rows(payload)):
        value = math.hypot(*(float(row[field]) for field in IMU))
        output.append(Native(name, "px4_imu", index, line, "t", row["t"], IMU, value))
    require(all(Decimal(a.timestamp) < Decimal(b.timestamp) for a, b in zip(output, output[1:])), "Nonmonotonic INSANE source")
    return {"ang_rate_norm_rps": output}, float(output[0].timestamp), {path.name: member["sha256"], name: sha256(payload).hexdigest()}


def observations(source, payload, native, origin):
    """Compare every retained observation against raw values and its native clock."""
    result = defaultdict(list)
    positions = {}
    maximum = {"value_error": 0.0, "source_timestamp_error_seconds": 0.0, "observation_time_error_seconds": 0.0}
    timestamp_column = SOURCES[source][1]
    for signal, records in native.items():
        for record in records:
            key = (signal, record.timestamp) if source != "INSANE" else (signal, record.index)
            require(key not in positions, f"Duplicate native record key: {source}:{key}")
            positions[key] = record
    for line, row in csv_rows(payload):
        signal = row["signal_id"]
        index = len(result[signal])
        key = (signal, row[timestamp_column]) if source != "INSANE" else (signal, index)
        record = positions.pop(key)
        require(row.get("source_topic", record.topic) == record.topic, f"Topic mismatch: {source}:{line}")
        time = Decimal(row["time_seconds"])
        if source == "INSANE":
            raw_time = float(record.timestamp)
            raw_error = abs(float(row[timestamp_column]) - raw_time)
            time_error = abs(float(time) - (raw_time - origin))
            require(raw_error <= math.ulp(raw_time) and time_error <= math.ulp(raw_time) + math.ulp(origin),
                    f"INSANE timestamp mismatch: {line}")
            maximum["source_timestamp_error_seconds"] = max(maximum["source_timestamp_error_seconds"], raw_error)
            maximum["observation_time_error_seconds"] = max(maximum["observation_time_error_seconds"], time_error)
        else:
            require(time * 1_000_000 == int(record.timestamp) - origin, f"Microsecond clock mismatch: {source}:{line}")
        error = abs(float(row["value"]) - record.value)
        require(error <= NATIVE_VALUE_ATOL, f"Native value mismatch: {source}:{line}: {error}")
        maximum["value_error"] = max(maximum["value_error"], error)
        require(not result[signal] or time > result[signal][-1][1], f"Nonmonotonic retained trace: {source}:{line}")
        result[signal].append((line, time, float(row["value"]), record))
    require(not positions, f"Unmapped native records: {source}")
    return result, maximum


def integer(text):
    number = Decimal(text)
    require(number == int(number), f"Noninteger coordinate: {text}")
    return int(number)


def event_observation(stream, index, time):
    position = integer(index)
    require(0 <= position < len(stream), f"Event coordinate outside retained trace: {position}")
    row = stream[position]
    require(row[1] == Decimal(time), f"Event time and index identify different observations: {position}, {time}")
    return row


def event_key(event):
    return tuple(event[field] for field in ("source", "case_id", "formula_id", "signal_id", "obligation_id"))


def event_rows(event_payload, streams):
    all_events = list(csv_rows(event_payload))
    external = [(line, event) for line, event in all_events if event["source"] in SOURCES]
    triggers = {}
    for _, event in external:
        if event["event_type"] == "obligation_triggered":
            key = event_key(event)
            require(key not in triggers, f"Duplicate trigger identity: {key}")
            triggers[key] = event["observed_index"], event["absolute_observed_time_seconds_decimal"]
    clock_indices = {(source, signal): {row[1]: str(index) for index, row in enumerate(trace)}
                     for source, signals in streams.items() for signal, trace in signals.items()}
    for line, event in external:
        source, signal = event["source"], event["signal_id"]
        trace = streams[source][signal]
        observed = event_observation(trace, event["observed_index"], event["absolute_observed_time_seconds_decimal"])
        require(abs(float(event["observed_value"]) - observed[2]) <= EVENT_VALUE_ATOL, f"Event value mismatch: {line}")
        coordinates = {"observed": observed}
        if event["trigger_index"]:
            index = str(integer(event["trigger_index"]))
            time = event["absolute_trigger_time_seconds_decimal"]
            require((index, time) == triggers[event_key(event)], f"Trigger and event disagree: {line}")
            coordinates["trigger"] = event_observation(trace, index, time)
        if event["absolute_recovery_segment_start_seconds_decimal"]:
            time = event["absolute_recovery_segment_start_seconds_decimal"]
            index = clock_indices[(source, signal)][Decimal(time)]
            recovery = event_observation(trace, index, time)
            require(coordinates["trigger"][1] < recovery[1] <= observed[1], f"Recovery chronology mismatch: {line}")
            coordinates["recovery_start"] = recovery
        yield line, event, coordinates


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("checkout", "input-root", "replay", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--insane-archive-index", type=Path, help="Original indoor_1_sensors.zip or its central-directory tail")
    args = parser.parse_args()
    commit = subprocess.check_output(["git", "-C", str(args.checkout), "rev-parse", "HEAD"], text=True).strip()
    require(commit == V35, "Use the frozen v35 Git commit")
    frozen = read_json(args.checkout / "research/real_replay/verified_four_source_reference.json")
    raw_sources = frozen["raw_sources"]
    archive_index = args.insane_archive_index or args.input_root / INSANE_DIR / "indoor_1_sensors_tail.bin"
    cases = {"FlightReview": flight_records(args.input_root, raw_sources), "IDF_DS": idf_records(args.checkout, raw_sources),
             "INSANE": insane_records(args.input_root, raw_sources, archive_index)}
    streams, summary = {}, {}
    for source, (native, origin, hashes) in cases.items():
        file = SOURCES[source][0]
        payload = checked_bytes(args.replay / "reconstructed/specification/v2/results" / file, frozen["derived_sha256"][file])
        streams[source], errors = observations(source, payload, native, origin)
        summary[source] = {"native_inputs_sha256": hashes, "reconstructed_observation_csv_sha256": frozen["derived_sha256"][file],
                           "observations_by_signal": {signal: len(rows) for signal, rows in streams[source].items()}, "maximum_errors": errors}
    event_file = "fresh_monitor_events.csv"
    event_sha = frozen["fresh_output_sha256"][event_file]
    event_payload = checked_bytes(args.replay / event_file, event_sha)
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    counts, types = defaultdict(Counter), defaultdict(Counter)
    event_errors = defaultdict(float)
    distinct = defaultdict(set)
    with (output / "external_event_native_coordinates.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("ledger_csv_line", "source", "formula_id", "signal_id", "event_type", "obligation_id",
                         "coordinate_role", "reconstructed_csv_line", "observation_time_seconds", "native_member", "native_topic",
                         "ulog_instance", "native_record_index_zero_based", "native_csv_line_one_based", "native_timestamp_field",
                         "native_timestamp", "value_source_fields"))
        for line, event, coordinates in event_rows(event_payload, streams):
            source = event["source"]
            types[source][event["event_type"]] += 1
            original_value = coordinates["observed"][3].value
            event_errors[source] = max(event_errors[source], abs(float(event["observed_value"]) - original_value))
            for role, (observation_line, time, _, record) in coordinates.items():
                counts[source][role] += 1
                distinct[source].add((record.member, record.topic, record.index))
                writer.writerow((line, source, event["formula_id"], event["signal_id"], event["event_type"], event["obligation_id"],
                                 role, observation_line, time, record.member, record.topic, 0 if source == "FlightReview" else "",
                                 record.index, record.csv_line, record.timestamp_field, record.timestamp, " ".join(record.fields)))
    for source, row in summary.items():
        require(counts[source]["observed"] == frozen["fresh_replay"]["source_counts"][source]["events"], f"Event coverage mismatch: {source}")
        row.update(coordinates=dict(counts[source]), event_types=dict(types[source]), distinct_native_records=len(distinct[source]))
        row["maximum_errors"]["event_value_vs_recomputed_native"] = event_errors[source]
    coordinate_file = output / "external_event_native_coordinates.csv"
    receipt = {"status": "passed", "commit": commit, "pyulog_version": version("pyulog"), "event_csv_sha256": event_sha,
               "coordinate_csv_sha256": sha256(coordinate_file.read_bytes()).hexdigest(), "sources": summary,
               "external_observed_events": sum(row["observed"] for row in counts.values()),
               "external_trigger_coordinates": sum(row["trigger"] for row in counts.values()),
               "external_recovery_start_coordinates": sum(row["recovery_start"] for row in counts.values()),
               "coordinate_row_count": sum(sum(row.values()) for row in counts.values()),
               "tolerances": {"native_value_absolute": NATIVE_VALUE_ATOL, "ledger_value_absolute": EVENT_VALUE_ATOL,
                              "insane_source_timestamp": "one binary64 ULP of source epoch timestamp",
                              "insane_observation_time": "sum of the binary64 ULPs at source and origin"},
               "input_contract": "ULog SHA, IDF archive member SHA/CRC/size, and INSANE local segment SHA plus central-directory member CRC/size",
               "output_contract": "native source coordinates in the retained replay, not physical event or calibrated safety measurements"}
    (output / "external_lineage_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
