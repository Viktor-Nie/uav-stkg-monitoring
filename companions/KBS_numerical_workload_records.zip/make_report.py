"""Read new frozen results and emit bounded paper-ready tables and checks."""
from collections import Counter
import csv
import hashlib
import itertools
import json
from pathlib import Path
import statistics

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,obj):
    with Path(path).open('x',encoding='utf-8') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.write('\n')


def main():
    protocol=load(HERE/'protocol_before_runs.json')
    for rel,h in protocol['input_sha256'].items():
        assert sha(HERE/rel)==h,rel
    for rel,h in protocol['read_only_source_sha256'].items():
        assert sha(ROOT/rel)==h,rel
    cases=load(HERE/'inputs/A_cases.json')
    assert len(cases)==648 and len({c['case_id'] for c in cases})==648
    cells={(c['rule']['deadline'],c['rule']['dwell'],c['rule']['value_epsilon'],c['origin'],c['pattern']) for c in cases}
    expected=set(itertools.product(('0.2','0.5','2.0'),('0','0.05','0.15'),('0','0.02'),('0','1000000','1000000000'),protocol['A']['patterns']))
    assert cells==expected
    a=load(HERE/'A_results/summary.json')
    rows=list(csv.DictReader((HERE/'A_results/case_results.csv').open(encoding='utf-8-sig',newline='')))
    prefixes=list(csv.DictReader((HERE/'A_results/prefix_results.csv').open(encoding='utf-8-sig',newline='')))
    full=load(HERE/'A_results/full_signatures.json')
    disparities=load(HERE/'A_results/all_discrepancies.json')
    assert len(rows)==1320 and len(full)==1320
    assert len({(r['case_id'],r['channel']) for r in rows})==1320
    assert sum(r['agrees']=='False' for r in prefixes)==len(disparities)
    full_by_key={(r['case_id'],r['channel']):r for r in full}
    for r in rows:
        item=full_by_key[(r['case_id'],r['channel'])]
        assert (r['full_signature_agrees']=='True')==(item['reference']==item['observed'])
    breakdown=[]
    for channel in protocol['A']['channels']:
        for origin in ('0','1000000','1000000000'):
            for dwell in ('0','0.05','0.15'):
                sub=[r for r in rows if r['group']=='factorial' and r['channel']==channel and r['origin']==origin and r['dwell']==dwell]
                assert len(sub)==72
                breakdown.append({'channel':channel,'origin':origin,'dwell':dwell,'cases':72,
                    'case_matches':sum(r['full_signature_agrees']=='True' for r in sub),
                    'case_mismatches':sum(r['full_signature_agrees']=='False' for r in sub),
                    'prefixes':sum(int(r['prefixes']) for r in sub),
                    'prefix_mismatches':sum(int(r['prefix_mismatches']) for r in sub),
                    'input_rejections':sum(r['observed_response_verdict']=='rejected_input_contract' for r in sub)})
    with (HERE/'A_results/factor_breakdown.csv').open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(breakdown[0]));w.writeheader();w.writerows(breakdown)
    b=load(HERE/'B_results/summary.json')
    assert len(b['workloads'])==9
    for r in b['workloads']:
        path=HERE/'B_results'/r['workload_id']/'completed_iterations.csv'
        raw=list(csv.DictReader(path.open(encoding='utf-8-sig',newline=''))) if path.exists() else []
        measured=[x for x in raw if x['phase']=='measured']
        assert len(measured)==r['completed_measured']
        if len(measured)==5:
            assert r['timing_median_ms']==statistics.median(float(x['total_ms']) for x in measured)
        else:
            assert r['timing_median_ms'] is None
    old=ROOT/'specification/v2/results/traceability_graph/verification.json'
    prior=load(ROOT/'specification/v2/results/v2_evidence_manifest.json')
    # The historical manifest structure is inspected without executing a writer.
    old_expected=prior['sha256']['specification/v2/results/traceability_graph/verification.json']
    assert sha(old)==old_expected
    checks={'schema':'extension_read_only_validation_v1','protocol_sha256':sha(HERE/'protocol_before_runs.json'),
        'A_648_unique_full_factor_cells':cells==expected,'A_1320_case_channel_records':len(rows)==1320,
        'A_all_prefix_discrepancies_retained':sum(r['agrees']=='False' for r in prefixes)==len(disparities),
        'A_table_full_signatures_reconcile':True,'B_all_9_cells_retained':True,
        'B_medians_exactly_recomputed_from_5_iterations':True,'frozen_inputs_and_pinned_sources_byte_unchanged':True,
        'old_graph_verification_bytes_match_historical_manifest':True,
        'preflight_identical_write_recorded':'preflight_write_incident.json',
        'reference_is_authored_computational_implementation_not_human_gold':True,
        'new_training_or_model_calls_or_flight_scoring':False,
        'guard_amendment_sha256':sha(HERE/'protocol_amendment_process_tree_guard.json'),
        'initial_launcher_working_set_peaks_invalidated':all(r['observed_process_working_set_peak_bytes'] is None for r in b['workloads']),
        'B05_original_memory_pass_interruption_retained':b['workloads'][4]['status']=='interrupted_for_process_tree_guard_correction'}
    dump(HERE/'validation_receipt.json',checks)
    dump(HERE/'statistics.json',{'A':a,'A_by_origin_dwell':breakdown,'B':b,
        'case_disagreement_patterns':dict(Counter(r['pattern'] for r in rows if r['group']=='factorial' and r['full_signature_agrees']=='False')),
        'note':'Deterministic factor/workload design; no inferential p-values or independent-sample confidence intervals.'})
    asums={(s['group'],s['channel']):s for s in a['channel_summaries']}
    abs_=asums['factorial','absolute_float'];rel=asums['factorial','decimal_origin_relative_float']
    lines=['# 新增主线计算实验结果（2026-10-11）','',
        '本轮包含 648 个完整交叉构造案例（216 个零持续、432 个正持续）和另列的 12 个拒绝输入。不是新增自然语言样本或新飞行；原 102/600 实验分母、生产源码与图参数保持。','',
        '## A：Decimal 独立枚举与两种输入通道','',
        '| 通道 | 完整签名一致 | 前缀一致 | 主案例输入拒绝 |','|---|---:|---:|---:|',
        f"| 绝对 float | {abs_['case_matches']}/648 | {abs_['prefixes']-abs_['prefix_mismatches']}/{abs_['prefixes']} | {abs_['input_rejections']} |",
        f"| 先减 Decimal 原点再转 float | {rel['case_matches']}/648 | {rel['prefixes']-rel['prefix_mismatches']}/{rel['prefixes']} | {rel['input_rejections']} |",'',
        '所有不一致与拒绝保存在 full_signatures.json、all_discrepancies.json 和逐因子 CSV；没有通过改标签、调容差或改生产源码消除失败。','',
        '## B：固定 24 公式的本机尺度负载','',
        '| 点数 | 密度 | 完成热身/计时 | 全流程中位 ms | Python 分配峰 MiB | 状态 |',
        '|---:|---|---:|---:|---:|---|']
    tex_a=[]
    for s in (abs_,rel):
        name='Absolute float' if s['channel']=='absolute_float' else 'Decimal-origin relative float'
        tex_a.append(f"{name} & {s['case_matches']}/648 & {s['prefixes']-s['prefix_mismatches']}/{s['prefixes']} & {s['input_rejections']} " + chr(92)*2)
    tex_b=[]
    for r in b['workloads']:
        median='—' if r['timing_median_ms'] is None else f"{r['timing_median_ms']:.2f}"
        mem='—' if r['python_allocation_peak_bytes'] is None else f"{r['python_allocation_peak_bytes']/1024**2:.2f}"
        lines.append(f"| {r['samples']:,} | {r['density']} | {r['completed_warmup']}/2, {r['completed_measured']}/5 | {median} | {mem} | {r['status']} |")
        status='Complete' if r['complete_cell'] else '60-s budget reached' if r['status']=='timeout_60s' else r['status'].replace('_',' ')
        tex_b.append(f"{r['samples']} & {r['density']} & {r['completed_measured']}/5 & {median.replace('—','--')} & {mem.replace('—','--')} & {status} " + chr(92)*2)
    lines += ['', '单格原定 60 秒涵盖启动、2 次热身、5 次纯计时和另一次内存测量。首四格完成；第五格已完成计时，其内存测量在执行器修正时中断。原约 4 MiB 启动器进程峰值无效，已置空；Python tracemalloc 独立分配测量本身不受这一启动器问题影响。追加冻结协议改为监控/终止完整进程树，余下负载继续按 60 秒限额执行。对前五格另做固定单次内存诊断，保留原记录，不重做或挑选计时；诊断不把第五格原中断抹成完整完成。未完成 5 次测量不估计中位数；所有部分记录保留。单独内存值仅表示 Python 分配，不是总进程内存。旧 verify_export 在预检时被误调用一次，其写回字节与历史 SHA 完全相同，实际调用已记入 preflight_write_incident.json。']
    with (HERE/'results_summary_zh.md').open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
    english=(f"An additional constructed boundary suite crossed three deadlines, three dwell durations, two value tolerances, three time origins, and twelve observation patterns, yielding 648 cases (432 with positive dwell). An independent Decimal evaluator enumerated future recovery witnesses for each trigger and compared complete invariant/response verdict and obligation signatures and all eligible prefixes. Absolute floating-point timestamps matched {abs_['case_matches']}/648 complete signatures and {abs_['prefixes']-abs_['prefix_mismatches']}/{abs_['prefixes']} prefixes; subtracting the Decimal origin before floating-point conversion matched {rel['case_matches']}/648 and {rel['prefixes']-rel['prefix_mismatches']}/{rel['prefixes']}, respectively. All discrepancies and input rejections remain in the retained records; the production monitor and existing tolerance settings were unchanged. Twelve separately specified input-contract cases were reported outside the factorial denominator. These constructed tests extend boundary coverage and do not add independent language examples or flight records.\n\n"
        f"A separate local scaling experiment held the 24 graph-bound formulas and their parameters fixed while varying synthetic trace length (1,000, 10,000, and 100,000 observations) and three trigger-density patterns. Each of nine workload cells was assigned two warm-ups, five measured iterations without tracemalloc, and one separate Python-allocation measurement under a 60-s total cell budget. Complete five-iteration timing records were obtained for {b['timing_complete_workloads']}/9 cells; {b['complete_workloads']}/9 cells completed both timing and the originally assigned allocation measurement. A Windows launcher observation was discarded, and a frozen executor amendment enforced the same stop conditions over the actual process tree. The fifth cell's allocation pass was interrupted during this correction; its completed timing records remained unchanged, and separate fixed allocation diagnostics were retained without rerunning timings. Resource limits and partial iterations were retained, and a median was reported only when all five measurements completed. Timing covered CSV parsing, graph-bound replay, and summary serialization; it excluded telemetry, actuation, and full event-ledger serialization. These measurements characterize desktop offline workload cost, rather than airborne timing or new empirical flight coverage.\n")
    with (HERE/'paper_ready_results_en.md').open('x',encoding='utf-8') as f:f.write(english)
    with (HERE/'paper_ready_table_rows_A.tex').open('x',encoding='utf-8') as f:f.write('\n'.join(tex_a)+'\n')
    with (HERE/'paper_ready_table_rows_B.tex').open('x',encoding='utf-8') as f:f.write('\n'.join(tex_b)+'\n')
    print(json.dumps({'A':a['channel_summaries'],'B_timing_complete':b['timing_complete_workloads'],'B_cells_complete':b['complete_workloads']}))


if __name__=='__main__':main()
