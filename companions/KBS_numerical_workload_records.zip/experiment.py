"""New frozen experiments only; production and historical evidence are read-only."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal as D
import csv
import gc
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
import tracemalloc

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
V2 = ROOT/'specification/v2'
sys.path.insert(0,str(V2))
import pandas as pd
import numpy as np
from sampled_data_contract import EventTimeObservationContract, SamplingContract
from sampled_monitor import (InvariantSpecification, BoundedResponseSpecification,
    monitor_invariant, monitor_bounded_response)
from monitor_from_traceability_graph import instantiate_formula, replay_trace
from verify_traceability_graph import verify_export
from decimal_oracle import evaluate

CONTRACT = {'maximum_gap': '0.05', 'timestamp_epsilon': '0.000000001'}
PATTERNS = ('no_trigger','early_recovery','closed_deadline','deadline_plus_epsilon',
    'deadline_plus_two_epsilon','exact_dwell_at_recovery_bound','short_dwell_end',
    'interrupted_recovery','overlapping_triggers','expired_then_late_recovery',
    'expired_and_pending','pending_end')


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.write('\n')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def csv_write(path,rows):
    if not rows:
        raise ValueError('empty_result_rows')
    with Path(path).open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def fixtures(d,tau,ve,origin,pattern):
    e = D(CONTRACT['timestamp_epsilon'])
    high, low, middle, equal = D('1.2')+ve,D('0.3')+ve,D('0.75')+ve,D('0.5')+ve
    anchors=[(D(0),high),(D('0.01'),middle)]
    finish=d+D('0.05')
    start=(d-tau)/2
    if pattern=='no_trigger':
        anchors=[(D(0),middle)]
    elif pattern=='early_recovery':
        anchors += [(start,low),(start+tau,low)]
    elif pattern in ('closed_deadline','deadline_plus_epsilon','deadline_plus_two_epsilon'):
        shift={'closed_deadline':D(0),'deadline_plus_epsilon':e,
               'deadline_plus_two_epsilon':2*e}[pattern]
        complete=d+shift
        anchors += [(complete-tau,low),(complete,low)]
    elif pattern=='exact_dwell_at_recovery_bound':
        start=(d-tau)/3
        anchors += [(start,equal),(start+tau,equal)]
    elif pattern=='short_dwell_end':
        anchors += [(start,low)]
        finish=start+tau-2*e if tau>0 else start+2*e
        anchors += [(finish,low)]
    elif pattern=='interrupted_recovery':
        start=(d-tau)/4
        first_duration=tau/2 if tau else D('0.01')
        reset=start+first_duration
        restart=reset+D('0.01')
        anchors += [(start,low),(reset,middle),(restart,low),(restart+tau,low)]
        finish=max(finish,restart+tau+D('0.02'))
    elif pattern=='overlapping_triggers':
        anchors=[(D(0),high),(D('0.01'),high),(D('0.02'),high),(D('0.025'),middle)]
        start=max(D('0.03'),start)
        anchors += [(start,low),(start+tau,low)]
    elif pattern=='expired_then_late_recovery':
        anchors += [(d+2*e,middle),(d+D('0.025'),low),(d+D('0.025')+tau,low)]
        finish=d+D('0.075')+tau
    elif pattern=='expired_and_pending':
        finish=d+D('0.025')
        anchors += [(finish,high)]
    elif pattern=='pending_end':
        finish=d-e
    anchors += [(finish,anchors[-1][1])]
    # Points are explicit synthetic design observations. Filling is defined
    # fixture generation, never repair/interpolation of a recorded flight.
    unique={}
    for t,v in anchors:
        if t in unique and unique[t]!=v:
            raise ValueError('contradictory_synthetic_anchor')
        unique[t]=v
    anchors=sorted(unique.items())
    points=[]
    for i,(t,v) in enumerate(anchors):
        points.append({'time':str(origin+t),'value':str(v)})
        if i+1<len(anchors):
            end=anchors[i+1][0]
            next_t=t+D('0.04')
            while next_t<end and end-next_t>e:
                points.append({'time':str(origin+next_t),'value':str(v)})
                next_t+=D('0.04')
    return points


def freeze():
    if (HERE/'protocol_before_runs.json').exists():
        raise RuntimeError('protocol_already_frozen')
    verify_export()
    inp=HERE/'inputs'; inp.mkdir(exist_ok=False)
    cases=[]
    for d in ('0.2','0.5','2.0'):
        for tau in ('0','0.05','0.15'):
            for ve in ('0','0.02'):
                for origin in ('0','1000000','1000000000'):
                    for pattern in PATTERNS:
                        points=fixtures(D(d),D(tau),D(ve),D(origin),pattern)
                        rule={'upper':'1.0','recovery':'0.5','deadline':d,'dwell':tau,'value_epsilon':ve}
                        times=[D(p['time']) for p in points]
                        gaps=[b-a for a,b in zip(times,times[1:])]
                        if len(points)<2 or any(g<=D(CONTRACT['timestamp_epsilon']) or g>D(CONTRACT['maximum_gap'])+D(CONTRACT['timestamp_epsilon']) for g in gaps):
                            raise ValueError('fixture_preflight_failure:'+str((d,tau,ve,origin,pattern)))
                        cases.append({'case_id':f'A{len(cases)+1:04d}','pattern':pattern,
                            'origin':origin,'rule':rule,'points':points})
    if len(cases)!=648:
        raise AssertionError('expected_648_full_factor_cases')
    write(inp/'A_cases.json',cases)
    # Separate deliberately rejected input-contract cases; not included in 648.
    negatives=[]
    rule=cases[0]['rule']
    for origin in ('0','1000000000'):
        for name,ts,vs in (
            ('one_point',['0'],['1.2']),('duplicate',['0','0'],['1.2','0.3']),
            ('decreasing',['0.02','0.01'],['1.2','0.3']),
            ('large_gap',['0','0.1'],['1.2','0.3']),
            ('nan_time',['0','NaN'],['1.2','0.3']),
            ('nan_value',['0','0.02'],['1.2','NaN'])):
            points=[{'time':str(D(t)+D(origin)),'value':v} for t,v in zip(ts,vs)]
            negatives.append({'case_id':f'R{len(negatives)+1:03d}','pattern':name,
                'origin':origin,'rule':rule,'points':points})
    write(inp/'A_rejected_contract_cases.json',negatives)
    graph_nodes=V2/'results/traceability_graph/nodes.csv'
    graph_edges=V2/'results/traceability_graph/relationships.csv'
    nodes=pd.read_csv(graph_nodes,encoding='utf-8-sig')
    formula_ids=sorted(nodes.loc[nodes['id'].str.startswith('formula:'),'id'].tolist())
    if len(formula_ids)!=24:
        raise AssertionError('catalog_not_24_formulas')
    specs=[instantiate_formula(fid) for fid in formula_ids]
    signals=sorted({s.signal for s in specs})
    levels={}
    for signal in signals:
        current=[s for s in specs if s.signal==signal]
        lows=[s.recovery_upper+s.value_epsilon if isinstance(s,BoundedResponseSpecification) else s.upper_bound+s.value_epsilon for s in current]
        highs=[s.trigger_upper+s.value_epsilon if isinstance(s,BoundedResponseSpecification) else s.upper_bound+s.value_epsilon for s in current]
        levels[signal]={'low':min(lows)-1.0,'high':max(highs)+1.0}
    workloads=[]
    for count in (1000,10000,100000):
        for density in ('quiescent','sparse','dense'):
            index=np.arange(count)
            frame={'time_seconds':index/20.0}
            active=np.zeros(count,dtype=bool) if density=='quiescent' else index%40<4 if density=='sparse' else np.ones(count,dtype=bool)
            for signal in signals:
                frame[signal]=np.where(active,levels[signal]['high'],levels[signal]['low'])
            path=inp/f'B_{count}_{density}.csv'
            pd.DataFrame(frame).to_csv(path,index=False,encoding='utf-8-sig',float_format='%.12g')
            workloads.append({'workload_id':f'B{len(workloads)+1:02d}','samples':count,
                'density':density,'trace_path':path.relative_to(HERE).as_posix()})
    write(inp/'B_workloads.json',workloads)
    write(inp/'B_bound_specifications.json',{'formula_ids':formula_ids,
        'specifications':[vars(s) for s in specs],'signal_levels':levels})
    code_paths=[Path(__file__),HERE/'decimal_oracle.py',graph_nodes,graph_edges]
    for module in tuple(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename and Path(filename).suffix=='.py' and Path(filename).is_relative_to(V2):
            code_paths.append(Path(filename))
    env={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
        'processor':platform.processor(),'logical_cpus':os.cpu_count(),
        'packages':{name:version(name) for name in ('pandas','numpy')},
        'device_role':'ground desktop; no airborne measurement'}
    write(HERE/'environment_before_runs.json',env)
    protocol={'schema':'monitor_scale_extension_protocol_v1','frozen_utc':now(),
        'frozen_before_runs':True,'training':False,'model_calls':False,'new_flight_scoring':False,
        'A':{'cases':648,'rejected_contract_cases':12,'patterns':list(PATTERNS),
             'contract':CONTRACT,'channels':['absolute_float','decimal_origin_relative_float'],
             'signature_fields':['invariant_verdict','invariant_violations','response_verdict','triggers','recovered','expired','pending'],
             'prefixes':'every length >=2, plus singleton only for rejection group',
             'reference':'Independent Decimal per-trigger future-witness enumeration; no shared FIFO state',
             'failure_rule':'Persist all mismatches and rejects; no relabelling, filtering or production modification'},
        'B':{'workload_cells':9,'formula_ids':formula_ids,'samples':[1000,10000,100000],
             'density_patterns':['quiescent','sparse (4 high observations per 40)','dense'],
             'warmup':2,'measurements':5,'cell_timeout_seconds':60,
             'cell_memory_stop_bytes':2*1024**3,'sequence':'ascending length then quiescent/sparse/dense; fixed without best-run selection',
             'timing_scope':'CSV parse + graph-bound 24-formula replay + summary CSV serialization; internal events allocated but complete event-ledger serialization is not timed',
             'tracemalloc_in_timing':False,'memory':'One separate iteration after timings with tracemalloc; Python allocation peak, not RSS',
             'timeout_scope':'Entire workload child including imports, warmup, measured iterations, and independent memory pass',
             'summary_rule':'Median only if all five measured iterations finish; partial records retained and never described as complete'},
        'input_sha256':{p.relative_to(HERE).as_posix():sha(p) for p in sorted(inp.iterdir())},
        'read_only_source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in sorted(set(code_paths))},
        'environment_sha256':sha(HERE/'environment_before_runs.json'),
        'scope':'New constructed computational cases; not new language corpus, independent flights, physical safety validation or an extension of earlier 102/600 denominators'}
    write(HERE/'protocol_before_runs.json',protocol)
    print(json.dumps({'status':'frozen_before_runs','cases':648,'negative_cases':12,'workloads':9,'sha256':sha(HERE/'protocol_before_runs.json')}),flush=True)


def check_protocol():
    protocol=load(HERE/'protocol_before_runs.json')
    for rel,digest in protocol['input_sha256'].items():
        if sha(HERE/rel)!=digest:
            raise ValueError('frozen_input_changed:'+rel)
    for rel,digest in protocol['read_only_source_sha256'].items():
        if sha(ROOT/rel)!=digest:
            raise ValueError('frozen_source_changed:'+rel)
    return protocol


def observed(points,rule,relative):
    origin=D(points[0]['time']) if relative else D(0)
    frame=pd.DataFrame({'time_seconds':[float(D(p['time'])-origin) for p in points],
                        'signal':[float(D(p['value'])) for p in points]})
    c=EventTimeObservationContract(float(CONTRACT['maximum_gap']),float(CONTRACT['timestamp_epsilon']))
    inv=monitor_invariant(frame,InvariantSpecification('signal',float(rule['upper']),float(rule['value_epsilon'])),c)
    resp=monitor_bounded_response(frame,BoundedResponseSpecification('signal',float(rule['upper']),float(rule['recovery']),float(rule['deadline']),float(rule['dwell']),float(rule['value_epsilon'])),c)
    signature={'invariant_verdict':inv.verdict.value,'invariant_violations':inv.violating_sample_indices,
        'response_verdict':resp.verdict.value,'triggers':[o.trigger_index for o in resp.created_obligations],
        'recovered':sorted(resp.recovered_obligation_ids),'expired':sorted(resp.expired_obligation_ids),
        'pending':sorted(resp.pending_obligation_ids)}
    return signature,resp.sampling_audit.to_dict()


def run_a():
    check_protocol()
    out=HERE/'A_results';out.mkdir(exist_ok=False)
    cases=load(HERE/'inputs/A_cases.json'); negatives=load(HERE/'inputs/A_rejected_contract_cases.json')
    rows=[];prefix_rows=[];details=[];discrepancies=[]
    start=time.perf_counter()
    for case in cases+negatives:
        points,rule=case['points'],case['rule']
        ref=evaluate(points,rule,CONTRACT)
        for channel,relative in (('absolute_float',False),('decimal_origin_relative_float',True)):
            got,audit=observed(points,rule,relative)
            bad=[key for key in ref if ref[key]!=got[key]]
            failed_prefixes=[]
            for length in range(2,len(points)+1):
                pr=evaluate(points[:length],rule,CONTRACT)
                pg,_=observed(points[:length],rule,relative)
                pb=[key for key in pr if pr[key]!=pg[key]]
                prefix_rows.append({'case_id':case['case_id'],'group':'factorial' if case['case_id'].startswith('A') else 'rejected_contract','channel':channel,'prefix_length':length,'agrees':not pb,'differing_fields':';'.join(pb)})
                if pb:
                    failed_prefixes.append(length)
                    discrepancies.append({'case_id':case['case_id'],'channel':channel,'prefix_length':length,'reference':pr,'observed':pg,'differing_fields':pb})
            row={'case_id':case['case_id'],'group':'factorial' if case['case_id'].startswith('A') else 'rejected_contract',
                'pattern':case['pattern'],'origin':case['origin'],'deadline':rule['deadline'],'dwell':rule['dwell'],'value_epsilon':rule['value_epsilon'],
                'observations':len(points),'channel':channel,'reference_response_verdict':ref['response_verdict'],
                'observed_response_verdict':got['response_verdict'],'full_signature_agrees':not bad,
                'differing_fields':';'.join(bad),'prefixes':max(0,len(points)-1),'prefix_mismatches':len(failed_prefixes)}
            rows.append(row);details.append({'case_id':case['case_id'],'channel':channel,'reference':ref,'observed':got,'input_audit':audit})
        if len(rows)%108==0:
            print(json.dumps({'A_cases_processed':len(rows)//2,'elapsed_seconds':round(time.perf_counter()-start,2)}),flush=True)
    csv_write(out/'case_results.csv',rows);csv_write(out/'prefix_results.csv',prefix_rows)
    write(out/'full_signatures.json',details);write(out/'all_discrepancies.json',discrepancies)
    summaries=[]
    for group in ('factorial','rejected_contract'):
        for channel in ('absolute_float','decimal_origin_relative_float'):
            subset=[r for r in rows if r['group']==group and r['channel']==channel]
            summaries.append({'group':group,'channel':channel,'cases':len(subset),
                'case_matches':sum(r['full_signature_agrees'] for r in subset),
                'case_mismatches':sum(not r['full_signature_agrees'] for r in subset),
                'prefixes':sum(r['prefixes'] for r in subset),'prefix_mismatches':sum(r['prefix_mismatches'] for r in subset),
                'input_rejections':sum(r['observed_response_verdict']=='rejected_input_contract' for r in subset),
                'reference_verdicts':dict(Counter(r['reference_response_verdict'] for r in subset))})
    write(out/'summary.json',{'schema':'extension_A_summary_v1','cases':648,'separate_rejection_cases':12,'elapsed_seconds':time.perf_counter()-start,'channel_summaries':summaries,'all_discrepancies_retained':True,'production_modified':False,'protocol_sha256':sha(HERE/'protocol_before_runs.json')})
    print(json.dumps(summaries),flush=True)


def iteration(path,formula_ids):
    import io
    t0=time.perf_counter_ns();frame=pd.read_csv(path,encoding='utf-8-sig');t1=time.perf_counter_ns()
    replay=replay_trace(frame,formula_ids);t2=time.perf_counter_ns()
    buffer=io.StringIO();replay.to_csv(buffer,index=False,lineterminator='\n');t3=time.perf_counter_ns()
    counts={'trigger_count':int(replay['created_obligation_count'].sum()),
        'recovery_count':int(replay['recovered_obligation_count'].sum()),
        'expired_count':int(replay['expired_obligation_count'].sum()),
        'pending_count':int(replay['pending_obligation_count'].sum()),
        'invariant_violation_count':int(replay['violating_sample_count'].sum())}
    metrics={'parse_ms':(t1-t0)/1e6,'monitor_ms':(t2-t1)/1e6,
        'summary_serialization_ms':(t3-t2)/1e6,'total_ms':(t3-t0)/1e6,
        'summary_output_bytes':len(buffer.getvalue().encode('utf-8')),
        'trace_samples':len(frame),'formula_count':len(replay),**counts}
    return metrics,replay


def b_worker(workload_id):
    proto=check_protocol()
    cell=next(w for w in load(HERE/'inputs/B_workloads.json') if w['workload_id']==workload_id)
    out=HERE/'B_results'/workload_id
    ids=proto['B']['formula_ids']
    path=HERE/cell['trace_path']
    raw=out/'completed_iterations.csv'
    write(out/'worker_started.json',{'started_utc':now(),'tracemalloc_timing':False,**cell})
    with raw.open('x',encoding='utf-8-sig',newline='') as f:
        writer=None
        for phase,count in (('warmup',2),('measured',5)):
            for i in range(count):
                if tracemalloc.is_tracing():
                    raise AssertionError('tracemalloc_in_timing')
                metrics,replay=iteration(path,ids)
                row={'phase':phase,'iteration':i+1,**metrics}
                if writer is None:
                    writer=csv.DictWriter(f,fieldnames=list(row));writer.writeheader()
                writer.writerow(row);f.flush()
                if phase=='warmup' and i==0:
                    replay.to_csv(out/'first_replay_summary.csv',index=False,encoding='utf-8-sig')
                del replay;gc.collect()
        f.flush()
    write(out/'timings_completed.json',{'finished_utc':now(),'measurements':5})
    gc.collect();tracemalloc.start();tracemalloc.reset_peak()
    metrics,replay=iteration(path,ids)
    _,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    del replay
    write(out/'separate_memory_pass.json',{'finished_utc':now(),'python_allocation_peak_bytes':peak,
        'scope':'Python allocation peak only; no RSS claim; independent pass excluded from reported timing median',
        'counts':{k:v for k,v in metrics.items() if k.endswith('_count')}})


def process_memory(pid):
    if os.name!='nt':
        return None
    import ctypes
    from ctypes import wintypes
    class Memory(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
            ('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),
            ('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),
            ('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),
            ('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
    k=ctypes.WinDLL('kernel32',use_last_error=True); p=ctypes.WinDLL('psapi',use_last_error=True)
    k.OpenProcess.restype=wintypes.HANDLE;k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    p.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD]
    handle=k.OpenProcess(0x0400|0x0010,False,pid)
    if not handle:
        return None
    try:
        mem=Memory();mem.cb=ctypes.sizeof(mem)
        return int(mem.WorkingSetSize) if p.GetProcessMemoryInfo(handle,ctypes.byref(mem),mem.cb) else None
    finally:
        k.CloseHandle(handle)


def run_b():
    proto=check_protocol();out=HERE/'B_results';out.mkdir(exist_ok=False)
    rows=[]
    for cell in load(HERE/'inputs/B_workloads.json'):
        target=out/cell['workload_id'];target.mkdir()
        start=time.perf_counter();peak=0;stop_reason=None
        with (target/'worker_stdout.txt').open('x',encoding='utf-8') as stdout, (target/'worker_stderr.txt').open('x',encoding='utf-8') as stderr:
            process=subprocess.Popen([sys.executable,'-B','-X','utf8',str(__file__),'b-worker','--workload',cell['workload_id']],stdout=stdout,stderr=stderr,cwd=str(ROOT),env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            while process.poll() is None:
                elapsed=time.perf_counter()-start
                memory=process_memory(process.pid)
                if memory is not None:
                    peak=max(peak,memory)
                if elapsed>proto['B']['cell_timeout_seconds']:
                    stop_reason='timeout_60s';process.kill();break
                if memory is not None and memory>proto['B']['cell_memory_stop_bytes']:
                    stop_reason='process_working_set_over_2GiB';process.kill();break
                time.sleep(0.2)
            returncode=process.wait(timeout=10)
        raw=target/'completed_iterations.csv'
        completed=list(csv.DictReader(raw.open(encoding='utf-8-sig',newline=''))) if raw.exists() else []
        measured=[r for r in completed if r['phase']=='measured']
        full=len(measured)==5
        memory_path=target/'separate_memory_pass.json'
        memory_record=load(memory_path) if memory_path.exists() else None
        row={'workload_id':cell['workload_id'],'samples':cell['samples'],'density':cell['density'],
            'status':stop_reason or ('completed' if returncode==0 else 'worker_error'),
            'exit_code':returncode,'elapsed_seconds':time.perf_counter()-start,
            'completed_warmup':sum(r['phase']=='warmup' for r in completed),'completed_measured':len(measured),
            'timing_median_ms':statistics.median(float(r['total_ms']) for r in measured) if full else None,
            'monitor_median_ms':statistics.median(float(r['monitor_ms']) for r in measured) if full else None,
            'throughput_samples_per_s':statistics.median(cell['samples']/(float(r['total_ms'])/1000) for r in measured) if full else None,
            'separate_memory_pass_completed':memory_record is not None,
            'python_allocation_peak_bytes':memory_record['python_allocation_peak_bytes'] if memory_record else None,
            'observed_process_working_set_peak_bytes':peak,'complete_cell':full and memory_record is not None and returncode==0,
            'observed_trigger_count':int(completed[0]['trigger_count']) if completed else None,
            'observed_expired_count':int(completed[0]['expired_count']) if completed else None,
            'observed_pending_count':int(completed[0]['pending_count']) if completed else None}
        rows.append(row);write(target/'cell_receipt.json',row)
        print(json.dumps(row),flush=True)
    csv_write(out/'workload_summary.csv',rows)
    write(out/'summary.json',{'schema':'extension_B_summary_v1','protocol_sha256':sha(HERE/'protocol_before_runs.json'),
        'workloads':rows,'fixed_formulas':24,'all_workloads_accounted_for':len(rows)==9,
        'complete_workloads':sum(r['complete_cell'] for r in rows),'timing_complete_workloads':sum(r['completed_measured']==5 for r in rows),
        'production_modified':False,'sampling':'synthetic 20 Hz points, not new flights or independent NL examples'})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','a','b','b-worker','check']);parser.add_argument('--workload')
    args=parser.parse_args()
    if args.action=='freeze':freeze()
    elif args.action=='a':run_a()
    elif args.action=='b':run_b()
    elif args.action=='b-worker':b_worker(args.workload)
    else:print(json.dumps({'protocol':sha(HERE/'protocol_before_runs.json'),'sources_and_inputs_unchanged':bool(check_protocol())}),flush=True)


if __name__=='__main__':
    main()
