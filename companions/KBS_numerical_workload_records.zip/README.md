# 第 77 轮：新增监测边界与尺度负载实验

已按用户选择补论文主线计算证据。结果入口为 `results_summary_zh.md`、`paper_ready_results_en.md`、`statistics.json`；可直接用于新稿的表格数据在 `paper_ready_table_rows_A.tex`、`paper_ready_table_rows_B.tex`。原 102 案例/600 轨迹、语言评分及旧封存不被合并或改分。

## 原始实验与冻结证据

- `protocol_before_runs.json` 在运行前固定了 648 主案例、12 单列输入拒绝例、9 个负载格、现有 24 公式、代码/输入 SHA 和环境。
- `A_results/case_results.csv` 与 `prefix_results.csv` 记录逐例与逐前缀；`full_signatures.json` 和 `all_discrepancies.json` 保留所有不一致、拒绝和实际输出。
- `B_results/B01` 至 `B09` 保存每格原始完成迭代、独立内存结果或超时/中断回执；`B_results/workload_summary.csv` 和 `summary.json` 汇总所有计划格，缺失中位数不被填补。
- `validation_receipt.json` 核对完整因子交叉、案例/前缀、5 次计时中位数、冻结源码与输入、旧图验收哈希。
- `experiment_artifact_manifest.json` 固定本次实验产生的文件子集，后续根代理的独立复核可另增文件；不覆盖这里已产生的结果。

## 结果

A 原绝对 float 输入通道一致 602/648、15,946/16,134 前缀；先减 Decimal 原点再转 float 一致 648/648、16,134/16,134。原路径的 46 个签名差异（含 12 个精度输入拒绝）全部在 1e9 秒原点。独立 12 契约负例两通道都正确拒绝。没有修改生产监控器、容差或期待标签；这次路径比较不表示既有真实日志全数重处理。

B 五格获得完整 5 次计时，四格完成原计划的计时与独立内存。第五格稀疏 10k 的计时完成，原内存 pass 在执行器修正时中断，之后按追加冻结协议完成单独诊断。密集 10k 在 60 秒整格预算到达时仅完成 4 次测量；100k 三格未完成测量序列，记录其全部热身/部分输出。100k 静默已有 2 次完整热身回放、稀疏有 1 次，不能据预算停止写成单条轨迹执行不了。

## 两个必须保留的执行记录

1. 预检曾误调用旧 `verify_export()`，它重写了 `specification/v2/results/traceability_graph/verification.json` 的相同字节，时间戳可能改变。实际 SHA 与历史 v2 manifest 都为 `3832fc8b3b94b830d94c8447061b81619b95d467358304783cbbad02ed5cfc99`。`preflight_write_incident.json` 记录此事；不得声称没有对旧目录发生写入调用。旧生产源码/科学结果的字节保持。
2. Windows venv 启动器另起真实 Python 子进程，初版内存守卫只观测启动器，原约 4 MiB 进程峰值无效。`protocol_amendment_process_tree_guard.json` 先冻结追加修正，再监控/终止实际完整进程树；初版源码、已有计时与中断记录均保留。前五格另做固定一次的独立内存诊断，保存在 `B_guard_memory_checks`；不重新选择计时。当前没有本实验后台工作进程。

本轮没有训练、新模型调用、新实飞、故障分数新评分或论文封存目录修改。计算参考不是真人标注或独立物理真值。

## 安全重验

只读 SHA 检查可运行：

```powershell
& '.venv_torch/Scripts/python.exe' -B -X utf8 'analysis/results/77_monitor_scale_extension_20261011/experiment.py' check
```

`freeze/a/b`、`safe_controller.py continue` 和 `make_report.py` 是本轮生成入口，已完成后不要重跑；它们使用新建文件/目录保护。后续新实验另建目录并保留这轮完整首次结果。
