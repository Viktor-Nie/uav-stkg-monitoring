"""Frozen Windows redirector-aware process-tree guard amendment; no core edits."""
import argparse
import csv
import ctypes
from ctypes import wintypes
import gc
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import tracemalloc

sys.dont_write_bytecode=True
import experiment as ex
HERE=ex.HERE


def process_tree(root_pid):
    class Entry(ctypes.Structure):
        _fields_=[('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('th32ProcessID',wintypes.DWORD),
            ('th32DefaultHeapID',ctypes.c_size_t),('th32ModuleID',wintypes.DWORD),('cntThreads',wintypes.DWORD),
            ('th32ParentProcessID',wintypes.DWORD),('pcPriClassBase',wintypes.LONG),('dwFlags',wintypes.DWORD),
            ('szExeFile',wintypes.WCHAR*260)]
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.CreateToolhelp32Snapshot.argtypes=[wintypes.DWORD,wintypes.DWORD];k.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
    k.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)]
    k.Process32NextW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)]
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=k.CreateToolhelp32Snapshot(2,0)
    if handle==ctypes.c_void_p(-1).value:
        raise OSError('process_snapshot_failed')
    links={};entry=Entry();entry.dwSize=ctypes.sizeof(entry)
    try:
        ok=k.Process32FirstW(handle,ctypes.byref(entry))
        while ok:
            links[int(entry.th32ProcessID)]=int(entry.th32ParentProcessID)
            ok=k.Process32NextW(handle,ctypes.byref(entry))
    finally:k.CloseHandle(handle)
    found={root_pid};changed=True
    while changed:
        new={pid for pid,parent in links.items() if parent in found}
        changed=not new.issubset(found);found.update(new)
    return found


def terminate_tree(process,known):
    # root PID comes directly from this controller's Popen handle; the only
    # descendants accepted here are native snapshot relations to that PID.
    tree=process_tree(process.pid)
    result=subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10)
    known.update(tree)
    process.wait(timeout=10)
    alive=[]
    for pid in tree:
        if ex.process_memory(pid) is not None:
            alive.append(pid)
    if alive:
        k=ctypes.WinDLL('kernel32',use_last_error=True)
        k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
        k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k.CloseHandle.argtypes=[wintypes.HANDLE]
        for pid in alive:
            handle=k.OpenProcess(1,False,pid)
            if handle:
                try:k.TerminateProcess(handle,1)
                finally:k.CloseHandle(handle)
    return {'native_taskkill_exit':result.returncode,'target_root_pid':process.pid,
            'observed_target_descendants':sorted(tree),'additional_exact_descendant_termination':alive}


def freeze():
    ex.check_protocol()
    existing={}
    for p in sorted((HERE/'B_results').rglob('*')):
        if p.is_file():existing[p.relative_to(HERE).as_posix()]=ex.sha(p)
    ex.write(HERE/'protocol_amendment_process_tree_guard.json',{
        'schema':'process_tree_guard_amendment_v1','frozen_utc':ex.now(),'frozen_before_continuation':True,
        'initial_protocol_sha256':ex.sha(HERE/'protocol_before_runs.json'),
        'new_controller_sha256':ex.sha(Path(__file__)),'core_executor_unchanged':True,
        'scientific_factors_and_five_timings_unchanged':True,
        'reason':'Windows venv python.exe redirects to a base-environment Python child process. Initial guard observed/killed only the launcher, so the process-tree guard is necessary to enforce the same stop conditions.',
        'completed_cells_reused':['B01','B02','B03','B04'],
        'interrupted_cell':'B05','interrupted_cell_timing_iterations_completed':5,
        'interruption':'Exact original experimental root PID 22396 and descendants were terminated with taskkill /T /F during the independent memory pass; native process listing then contained no experimental process.',
        'completed_first_four_python_allocation_measurements_valid':True,
        'initial_4MiB_process_peak_invalid_for_compute_process':True,
        'new_full_cells':['B06','B07','B08','B09'],
        'per_cell_total_seconds':60,'process_tree_working_set_limit_bytes':2*1024**3,
        'memory_rechecks':['B01','B02','B03','B04','B05'],
        'memory_recheck_policy':'One separate fixed allocation pass for each cell with five already completed timings, under an independent 60-s diagnostic limit. Do not rerun or select timing iterations. Original first four allocation peaks remain primary; B05 recheck does not erase interruption or claim original cell completion.',
        'existing_B_records_sha256':existing})
    print(json.dumps({'status':'guard_amendment_frozen','sha256':ex.sha(HERE/'protocol_amendment_process_tree_guard.json')}),flush=True)


def check():
    ex.check_protocol();a=ex.load(HERE/'protocol_amendment_process_tree_guard.json')
    assert ex.sha(Path(__file__))==a['new_controller_sha256']
    for p,h in a['existing_B_records_sha256'].items():assert ex.sha(HERE/p)==h,p
    return a


def guarded(action,cell,out):
    command=[sys.executable,'-B','-X','utf8',str(HERE/'experiment.py'),'b-worker','--workload',cell['workload_id']] if action=='full' else [sys.executable,'-B','-X','utf8',str(__file__),'memory-worker','--workload',cell['workload_id']]
    started=time.perf_counter();peak=0;known=set();stop=None;termination=None
    with (out/'guard_stdout.txt').open('x',encoding='utf-8') as stdout,(out/'guard_stderr.txt').open('x',encoding='utf-8') as stderr:
        process=subprocess.Popen(command,cwd=str(ex.ROOT),stdout=stdout,stderr=stderr,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},creationflags=subprocess.CREATE_NO_WINDOW)
        while process.poll() is None:
            tree=process_tree(process.pid);known.update(tree)
            observed=[ex.process_memory(pid) for pid in tree]
            total=sum(m for m in observed if m is not None);peak=max(peak,total)
            if time.perf_counter()-started>60:
                stop='timeout_60s';termination=terminate_tree(process,known);break
            if total>2*1024**3:
                stop='process_tree_working_set_over_2GiB';termination=terminate_tree(process,known);break
            time.sleep(0.2)
        code=process.wait(timeout=10)
    return {'action':action,'status':stop or ('completed' if code==0 else 'worker_error'),
        'exit_code':code,'elapsed_seconds':time.perf_counter()-started,
        'observed_process_tree_working_set_peak_bytes':peak,'guarded_pids':sorted(known),'termination':termination,
        'scope':'Sum of sampled resident working sets across this child and actual descendants; not unique physical memory and not Python-allocation peak'}


def memory_worker(workload):
    ex.check_protocol()
    cell=next(w for w in ex.load(HERE/'inputs/B_workloads.json') if w['workload_id']==workload)
    out=HERE/'B_guard_memory_checks'/workload
    gc.collect();tracemalloc.start();tracemalloc.reset_peak()
    metrics,replay=ex.iteration(HERE/cell['trace_path'],ex.load(HERE/'protocol_before_runs.json')['B']['formula_ids'])
    _,peak=tracemalloc.get_traced_memory();tracemalloc.stop();del replay
    ex.write(out/'allocation_measurement.json',{'finished_utc':ex.now(),'python_allocation_peak_bytes':peak,
        'scope':'One separate allocation pass under executor guard amendment; no timing rerun',
        'counts':{k:v for k,v in metrics.items() if k.endswith('_count')}})


def continuation():
    amendment=check()
    cells=ex.load(HERE/'inputs/B_workloads.json');rows=[]
    for cell in cells[:4]:
        row=ex.load(HERE/'B_results'/cell['workload_id']/'cell_receipt.json')
        row['initial_launcher_memory_guard_invalid']=True
        row['observed_process_working_set_peak_bytes']=None
        row['observed_process_tree_working_set_peak_bytes']=None
        rows.append(row)
    cell=cells[4];out=HERE/'B_results'/cell['workload_id']
    raw=list(csv.DictReader((out/'completed_iterations.csv').open(encoding='utf-8-sig',newline='')))
    measured=[r for r in raw if r['phase']=='measured'];assert len(measured)==5
    interrupted={'workload_id':cell['workload_id'],'samples':cell['samples'],'density':cell['density'],
        'status':'interrupted_for_process_tree_guard_correction','exit_code':None,'elapsed_seconds':None,
        'completed_warmup':sum(r['phase']=='warmup' for r in raw),'completed_measured':len(measured),
        'timing_median_ms':statistics.median(float(r['total_ms']) for r in measured),
        'monitor_median_ms':statistics.median(float(r['monitor_ms']) for r in measured),
        'throughput_samples_per_s':statistics.median(cell['samples']/(float(r['total_ms'])/1000) for r in measured),
        'separate_memory_pass_completed':False,'python_allocation_peak_bytes':None,
        'observed_process_working_set_peak_bytes':None,'complete_cell':False,
        'observed_trigger_count':int(raw[0]['trigger_count']),'observed_expired_count':int(raw[0]['expired_count']),
        'observed_pending_count':int(raw[0]['pending_count']),'initial_launcher_memory_guard_invalid':True,
        'observed_process_tree_working_set_peak_bytes':None}
    ex.write(out/'interruption_receipt.json',interrupted);rows.append(interrupted)
    for cell in cells[5:]:
        out=HERE/'B_results'/cell['workload_id'];out.mkdir(exist_ok=False)
        guard=guarded('full',cell,out);ex.write(out/'process_tree_guard_receipt.json',guard)
        raw_path=out/'completed_iterations.csv'
        raw=list(csv.DictReader(raw_path.open(encoding='utf-8-sig',newline=''))) if raw_path.exists() else []
        measured=[r for r in raw if r['phase']=='measured'];full=len(measured)==5
        memory_path=out/'separate_memory_pass.json';memory=ex.load(memory_path) if memory_path.exists() else None
        row={'workload_id':cell['workload_id'],'samples':cell['samples'],'density':cell['density'],
            'status':guard['status'],'exit_code':guard['exit_code'],'elapsed_seconds':guard['elapsed_seconds'],
            'completed_warmup':sum(r['phase']=='warmup' for r in raw),'completed_measured':len(measured),
            'timing_median_ms':statistics.median(float(r['total_ms']) for r in measured) if full else None,
            'monitor_median_ms':statistics.median(float(r['monitor_ms']) for r in measured) if full else None,
            'throughput_samples_per_s':statistics.median(cell['samples']/(float(r['total_ms'])/1000) for r in measured) if full else None,
            'separate_memory_pass_completed':memory is not None,'python_allocation_peak_bytes':memory['python_allocation_peak_bytes'] if memory else None,
            'observed_process_working_set_peak_bytes':None,'complete_cell':full and memory is not None and guard['status']=='completed',
            'observed_trigger_count':int(raw[0]['trigger_count']) if raw else None,
            'observed_expired_count':int(raw[0]['expired_count']) if raw else None,
            'observed_pending_count':int(raw[0]['pending_count']) if raw else None,
            'initial_launcher_memory_guard_invalid':False,
            'observed_process_tree_working_set_peak_bytes':guard['observed_process_tree_working_set_peak_bytes']}
        ex.write(out/'cell_receipt.json',row);rows.append(row);print(json.dumps(row),flush=True)
    mem_dir=HERE/'B_guard_memory_checks';mem_dir.mkdir(exist_ok=False)
    for cell in cells[:5]:
        out=mem_dir/cell['workload_id'];out.mkdir()
        guard=guarded('memory',cell,out);ex.write(out/'process_tree_guard_receipt.json',guard)
        print(json.dumps({'memory_recheck':cell['workload_id'],**guard}),flush=True)
    ex.csv_write(HERE/'B_results/workload_summary.csv',rows)
    ex.write(HERE/'B_results/summary.json',{'schema':'extension_B_summary_v2','protocol_sha256':ex.sha(HERE/'protocol_before_runs.json'),
        'guard_amendment_sha256':ex.sha(HERE/'protocol_amendment_process_tree_guard.json'),'workloads':rows,
        'fixed_formulas':24,'all_workloads_accounted_for':len(rows)==9,
        'complete_workloads':sum(r['complete_cell'] for r in rows),
        'timing_complete_workloads':sum(r['completed_measured']==5 for r in rows),'production_modified':False,
        'memory_rechecks':'B_guard_memory_checks; first four original allocation peaks primary; B05 diagnostic does not erase its original interrupted memory pass',
        'sampling':'synthetic 20 Hz points, not new flights or independent NL examples'})
    check()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['freeze','continue','memory-worker']);parser.add_argument('--workload');args=parser.parse_args()
    if args.action=='freeze':freeze()
    elif args.action=='continue':continuation()
    else:memory_worker(args.workload)


if __name__=='__main__':main()
