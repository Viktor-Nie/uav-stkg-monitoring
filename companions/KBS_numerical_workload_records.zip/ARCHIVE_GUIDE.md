# Numerical and desktop workload records

These retained records are indexed by experiment_artifact_manifest.json. Read README.md and the protocol and result directories to inspect the original experiment. For an offline monitor rerun, extract the public v35 snapshot and use reproduce_monitor.py. The workload cells record elapsed time in the original hardware and software environment.
