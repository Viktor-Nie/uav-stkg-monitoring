# v63可选候选入口的完整绑定前置检查

只用Python标准库。运行修订入口：
python fixed_entry/validate_candidate.py examples/valid_response.json
python fixed_entry/validate_candidate.py examples/empty_bindings.json
python fixed_entry/validate_candidate.py examples/null_bindings.json

后两份应返回accepted=false、stage=binding_precheck、numeric_check=null、stkg_checked=false、bound_values=null。无参数推测、去重、数值强制转换或静默规范化。有效成功记录保持原输出接口。

检查 supplied bindings 的JSON记录结构、完整2/5角色集、规范单位、有限int/float且排除bool、四个非空来源字段及原冻结目录的数值策略（epsilon=0、r<=u、d>0、0<=tau<d）。这是前置条件检查，不认证来源字段真实、外部文件或执行上下文，也不替代完整图验证。admissible_pairs与来源事实仍须由可信调用方提供，不应把此CLI作为完整监测部署授权。

25个不合法载荷+5合法控制均为发现问题后构造的工程回归，非独立需求或人工语义标签。30输入包括None/空/缺失/重复角色、类型、单位、数值域、来源字段等。原24配置和v62的24词法控制完整返回记录保持字节一致。v62词法代码、评分器、输入CSV不改；validate_candidate.py加前置检查，旧测试中只有一处不完整单参数夹具换成完整N01两绑定，断言AST保持。

回归命令：
python run_binding_controls.py --module-dir legacy_v62 --protocol binding_protocol.json --output rerun_old --mode legacy
python run_binding_controls.py --module-dir fixed_entry --protocol binding_protocol.json --output rerun_new --mode fixed
python run_v62_guard_controls.py --module-dir fixed_entry --protocol v62_guard_protocol.json --output rerun_lexical --mode fixed
在legacy_v62和fixed_entry分别运行python -m unittest test_numeric_text_guard，各有7项。目录/CLI输入仅用于固定回归，不引入模型调用、训练、飞行、人工标签或监测判决。

诊断输出将实际传入的NaN/Inf标记成对象以保持严格JSON，不改变函数接收到的真实浮点值。公开v35和历史v62代码保留，不上传或替换历史评分。
