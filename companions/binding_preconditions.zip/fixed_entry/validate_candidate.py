"""Optional validation: binding preconditions -> numeric text -> candidate structure.

This new entry point is not silently substituted into the frozen historical runner.
Supplied source fields and admissible pairs remain caller-trusted inputs; these
preconditions do not authenticate provenance or replace the full graph verifier.
"""
from __future__ import annotations
import argparse,json,math
from pathlib import Path
from ablation_scoring import normalize_roles,graph_validate
from numeric_text_guard import bind_if_text_consistent

SIGNAL_UNITS={'speed_3d_mps':'m/s','height_m':'m','abs_roll_rad':'rad',
 'abs_pitch_rad':'rad','ang_rate_norm_rps':'rad/s'}
EXECUTABLE_ROLES={'invariant_upper':{'upper_bound','value_epsilon'},
 'bounded_response':{'trigger_upper','recovery_upper','deadline_seconds','dwell_seconds','value_epsilon'}}
SOURCE_FIELDS=('parameter_id','source_type','source_version','source_reference')

def binding_precondition_reason(candidate:dict,bindings:list[dict])->str|None:
 """Check a supplied JSON binding contract without coercing or authenticating it."""
 if not isinstance(candidate,dict):return 'candidate_not_object'
 if not isinstance(bindings,list):return 'bindings_not_list'
 template=candidate.get('template_id');signal=candidate.get('signal_id')
 if not isinstance(template,str) or not isinstance(signal,str):return 'unknown_binding_contract'
 if template not in EXECUTABLE_ROLES or signal not in SIGNAL_UNITS:return 'unknown_binding_contract'
 if any(not isinstance(b,dict) for b in bindings):return 'binding_not_object'
 roles=[b.get('role') for b in bindings]
 if any(not isinstance(role,str) for role in roles):return 'invalid_binding_role'
 if len(roles)!=len(EXECUTABLE_ROLES[template]) or set(roles)!=EXECUTABLE_ROLES[template]:
  return 'binding_role_cardinality'
 values={}
 for b in bindings:
  if any(not isinstance(b.get(key),str) or not b[key].strip() for key in SOURCE_FIELDS):
   return 'missing_binding_source_field'
  expected='s' if b['role'] in ('deadline_seconds','dwell_seconds') else SIGNAL_UNITS[signal]
  unit=b.get('unit');unit='rad/s' if unit=='rps' else unit
  if unit!=expected:return 'binding_unit_mismatch'
  value=b.get('value')
  if isinstance(value,bool) or not isinstance(value,(int,float)):return 'invalid_binding_value_type'
  try:finite=math.isfinite(value)
  except (OverflowError,TypeError,ValueError):finite=False
  if not finite:return 'nonfinite_binding_value'
  values[b['role']]=value
 if values['value_epsilon']!=0:return 'frozen_value_tolerance_policy'
 if template=='bounded_response':
  if values['deadline_seconds']<=0:return 'nonpositive_deadline'
  if not 0<=values['dwell_seconds']<values['deadline_seconds']:return 'invalid_dwell'
  if values['recovery_upper']>values['trigger_upper']:return 'recovery_above_trigger'
 return None

def validate_candidate(original_text:str,candidate:dict,bindings:list[dict],admissible_pairs:set[tuple[str,str]])->dict:
 reason=binding_precondition_reason(candidate,bindings)
 if reason is not None:
  return {'accepted':False,'stage':'binding_precheck','reason':reason,'numeric_check':None,'bound_values':None,'stkg_checked':False}
 numeric=bind_if_text_consistent(original_text,bindings)
 if not numeric['check']['accepted']:
  return {'accepted':False,'stage':'explicit_numeric_text','reason':numeric['check']['reason'],'numeric_check':numeric['check'],'bound_values':None,'stkg_checked':False}
 if candidate.get('scope')!='in_scope':
  return {'accepted':False,'stage':'candidate_scope','reason':'model_refusal','numeric_check':numeric['check'],'bound_values':None,'stkg_checked':False}
 accepted,reason=graph_validate(candidate.get('signal_id',''),candidate.get('template_id',''),normalize_roles(candidate.get('parameter_roles',[])),candidate.get('formula_structure',''),admissible_pairs)
 return {'accepted':bool(accepted),'stage':'stkg','reason':reason,'numeric_check':numeric['check'],'bound_values':numeric['bound_values'] if accepted else None,'stkg_checked':True}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('input_json',type=Path,help='Object with original_text, candidate, bindings, and admissible_pairs');a=ap.parse_args();p=json.loads(a.input_json.read_text(encoding='utf-8'))
 result=validate_candidate(p['original_text'],p['candidate'],p['bindings'],{tuple(x) for x in p['admissible_pairs']})
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
