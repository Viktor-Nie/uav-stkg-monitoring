"""Exercise binding preconditions through the actual portable candidate entry."""
from pathlib import Path
from hashlib import sha256
import argparse
import copy
import csv
import importlib
import json
import math
import sys


def json_safe(value):
    if isinstance(value,float) and not math.isfinite(value):
        return {'nonfinite_float':str(value)}
    if isinstance(value,dict):
        return {str(k):json_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):
        return [json_safe(v) for v in value]
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['module-dir','protocol','output']:
        parser.add_argument('--'+name,required=True,type=Path)
    parser.add_argument('--mode',choices=['legacy','fixed'],required=True)
    args=parser.parse_args()
    assert not args.output.exists()
    sys.path.insert(0,str(args.module_dir.resolve()))
    entry=importlib.import_module('validate_candidate')
    scoring=importlib.import_module('ablation_scoring')
    with (args.module_dir/'inputs/v4_complete_formula_catalog.csv').open(encoding='utf-8-sig',newline='') as f:
        catalog=list(csv.DictReader(f))
    assert len(catalog)==24
    pairs={(r['signal_id'],r['template_id']) for r in catalog}
    protocol=json.loads(args.protocol.read_text(encoding='utf-8'))
    outcomes=[]
    for case in protocol['cases']:
        row=next(r for r in catalog if r['formula_id']==('N01' if case['operation']=='valid_invariant' else 'N06'))
        b=json.loads(row['parameter_bindings_json'])
        def role(name):
            return next(v for v in b if v['role']==name)
        op,value=case['operation'],case['value']
        if op=='null_list':b=None
        elif op=='empty_list':b=[]
        elif op=='remove_role':b=[v for v in b if v['role']!=value]
        elif op=='duplicate_role':b.append(copy.deepcopy(role(value)))
        elif op=='extra_role':
            extra=copy.deepcopy(b[0]);extra['role']='unexpected';b.append(extra)
        elif op=='set_deadline':role('deadline_seconds')['value']=value
        elif op=='nonfinite_deadline':role('deadline_seconds')['value']=float(value)
        elif op=='set_dwell':role('dwell_seconds')['value']=value
        elif op=='recovery_above_trigger':role('recovery_upper')['value']=role('trigger_upper')['value']+1
        elif op=='set_epsilon':role('value_epsilon')['value']=value
        elif op=='deadline_unit':role('deadline_seconds')['unit']=value
        elif op=='signal_unit':role('trigger_upper')['unit']=value
        elif op=='blank_metadata':role('deadline_seconds')[value]='  '
        elif op=='remove_metadata':role('deadline_seconds').pop(value)
        elif op=='nonobject_record':b[0]='not a record'
        elif op=='unhashable_role':b[0]['role']=[]
        elif op=='unknown_applicability':role('deadline_seconds')['applicability_status']='unknown'
        else:assert op in ['valid_response','valid_invariant'],op
        candidate=dict(scope='in_scope',signal_id=row['signal_id'],template_id=row['template_id'],
                       parameter_roles=list(scoring.TEMPLATE_ROLES[row['template_id']]),
                       formula_structure=scoring.canonical_formula('in_scope',row['signal_id'],row['template_id']))
        before=json.dumps(json_safe(b),ensure_ascii=False,sort_keys=True)
        try:
            result=entry.validate_candidate('within the configured deadline',candidate,b,pairs)
            outcome=dict(result=json_safe(result),exception=None)
        except Exception as error:
            outcome=dict(result=None,exception=type(error).__name__)
        assert json.dumps(json_safe(b),ensure_ascii=False,sort_keys=True)==before,case['id']
        if args.mode=='fixed':
            assert outcome['exception'] is None,(case['id'],outcome)
            assert result['accepted']==case['expected_accepted'],(case['id'],result)
            if not case['expected_accepted']:
                assert result['stage']=='binding_precheck' and result['numeric_check'] is None
                assert result['bound_values'] is None and not result['stkg_checked']
        elif case['expected_accepted']:
            assert outcome['exception'] is None and result['accepted'],case['id']
        outcomes.append(dict(**case,**outcome))
    original=[]
    for row in catalog:
        b=json.loads(row['parameter_bindings_json'])
        candidate=dict(scope='in_scope',signal_id=row['signal_id'],template_id=row['template_id'],
                       parameter_roles=list(scoring.TEMPLATE_ROLES[row['template_id']]),
                       formula_structure=scoring.canonical_formula('in_scope',row['signal_id'],row['template_id']))
        result=entry.validate_candidate(row['source_requirement_text_zh'],candidate,b,pairs)
        assert result['accepted'] and result['bound_values']=={v['role']:v['value'] for v in b}
        original.append(dict(formula_id=row['formula_id'],result=result))
    args.output.mkdir(parents=True)
    for name,data in [('binding_results.json',outcomes),('original_24_results.json',original)]:
        (args.output/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    invalid=outcomes[:25]
    receipt=dict(status='passed',mode=args.mode,constructed_controls=30,invalid_payloads=25,valid_controls=5,
                 invalid_admitted=sum(o['result'] is not None and o['result']['accepted'] for o in invalid),
                 invalid_exceptions=sum(o['exception'] is not None for o in invalid),
                 invalid_structured_refusals=sum(o['result'] is not None and not o['result']['accepted'] for o in invalid),
                 valid_admitted=sum(o['result'] is not None and o['result']['accepted'] for o in outcomes[25:]),
                 original_24_accepted=24,protocol_sha256=sha256(args.protocol.read_bytes()).hexdigest(),
                 diagnostic_nonfinite_serialization='tagged objects only in diagnostic output; function inputs remain actual floats',
                 source_sha256={n:sha256((args.module_dir/n).read_bytes()).hexdigest() for n in
                     ['numeric_text_guard.py','validate_candidate.py','ablation_scoring.py','inputs/v4_complete_formula_catalog.csv']})
    (args.output/'binding_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__':
    main()
