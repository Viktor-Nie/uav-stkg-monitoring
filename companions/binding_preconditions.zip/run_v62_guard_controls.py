"""Exercise the real candidate entry, preserving text, bindings and stage outputs."""
from pathlib import Path
from hashlib import sha256
import argparse
import copy
import csv
import importlib
import json
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module-dir',required=True,type=Path)
    parser.add_argument('--protocol',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--mode',required=True,choices=['legacy','fixed'])
    args=parser.parse_args()
    assert not args.output.exists()
    sys.path.insert(0,str(args.module_dir.resolve()))
    entry=importlib.import_module('validate_candidate')
    scoring=importlib.import_module('ablation_scoring')
    with (args.module_dir/'inputs/v4_complete_formula_catalog.csv').open(encoding='utf-8-sig',newline='') as f:
        catalog=list(csv.DictReader(f))
    assert len(catalog)==24
    row=next(r for r in catalog if r['formula_id']=='N06')
    bindings=json.loads(row['parameter_bindings_json'])
    assert next(b for b in bindings if b['role']=='deadline_seconds')['value']==2
    candidate=dict(scope='in_scope',signal_id=row['signal_id'],template_id=row['template_id'],
                   parameter_roles=list(scoring.TEMPLATE_ROLES[row['template_id']]),
                   formula_structure=scoring.canonical_formula('in_scope',row['signal_id'],row['template_id']))
    pairs={(r['signal_id'],r['template_id']) for r in catalog}
    protocol=json.loads(args.protocol.read_text(encoding='utf-8'))
    outcomes=[]
    for probe in protocol['probes']:
        saved=copy.deepcopy(bindings)
        result=entry.validate_candidate(probe['text'],copy.deepcopy(candidate),bindings,pairs)
        assert bindings==saved
        expected=probe['expected_fixed_accepted'] if args.mode=='fixed' else True
        assert result['accepted']==expected,(args.mode,probe['id'],result)
        if expected:
            assert result['stkg_checked'] and result['bound_values']=={b['role']:b['value'] for b in bindings}
        else:
            assert not result['stkg_checked'] and result['bound_values'] is None and result['stage']=='explicit_numeric_text'
        outcomes.append(dict(**probe,result=result))
    original=[]
    for row in catalog:
        b=json.loads(row['parameter_bindings_json'])
        candidate=dict(scope='in_scope',signal_id=row['signal_id'],template_id=row['template_id'],
                       parameter_roles=list(scoring.TEMPLATE_ROLES[row['template_id']]),
                       formula_structure=scoring.canonical_formula('in_scope',row['signal_id'],row['template_id']))
        before=copy.deepcopy(b)
        result=entry.validate_candidate(row['source_requirement_text_zh'],candidate,b,pairs)
        assert result['accepted'] and result['bound_values']=={v['role']:v['value'] for v in b} and b==before
        original.append(dict(formula_id=row['formula_id'],result=result))
    args.output.mkdir(parents=True)
    for name,data in [('probe_results.json',outcomes),('original_24_results.json',original)]:
        (args.output/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipt=dict(status='passed',mode=args.mode,targeted_probes=len(outcomes),
                 unsupported_notation_probes=16,supported_controls=8,
                 unsupported_notation_admitted=sum(r['result']['accepted'] for r in outcomes[:16]),
                 supported_controls_admitted=sum(r['result']['accepted'] for r in outcomes[16:]),
                 original_24_accepted_unchanged=24,
                 protocol_sha256=sha256(args.protocol.read_bytes()).hexdigest(),
                 source_sha256={n:sha256((args.module_dir/n).read_bytes()).hexdigest() for n in
                    ['numeric_text_guard.py','validate_candidate.py','ablation_scoring.py','inputs/v4_complete_formula_catalog.csv']},
                 new_human_labels=0,new_model_predictions=0,new_monitor_verdicts=0)
    (args.output/'guard_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__':
    main()
