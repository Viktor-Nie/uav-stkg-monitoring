"""Independent SQL event/source join and count check; standard library only."""
import argparse
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import sqlite3

def read(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream))
def integer(value):
    n=Decimal(value)
    assert n.is_finite() and n==n.to_integral_value()
    return int(n)
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results',type=Path,required=True)
    p.add_argument('--coordinates',type=Path,required=True)
    p.add_argument('--events',type=Path,help='Optional complete frozen ledger for independent origin verification')
    args=p.parse_args()
    manifest=json.loads((args.results/'input_manifest.json').read_text(encoding='utf-8'))
    source={r['role']:r for r in manifest['sources']}
    assert sha256(args.coordinates.read_bytes()).hexdigest()==source['source_coordinates']['sha256']
    events=read(args.results/'event_coordinate_projection.csv');coords=read(args.coordinates)
    if args.events:
        assert sha256(args.events.read_bytes()).hexdigest()==source['events']['sha256']
        original=[r for r in read(args.events) if r['source']=='RflyMAD']
        assert len(original)==len(events)==864
        for number,(a,b) in enumerate(zip(events,original)):
            assert int(a['event_row'])==number
            for key in a:
                if key!='event_row':assert a[key]==b[key],(number,key)
    db=sqlite3.connect(':memory:');db.row_factory=sqlite3.Row
    db.executescript('''CREATE TABLE mapping(cas TEXT,topic TEXT,idx INTEGER,line INTEGER,grid INTEGER,age INTEGER,PRIMARY KEY(cas,topic,idx));
    CREATE TABLE events(rownum INTEGER,cas TEXT,formula TEXT,signal TEXT,typ TEXT,obs INTEGER,obligation TEXT,trg INTEGER);
    CREATE TABLE signals(signal TEXT PRIMARY KEY,topic TEXT);
    INSERT INTO signals VALUES ('speed_3d_mps','local_position'),('height_m','local_position'),
    ('abs_roll_rad','vehicle_attitude'),('abs_pitch_rad','vehicle_attitude'),('ang_rate_norm_rps','vehicle_angular_velocity');''')
    db.executemany('INSERT INTO mapping VALUES (?,?,?,?,?,?)',[(r['case_id'],r['topic'],integer(r['grid_index']),integer(r['source_csv_line']),integer(r['grid_timestamp_us']),integer(r['record_age_us'])) for r in coords])
    db.executemany('INSERT INTO events VALUES (?,?,?,?,?,?,?,?)',[(integer(r['event_row']),r['case_id'],r['formula_id'],r['signal_id'],r['event_type'],integer(r['observed_index']),r['obligation_id'],integer(r['trigger_index']) if r['trigger_index'] else None) for r in events])
    db.executescript('''CREATE VIEW joined AS SELECT e.*,s.topic,o.line obsline,o.age obsage,o.grid obsgrid,t.line trgline,t.age trgage,t.grid trggrid
    FROM events e JOIN signals s ON e.signal=s.signal JOIN mapping o ON e.cas=o.cas AND s.topic=o.topic AND e.obs=o.idx
    LEFT JOIN mapping t ON e.cas=t.cas AND s.topic=t.topic AND e.trg=t.idx;''')
    actual=list(db.execute('SELECT * FROM joined ORDER BY rownum'));expected=read(args.results/'event_source_join.csv')
    assert len(actual)==len(expected)==864
    for a,b in zip(actual,expected):
        assert a['obsline']==integer(b['observed_source_csv_line'])
        assert a['obsage']==integer(b['observed_record_age_us'])
        assert a['trgline']==(integer(b['trigger_source_csv_line']) if b['trigger_source_csv_line'] else None)
        assert a['trgage']==(integer(b['trigger_record_age_us']) if b['trigger_record_age_us'] else None)
        raw=events[a['rownum']]
        origin=db.execute('SELECT MIN(grid) FROM mapping WHERE cas=?',(a['cas'],)).fetchone()[0]
        assert Decimal(raw['relative_observed_time_seconds'])*1000000==a['obsgrid']-origin
        if raw['relative_trigger_time_seconds']:
            assert Decimal(raw['relative_trigger_time_seconds'])*1000000==a['trggrid']-origin
    bad=list(db.execute('''SELECT cas,formula,obligation FROM joined WHERE obligation<>'' GROUP BY cas,formula,obligation
    HAVING COUNT(*)<>2 OR SUM(typ='obligation_triggered')<>1 OR SUM(typ IN ('obligation_recovered','obligation_expired'))<>1
    OR MIN(trg)<>MAX(trg) OR MIN(trgline)<>MAX(trgline)'''));assert not bad
    checked=0
    for filename in ['case_event_summary.csv','formula_event_summary.csv']:
        for r in read(args.results/filename):
            where='cas=? AND typ=?';params=[r['case_id'],r['event_type']]
            if r['formula_id']!='ALL_CONFIGURATIONS':where+=' AND formula=?';params.append(r['formula_id'])
            counts=db.execute('SELECT COUNT(*),COUNT(DISTINCT formula||CHAR(31)||topic||CHAR(31)||obsline),COUNT(DISTINCT formula||CHAR(31)||topic||CHAR(31)||trgline),COALESCE(MAX(obsage),0),COALESCE(SUM(obsage>=100000),0) FROM joined WHERE '+where,params).fetchone()
            top=db.execute('SELECT COALESCE(MAX(n),0) FROM (SELECT COUNT(*) n FROM joined WHERE obligation<>\'\' AND '+where+' GROUP BY formula,topic,trgline)',params).fetchone()[0]
            for key,n in zip(['event_rows','distinct_observed_formula_record_pairs','distinct_trigger_formula_record_pairs','max_observed_record_age_us','observed_record_age_at_least_100ms_count'],counts):
                assert integer(r[key])==n,(filename,r,key,n)
            assert integer(r['max_obligations_per_trigger_formula_record'])==top
            checked+=1
    receipt={'status':'passed','method':'Independent SQLite joins, grouping and distinct formula/topic/source-row keys',
             'joined_events':864,'obligation_lineages':288,'aggregate_rows_checked':checked,
             'original_full_ledger_verified_this_run':bool(args.events),'all_output_rows_checked':True,
             'not_an_independent_physical_validation':True}
    (args.results/'independent_sql_verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False))

if __name__=='__main__':main()
