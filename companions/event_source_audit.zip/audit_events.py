"""Join the complete frozen RflyMAD event ledger to verified source coordinates.

This descriptive accounting never calls or changes a monitor. No state values
are copied to its coordinate-only projection. Refuses to overwrite results.
"""
from collections import Counter, defaultdict
from datetime import datetime,timezone
from decimal import Decimal
from hashlib import sha256
from pathlib import Path
import argparse
import csv
import json

SIGNAL_TOPICS={'speed_3d_mps':'local_position','height_m':'local_position',
               'abs_roll_rad':'vehicle_attitude','abs_pitch_rad':'vehicle_attitude',
               'ang_rate_norm_rps':'vehicle_angular_velocity'}
TYPES=['invariant_violation','obligation_triggered','obligation_recovered','obligation_expired']
FIELDS=['event_row','case_id','formula_id','signal_id','event_type','observed_index',
        'obligation_id','trigger_index','relative_observed_time_seconds','relative_trigger_time_seconds']
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def integer(text):
    value=Decimal(text)
    assert value.is_finite() and value==value.to_integral_value(),text
    return int(value)
def read(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream))
def write(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def csvout(path,rows):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events',type=Path,required=True)
    p.add_argument('--fingerprints',type=Path,required=True)
    p.add_argument('--source-coordinates',type=Path,required=True)
    p.add_argument('--coordinate-receipt',type=Path,required=True)
    p.add_argument('--protocol',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(f'Refusing to overwrite {args.output}')
    fp=json.loads(args.fingerprints.read_text(encoding='utf-8'))
    assert digest(args.events)==fp['fresh_output_sha256']['fresh_monitor_events.csv']
    protocol=json.loads(args.protocol.read_text(encoding='utf-8'))
    assert protocol['id']=='v57-event-source-dependence-20261104'
    assert digest(args.source_coordinates)==protocol['coordinate_sha256']
    assert json.loads(args.coordinate_receipt.read_text(encoding='utf-8'))['status']=='passed'
    events=[r for r in read(args.events) if r['source']=='RflyMAD']
    coordinates=read(args.source_coordinates)
    assert len(events)==864 and len(coordinates)==11139
    lookup={(r['case_id'],r['topic'],int(r['grid_index'])):r for r in coordinates}
    assert len(lookup)==11139
    origins={case:min(int(r['grid_timestamp_us']) for r in coordinates if r['case_id']==case) for case in ['406_1','406_2','407_1']}
    projections=[];joined=[];event_keys=set()
    for number,event in enumerate(events):
        case=event['case_id'];topic=SIGNAL_TOPICS[event['signal_id']];index=integer(event['observed_index'])
        mapping=lookup[case,topic,index]
        assert Decimal(event['relative_observed_time_seconds'])*1000000==int(mapping['grid_timestamp_us'])-origins[case]
        key=(case,event['formula_id'],event['event_type'],index,event['obligation_id'])
        assert key not in event_keys;event_keys.add(key)
        row={'event_row':number,**{k:event[k] for k in FIELDS if k!='event_row'}}
        projections.append(row)
        row={**row,'topic':topic,'observed_source_csv_line':int(mapping['source_csv_line']),
             'observed_record_age_us':int(mapping['record_age_us']),
             'trigger_source_csv_line':'','trigger_record_age_us':''}
        if event['obligation_id']:
            trigger=lookup[case,topic,integer(event['trigger_index'])]
            assert Decimal(event['relative_trigger_time_seconds'])*1000000==int(trigger['grid_timestamp_us'])-origins[case]
            row.update(trigger_source_csv_line=int(trigger['source_csv_line']),trigger_record_age_us=int(trigger['record_age_us']))
        joined.append(row)
    assert Counter(r['event_type'] for r in joined)==dict(zip(TYPES,[288,288,92,196]))
    # Verify obligation lineage before collapsing any event-to-record keys.
    obligations=defaultdict(dict)
    for row in joined:
        if row['obligation_id']:
            key=(row['case_id'],row['formula_id'],row['obligation_id'])
            assert row['event_type'] not in obligations[key]
            obligations[key][row['event_type']]=row
    assert len(obligations)==288
    for records in obligations.values():
        assert 'obligation_triggered' in records
        assert len(records)==2 and len(set(records)&{'obligation_recovered','obligation_expired'})==1
        assert len({r['trigger_index'] for r in records.values()})==1
        assert len({r['trigger_source_csv_line'] for r in records.values()})==1
    def summarize(case,formula,event_type,group):
        obs={(r['formula_id'],r['topic'],r['observed_source_csv_line']) for r in group}
        trigger={(r['formula_id'],r['topic'],r['trigger_source_csv_line']) for r in group if r['obligation_id']}
        origin_counts=Counter((r['formula_id'],r['topic'],r['trigger_source_csv_line']) for r in group if r['obligation_id'])
        return {'case_id':case,'formula_id':formula,'event_type':event_type,'event_rows':len(group),
                'distinct_observed_formula_record_pairs':len(obs),
                'distinct_trigger_formula_record_pairs':len(trigger),
                'max_obligations_per_trigger_formula_record':max(origin_counts.values(),default=0),
                'max_observed_record_age_us':max((r['observed_record_age_us'] for r in group),default=0),
                'observed_record_age_at_least_100ms_count':sum(r['observed_record_age_us']>=100000 for r in group)}
    bycase=[];byformula=[]
    for case in ['406_1','406_2','407_1']:
        for event_type in TYPES:
            group=[r for r in joined if r['case_id']==case and r['event_type']==event_type]
            bycase.append(summarize(case,'ALL_CONFIGURATIONS',event_type,group))
        for formula in sorted({r['formula_id'] for r in joined if r['case_id']==case}):
            for event_type in TYPES:
                group=[r for r in joined if r['case_id']==case and r['formula_id']==formula and r['event_type']==event_type]
                byformula.append(summarize(case,formula,event_type,group))
    args.output.mkdir(parents=True)
    csvout(args.output/'event_coordinate_projection.csv',projections)
    csvout(args.output/'event_source_join.csv',joined)
    csvout(args.output/'case_event_summary.csv',bycase)
    csvout(args.output/'formula_event_summary.csv',byformula)
    write(args.output/'input_manifest.json',{'sources':[{'role':name,'path':str(path),'sha256':digest(path)}
          for name,path in [('events',args.events),('fingerprints',args.fingerprints),('source_coordinates',args.source_coordinates),
                             ('coordinate_receipt',args.coordinate_receipt),('protocol',args.protocol)]],
          'original_source_fingerprint_match':True,'no_state_values_in_projection':True})
    write(args.output/'audit_receipt.json',{'status':'passed','events':864,'obligations':288,
          'case_event_rows':12,'formula_event_rows':len(byformula),'event_types':dict(Counter(r['event_type'] for r in joined)),
          'all_obligations_have_one_trigger_and_one_terminal_event':True,'new_predictions':0,'new_labels':0,'new_flights':0,
          'monitor_rerun':False,'deduplication_is_not_a_new_monitor_policy':True})
    print(json.dumps({'status':'passed','case_summary':bycase,'N06': [r for r in byformula if r['case_id']=='407_1' and r['formula_id']=='N06']},ensure_ascii=False))

if __name__=='__main__':main()
