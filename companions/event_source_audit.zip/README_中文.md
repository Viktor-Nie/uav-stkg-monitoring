# v57事件来源核查附件

只对已有864条RflyMAD事件及288个义务做来源对应和计数，不重跑或更改监测器、参数、判决或事件。distinct pair按案例、公式、topic、源CSV行计；不是独立故障或测量次数。全部12个案例/事件类型格保留，40个额外汇总行对应实际发出过事件的公式，并为这些公式保留四类事件。无事件公式不成为新试验。

## 附件内可直接检查

```powershell
python verify_events_sqlite.py --results results --coordinates point_source_coordinates.csv
```

这个模式用标准库SQLite重建观察/触发两个join及52个汇总，只验证所给坐标投影的一致性，不冒称取得了完整原事件表；其original_full_ledger_verified_this_run标志为false。

## 提供原始冻结事件表后完整重算

需要已有完整fresh_monitor_events.csv，其SHA应为0f3622278edf2b026368003baea9e8bcea1328e0b8b90e3bf7b9d6f1ee31d3ba。它包含四来源事件；本程序只投影RflyMAD的864行。原文件可由冻结v35研究包research/real_replay/reproduce_real_replays.py配合其明确要求的外部输入重建，须匹配对应冻结档案；不能拿只有RflyMAD的另一种表冒充完整文件。完整路径用你自己的路径替换：

```powershell
python audit_events.py --events 'D:/your-input/fresh_monitor_events.csv' --fingerprints frozen_replay_fingerprints.json --source-coordinates point_source_coordinates.csv --coordinate-receipt coordinate_verification.json --protocol protocol.json --output fresh_results
python verify_events_sqlite.py --results fresh_results --coordinates point_source_coordinates.csv --events 'D:/your-input/fresh_monitor_events.csv'
```

完整模式核原表SHA及全部投影字段，original_full_ledger_verified_this_run为true。两脚本仅用Python标准库，不需要联网或模型调用。audit_events.py拒绝覆盖已有输出目录。source坐标是v55全三日志/九原始流独立核过的11139行；上游完整原始重建另见v55_replay_source_audit.zip。

附件只包含事件与源记录索引、时间、类别和汇总，不含observed_value等状态测量值，不带原始飞行归档或完整事件表。新计算不增加独立飞行、人工标注或语义样本。
