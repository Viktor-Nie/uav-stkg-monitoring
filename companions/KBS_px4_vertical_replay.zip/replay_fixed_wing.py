"""Replay two recorded returns below the configured PX4 altitude ceiling."""

from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from pyulog import ULog


LOG_ID = "47a8d1ef-fb1c-43c6-9e4f-46f1e378c697"
RAW_SHA = "be11fa5d885c79b6ccf6d0ac254319cbf6c20bb4ea6bbd63c336a57f6e27d911"
FIRMWARE = "99c40407ffd7ac184e2d7b4b293f36f10fe561ef"
PARAMETERS = {"GF_ACTION": 3, "GF_MAX_VER_DIST": 100.0, "GF_MAX_HOR_DIST": 0.0,
              "GF_SOURCE": 0, "GF_PREDICT": 0, "COM_FAIL_ACT_T": 0.0, "SYS_HITL": 0}
TOPICS = ("home_position", "vehicle_global_position", "vehicle_local_position", "vehicle_status", "failsafe_flags")
CLOCK = 1_000_000


def replay(source, research):
    sys.path.insert(0, str(research.resolve()))
    from monitor.sampled_monitor import BoundedResponseSpecification, EventTimeObservationContract, monitor_bounded_response

    assert source.stat().st_size == 15_792_555 and sha256(source.read_bytes()).hexdigest() == RAW_SHA
    log = ULog(str(source), list(TOPICS))
    assert log.msg_info_dict["ver_sw"] == FIRMWARE
    assert {key: log.initial_parameters[key] for key in PARAMETERS} == PARAMETERS
    assert all(name not in PARAMETERS for _, name, _ in log.changed_parameters)
    home, position, local, status, flags = (log.get_dataset(topic).data for topic in TOPICS)
    assert not any(status["hil_state"])
    home_row = list(home["timestamp"]).index(1147804869)
    assert home["valid_alt"][home_row] and home["valid_hpos"][home_row]
    periods = [int(t) for t in position["timestamp"]]
    start = bisect_right(periods, int(home["timestamp"][home_row]) - 1)
    stop = bisect_right(periods, int(home["timestamp"][home_row + 1]) - 1)
    times = periods[start:stop]
    heights = position["alt"][start:stop] - home["alt"][home_row]
    ceiling = np.float32(PARAMETERS["GF_MAX_VER_DIST"])
    threshold = float(np.nextafter(ceiling, np.float32(-np.inf)))
    outside = heights >= ceiling
    assert min(np.diff(times)) > 0 and heights.dtype == np.float32
    assert np.array_equal(heights > threshold, outside) and not outside[0] and not outside[-1]
    edges = list(np.flatnonzero(outside[1:] != outside[:-1]) + 1)
    assert len(edges) == 4
    flag_edges = np.flatnonzero(flags["geofence_breached"][1:] != flags["geofence_breached"][:-1]) + 1
    assert list(flags["geofence_breached"][flag_edges]) == [1, 0, 1, 0]

    def pos_row(index):
        return {"row": int(start + index + 1), "publish_us": times[index],
                "sample_us": int(position["timestamp_sample"][start + index]), "home_relative_alt_m": float(heights[index])}

    episodes = []
    for (enter, leave), (rise, clear) in zip(zip(edges[::2], edges[1::2], strict=True),
                                            zip(flag_edges[::2], flag_edges[1::2], strict=True), strict=True):
        clip_times = times[enter - 1:leave + 1]
        first, last = clip_times[0], clip_times[-1]
        gap = int(max(np.diff(clip_times)))
        assert gap <= 250_000
        assert all(d.timestamp + 1000 * d.duration < first or d.timestamp > last for d in log.dropouts)
        states = slice(bisect_right(status["timestamp"], first) - 1, bisect_right(status["timestamp"], last))
        locals_ = slice(bisect_right(local["timestamp"], first) - 1, bisect_right(local["timestamp"], last))
        health = slice(bisect_right(flags["timestamp"], first) - 1, clear + 1)
        assert all(status["arming_state"][states] == 2) and not any(status["failsafe_and_user_took_over"][states])
        assert all(local["z_valid"][locals_]) and all(local["v_z_valid"][locals_])
        assert not any(flags["local_altitude_invalid"][health]) and not any(flags["global_position_invalid"][health])
        assert not any(position["dead_reckoning"][start+enter-1:start+leave+1])
        active_mode = int(status["nav_state"][states.stop - 1])
        assert active_mode == 5
        flag_rise, flag_clear = (int(flags["timestamp"][i]) for i in (rise, clear))
        assert times[enter] <= flag_rise < times[enter + 1] and last <= flag_clear < times[leave + 1]

        trace = pd.DataFrame({"time_seconds": [str(t) for t in clip_times], "home_alt_m": heights[enter-1:leave+1]})
        contract = EventTimeObservationContract(maximum_observation_gap_seconds=0.25, timestamp_epsilon_seconds=0.0)
        checks = {}
        for seconds in (2, 12):
            rule = BoundedResponseSpecification("home_alt_m", threshold, threshold, seconds, 0.0, 0.0)
            result = monitor_bounded_response(trace, rule, contract, timestamp_scale_seconds="0.000001")
            final = len(clip_times) - 1
            deadlines = {i: t + seconds * CLOCK for i, t in enumerate(clip_times) if 0 < i < final}
            expected = {i: ("obligation_recovered", final) if last <= due else
                        ("obligation_expired", bisect_right(clip_times, due)) for i, due in deadlines.items()}
            triggers = [event.observed_index for event in result.events if event.event_type == "obligation_triggered"]
            terminal = {event.trigger_index: (event.event_type, event.observed_index) for event in result.events
                        if event.event_type != "obligation_triggered"}
            assert triggers == list(deadlines) and terminal == expected
            checks[str(seconds)] = {"verdict": result.verdict.value, "terminals": dict(Counter(kind for kind, _ in terminal.values()))}
        episodes.append({"prior_inside": pos_row(enter - 1), "first_outside": pos_row(enter),
                         "last_outside": pos_row(leave - 1), "first_inside": pos_row(leave),
                         "publication_elapsed_us": last - times[enter],
                         "adjacent_row_elapsed_bounds_us": [times[leave - 1] - times[enter], last - first],
                         "observations": len(clip_times), "maximum_gap_us": gap,
                         "failsafe_edges_us": [flag_rise, flag_clear], "mode_at_return": active_mode,
                         "critical_failure_flag_during_interval": any(bool(x) for x in flags["fd_critical_failure"][health]),
                         "analysis_deadlines": checks})
    return {"log_id": LOG_ID, "raw_sha256": RAW_SHA, "firmware_commit": FIRMWARE, "parameters": PARAMETERS,
            "home_row": home_row + 1, "home_publish_us": int(home["timestamp"][home_row]),
            "home_amsl_m": float(home["alt"][home_row]), "float32_monitor_threshold_m": threshold,
            "deadline_provenance": "2 s and 12 s are post-hoc demonstration settings; no operational return deadline supplied.",
            "episodes": episodes}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("source", "research", "output"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(replay(args.source, args.research), indent=2) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
