# PX4 fixed-wing altitude-ceiling replay

Obtain the original ULog independently from Flight Review at
https://cdn.logs.px4.io/47a8d1ef-fb1c-43c6-9e4f-46f1e378c697.ulg

Use Python 3.10 or later with numpy, pandas and pyulog.

    python -B replay_fixed_wing.py LOG.ulg research rerun.json

The receipt contains source topic rows, publication and sample clocks,
geofence flag edges and monitor outcomes for two recorded excursions.
Compare rerun.json against fixed_wing_receipt.json. The two deadlines are post hoc
replay settings. The ULog is hosted by Flight Review.
