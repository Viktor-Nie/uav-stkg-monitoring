# PX4 home-radius fence replay

Download the public geofence_test ULog from the Flight Review service.
https://cdn.logs.px4.io/47c0836c-9abc-4ed0-9c14-1800bc7fe75d.ulg

Use Python 3.10 or later with pyulog and pandas. Then run the replay.

    python -B replay_px4_geofence.py LOG.ulg research rerun.json

The script checks the original ULog hash, reproduces position-row and failsafe
coordinates, and compares all monitor events with an integer-clock check.
Compare rerun.json to px4_geofence_receipt.json. The analysis uses 10 and 12 s after the
logged exceedance. Both deadlines were selected for the demonstration.
