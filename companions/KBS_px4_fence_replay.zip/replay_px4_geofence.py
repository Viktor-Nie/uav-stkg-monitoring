"""Replay a recorded PX4 home-radius breach and return from native ULog rows."""

from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from hashlib import sha256
from math import atan2, cos, radians, sin, sqrt
from pathlib import Path
from struct import pack, unpack
import json
import sys

import pandas as pd
from pyulog import ULog


LOG_ID = "47c0836c-9abc-4ed0-9c14-1800bc7fe75d"
FIRMWARE = "94cb2012792b2ae89f0b147cfee53ee31ae550be"
SHA256 = "262f027115504cd177be6f7168a22f57d73fa237bf8392b2023b6e2299d8b171"
TOPICS = ("home_position", "vehicle_global_position", "vehicle_status", "failsafe_flags")
PARAMETERS = {"GF_MAX_HOR_DIST": 20.0, "GF_MAX_VER_DIST": 30.0, "GF_SOURCE": 0,
              "GF_PREDICT": 0, "GF_ACTION": 3, "COM_FAIL_ACT_T": 5.0, "SYS_HITL": 0}
DEADLINES = (10, 12)


def distance_m(lat, lon, home_lat, home_lon):
    lat, lon, home_lat, home_lon = map(radians, (lat, lon, home_lat, home_lon))
    a = sin((lat - home_lat) / 2) ** 2 + sin((lon - home_lon) / 2) ** 2 * cos(home_lat) * cos(lat)
    distance = 6_371_000 * 2 * atan2(sqrt(a), sqrt(1 - a))
    return unpack("<f", pack("<f", distance))[0]


def first_edges(values):
    return [i for i in range(1, len(values)) if values[i - 1] != values[i]]


def replay(source, research):
    sys.path.insert(0, str(research.resolve()))
    from monitor.sampled_monitor import BoundedResponseSpecification, EventTimeObservationContract, monitor_bounded_response

    native = source.read_bytes()
    digest = sha256(native).hexdigest()
    assert len(native) == 3_817_222 and digest == SHA256
    log = ULog(str(source), list(TOPICS))
    assert log.msg_info_dict["ver_sw"] == FIRMWARE and not log.dropouts
    parameters = {k: log.initial_parameters[k] for k in PARAMETERS}
    assert parameters == PARAMETERS
    assert all(name not in PARAMETERS for _, name, _ in log.changed_parameters)
    home, global_pos, status, flags = (log.get_dataset(name).data for name in TOPICS)
    assert not any(status["hil_state"])

    # Use the final valid Home fix. All observations in the tested span use this reference.
    home_i = len(home["timestamp"]) - 1
    assert home["valid_hpos"][home_i] and home["valid_alt"][home_i]
    first = bisect_right(global_pos["timestamp"], int(home["timestamp"][home_i]) - 1)
    positions = range(first, len(global_pos["timestamp"]))
    assert all(global_pos["lat_lon_valid"][i] and global_pos["alt_valid"][i] for i in positions)
    times = [int(global_pos["timestamp"][i]) for i in positions]
    gap_us = max(second - first for first, second in zip(times, times[1:]))
    assert min(second - first for first, second in zip(times, times[1:])) > 0
    assert max(abs(global_pos["alt"][i] - home["alt"][home_i]) for i in positions) < parameters["GF_MAX_VER_DIST"]
    distances = [distance_m(global_pos["lat"][i], global_pos["lon"][i], home["lat"][home_i], home["lon"][home_i])
                 for i in positions]
    radius = parameters["GF_MAX_HOR_DIST"]
    outside = [distance >= radius for distance in distances]
    enter, leave = first_edges(outside)
    assert not outside[0] and outside[enter] and not outside[leave]

    def coordinate(local_i):
        i = first + local_i
        return {"topic_row": i + 1, "publish_us": times[local_i],
                "estimator_sample_us": int(global_pos["timestamp_sample"][i]),
                "distance_m": distances[local_i], "horizontal_eph_m": float(global_pos["eph"][i])}

    flag_in, flag_out = first_edges(flags["geofence_breached"])
    assert not flags["geofence_breached"][0] and flags["geofence_breached"][flag_in]
    flag_start = int(flags["timestamp"][flag_in])
    flag_end = int(flags["timestamp"][flag_out])
    assert times[enter] <= flag_start < times[enter + 1] and times[leave] <= flag_end < times[leave + 1]

    hold_i = next(i for i, t in enumerate(status["timestamp"]) if t >= flag_start and status["nav_state"][i] == 4)
    return_i = next(i for i in range(hold_i + 1, len(status["timestamp"])) if status["nav_state"][i] == 5)
    assert all(status["arming_state"][i] == 2 for i in range(hold_i, return_i + 1))
    hold, rtl = (int(status["nav_state_timestamp"][i]) for i in (hold_i, return_i))
    assert flag_start <= hold < rtl < times[leave]

    # The PX4 distance is binary32. Its predecessor of the radius translates the
    # firmware's >= trigger and < recovery into the monitor's > and <= guards.
    radius_bits = unpack("<I", pack("<f", radius))[0]
    predecessor = unpack("<f", pack("<I", radius_bits - 1))[0]
    assert all((value > predecessor) == is_outside for value, is_outside in zip(distances, outside))
    profile = EventTimeObservationContract(maximum_observation_gap_seconds=0.25, timestamp_epsilon_seconds=0.0)
    trace = pd.DataFrame({"time_seconds": [str(t) for t in times], "home_distance_m": distances})
    checks = {}
    for seconds in DEADLINES:
        specification = BoundedResponseSpecification("home_distance_m", predecessor, predecessor,
                                                     seconds, 0.0, 0.0)
        result = monitor_bounded_response(trace, specification, profile, timestamp_scale_seconds="0.000001")
        expected = {}
        for i in range(enter, leave):
            due = times[i] + seconds * 1_000_000
            expected[i] = (("obligation_recovered", leave) if times[leave] <= due else
                           ("obligation_expired", bisect_right(times, due)))
        created = [event.observed_index for event in result.events if event.event_type == "obligation_triggered"]
        terminal = {event.trigger_index: (event.event_type, event.observed_index) for event in result.events
                    if event.event_type != "obligation_triggered"}
        assert created == list(expected) and terminal == expected
        kind, end = expected[enter]
        checks[str(seconds)] = {"trace_verdict": result.verdict.value, "trigger_samples": len(created),
                                "terminal_counts": dict(Counter(kind for kind, _ in expected.values())),
                                "first_trigger_outcome": kind, "first_trigger_terminal": coordinate(end)}

    return {"log_id": LOG_ID, "sha256": digest, "firmware_commit": FIRMWARE, "parameters": parameters,
            "source": "PX4 Flight Review, physical quadrotor with hardware-in-the-loop disabled",
            "analysis_scope": "Fused global-position estimate, final valid Home, source publication clock, no interpolation.",
            "sampled_outside": "horizontal distance >= 20 m based on firmware binary32 comparison",
            "analysis_deadline_note": "10 s and 12 s are post-hoc monitor demonstrations; firmware 5 s governs Hold before the next action.",
            "home_topic_row": home_i + 1, "home_publish_us": int(home["timestamp"][home_i]),
            "observations": len(times), "max_gap_us": gap_us, "peak_distance_m": max(distances),
            "last_inside_before_breach": coordinate(enter - 1), "first_outside": coordinate(enter),
            "last_outside": coordinate(leave - 1), "first_inside_after_breach": coordinate(leave),
            "sampled_elapsed_us": times[leave] - times[enter],
            "failsafe_flag": {"first_true_topic_row": flag_in + 1, "first_true_us": flag_start,
                              "first_false_topic_row": flag_out + 1, "first_false_us": flag_end},
            "nav_state": {"hold_topic_row": hold_i + 1, "hold_us": hold,
                          "return_topic_row": return_i + 1, "return_us": rtl},
            "float32_monitor_threshold_m": predecessor, "checks": checks}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("source", "research", "output"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(replay(args.source, args.research), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
