"""Independently check integer-time admission and future-scan obligation sets."""
from __future__ import annotations
import argparse
import csv
from hashlib import sha256
import importlib.util
import json
import math
from pathlib import Path
import sys

import pandas as pd


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', required=True, type=Path)
    parser.add_argument('--protocol', required=True, type=Path)
    parser.add_argument('--reference', required=True, type=Path)
    args = parser.parse_args()
    target = args.results / 'independent_verification.json'
    assert not target.exists()
    spec = importlib.util.spec_from_file_location('v58_independent_reference', args.reference)
    oracle = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = oracle
    spec.loader.exec_module(oracle)
    protocol = load(args.protocol)
    manifest = load(args.results / 'input_manifest.json')
    assert digest(args.protocol) == manifest['protocol_sha256']
    inputs = {}
    for r in manifest['diagnostic_traces']:
        path = args.results / r['file']
        assert digest(path) == r['sha256']
        data = pd.read_csv(path, encoding='utf-8-sig')
        # Integer coordinate checks do not use production admission code.
        with path.open(encoding='utf-8-sig', newline='') as stream:
            integer_times = [int(row['timestamp_us']) for row in csv.DictReader(stream)]
        assert integer_times == data.timestamp_us.tolist()
        data['time_seconds'] = [(t-integer_times[0])/1000000 for t in integer_times]
        inputs[(r['case_id'], r['route'])] = (data, integer_times)
    configs = {r['formula_id']: r for r in load(args.results / 'configurations.json')}
    signatures = {(r['case_id'], r['profile'], r['formula_id']): r
                  for r in load(args.results / 'obligation_signatures.json')}
    topic = {'speed_3d_mps': 'local_position', 'height_m': 'local_position',
             'abs_roll_rad': 'vehicle_attitude', 'abs_pitch_rad': 'vehicle_attitude',
             'ang_rate_norm_rps': 'vehicle_angular_velocity'}
    results = pd.read_csv(args.results / 'configuration_results.csv', encoding='utf-8-sig').fillna('')
    checked, accepted, rejected = [], 0, 0
    for row in results.to_dict('records'):
        c = configs[row['formula_id']]
        params = c['specification']
        route = 'grid' if row['profile'] == 'grid_frozen' else topic[params['signal']]
        data, times = inputs[(row['case_id'], route)]
        settings = protocol['profiles'][row['profile']]
        limit_us = round(1000000 * settings.get('maximum_gap_seconds', settings.get('maximum_observation_gap_seconds', 0)))
        gaps = [b-a for a, b in zip(times, times[1:])]
        eligible = (len(times) >= 2 and all(0 < gap <= limit_us for gap in gaps)
                    and all(math.isfinite(v) for v in data[params['signal']]))
        if route == 'grid':
            eligible = eligible and all(47500 <= gap <= 52500 for gap in gaps)
        key = (row['case_id'], row['profile'], row['formula_id'])
        actual = signatures[key]
        if not eligible:
            assert row['verdict'] == 'rejected_input_contract', key
            assert row['input_reasons']
            assert all(not actual[k] for k in ['violating_indices', 'trigger_indices', 'recovered_ids', 'expired_ids', 'pending_ids'])
            assert all(row[k] == 0 for k in ['violations', 'triggered', 'recovered', 'expired', 'pending'])
            rejected += 1
        else:
            accepted += 1
            if c['template'] == 'invariant_upper':
                value = oracle.evaluate_invariant(data, **params)
                assert list(value.violating_sample_indices) == actual['violating_indices'], key
                assert len(value.violating_sample_indices) == row['violations']
                assert all(not actual[k] for k in ['trigger_indices', 'recovered_ids', 'expired_ids', 'pending_ids'])
            else:
                value = oracle.evaluate_bounded_response(data, **params, timestamp_epsilon_seconds=1e-9)
                for expected, field in [('trigger_indices', 'trigger_indices'),
                                        ('recovered_obligation_ids', 'recovered_ids'),
                                        ('expired_obligation_ids', 'expired_ids'),
                                        ('pending_obligation_ids', 'pending_ids')]:
                    assert list(getattr(value, expected)) == actual[field], (key, field)
                assert [len(actual[k]) for k in ['trigger_indices', 'recovered_ids', 'expired_ids', 'pending_ids']] == [row[k] for k in ['triggered', 'recovered', 'expired', 'pending']]
            assert value.verdict == row['verdict'], key
        checked.append(key)
    assert len(checked) == 81 and len(set(checked)) == 81
    summaries = pd.read_csv(args.results / 'case_profile_summary.csv', encoding='utf-8-sig')
    for r in summaries.to_dict('records'):
        group = results[(results.case_id == r['case_id']) & (results.profile == r['profile'])]
        assert len(group) == r['configurations'] == 9
        for field, label in [('satisfied', 'satisfied'), ('violated', 'violated'),
                             ('inconclusive', 'inconclusive_end_of_trace'), ('rejected', 'rejected_input_contract')]:
            assert int((group.verdict == label).sum()) == r[field]
        for field in ['violations', 'triggered', 'recovered', 'expired', 'pending']:
            assert int(group[field].sum()) == r[field]
    pivot = results.pivot(index=['case_id', 'formula_id'], columns='profile', values='verdict')
    matched = int((pivot.grid_frozen == pivot.native_1p0).sum())
    receipt = {'status': 'passed', 'attempts': len(checked), 'accepted': accepted,
               'rejected': rejected, 'full_obligation_and_violation_sets_checked': True,
               'integer_microsecond_admission_independently_checked': True,
               'summary_rows_checked': len(summaries), 'grid_native_1s_matching_configuration_verdicts': matched,
               'matching_verdict_denominator': 27, 'new_flights': 0,
               'reference_sha256': digest(args.reference)}
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
