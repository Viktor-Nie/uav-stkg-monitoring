# 原始消息时刻敏感性核查附件

这是已有3段RflyMAD日志、9个冻结配置的81次观测方式比较，不是81个独立样本。0.10秒与1.0秒是先固定的事件时间间隔预算，1.0秒只作未标定的探索比较；所有拒绝保留，不选择最好结果。

本包含程序、原监测实现与图配置、原始输入指纹、方案、81行完整结果、9行案例汇总和完整义务签名。原始遥测及新派生轨迹值未放入包内；须提供frozen_replay_fingerprints.json所列外部原始文件和目录结构（materials目录内容），包括完整Real-Motor.zip。本包不会下载、训练、调用模型或修改原实验。

在解压目录运行（Python须已装numpy、pandas、scipy）：

```powershell
python -B run_native_sensitivity.py --protocol native_time_protocol.json --fingerprints frozen_replay_fingerprints.json --source-helper audit_sources.py --monitor-dir monitor --raw-root C:/实际路径/materials --output fresh_results
python -B verify_native_sensitivity.py --results fresh_results --protocol native_time_protocol.json --reference independent_reference_semantics.py
```

不能直接把results交给独立核验程序而省略外部原始重建，因为该核验还需要fresh_results/traces中现场重建的输入。完整原始文件先核SHA，原6份网格CSV必须精确重建；两实现共用已保存输入，但准入与语义计算分别实现。原配置/判决/义务签名应能与results逐字节核对；input_manifest中的运行路径及monitor_files清单随原生快照裁剪而不同，应按具体文件SHA核查，而不能宣称该清单整文件字节相同。

原消息在固定网格首末时刻的闭区间内按topic分别保留，不合成边界点、不跨topic对齐；各流首末观察时刻不同。网格与原始路线共同改变采样、保持和终端观察，不能把义务差异全归因某一因素，更不能把更少过期义务称更高检测准确率。原v35/v57结果继续保留。
