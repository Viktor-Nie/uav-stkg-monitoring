"""Trace the published CoDrone recovery times to observations in Table S1."""

from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from io import StringIO
from pathlib import Path
from zipfile import ZipFile
import csv
import json


ARCHIVE_SHA = "dedba847f8c6dfa0225920c66379b4fe588c24d8ce5440312a7d82665cc27007"
MEMBER = "Table S1. Flight data.csv"
METHODS = {"PPO": 0, "Hybrid-DGRL": 4, "PID": 8}
EXPECTED = {"PPO": (16, 18, Decimal("4.50")), "Hybrid-DGRL": (15, 16, Decimal("2.34"))}


def in_band(value):
    return 95 <= value <= 105


def record(row, time, altitude):
    return {"source_csv_line": row, "time_s": str(time), "altitude_cm": str(altitude)}


def audit(path):
    archive_sha = sha256(path.read_bytes()).hexdigest()
    assert archive_sha == ARCHIVE_SHA
    with ZipFile(path) as archive:
        raw = archive.read(MEMBER)
    rows = list(csv.reader(StringIO(raw.decode("utf-8-sig"), newline="")))
    records = {}
    for method, col in METHODS.items():
        assert rows[0][col:col + 3] == ["ControlMethod", "Time (s)", "Altitude (m)"]
        trace = [(i, Decimal(row[col + 1]), Decimal(row[col + 2]))
                 for i, row in enumerate(rows[1:], 2) if row[col]]
        assert all(rows[i - 1][col] == method for i, _, _ in trace)
        gaps = [second[1] - first[1] for first, second in zip(trace, trace[1:])]
        assert min(gaps) > 0
        last_outside = max(i for i, (_, _, height) in enumerate(trace) if not in_band(height))
        suffix = trace[last_outside + 1:]
        summary = {"samples": len(trace), "gap_range_s": [str(min(gaps)), str(max(gaps))],
                   "last_outside_band": record(*trace[last_outside]),
                   "first_row_of_final_in_band_suffix": record(*suffix[0]), "suffix_samples": len(suffix),
                   "observed_duration_of_suffix_s": str(suffix[-1][1] - suffix[0][1])}
        if method in EXPECTED:
            start_line, end_line, reported = EXPECTED[method]
            start = next(row for row in trace if row[0] == start_line)
            end = suffix[0]
            assert end[0] == end_line and end[1] - start[1] == reported and not in_band(start[2])
            summary["published_duration_matching_sample_difference"] = {
                "out_of_band_sample": record(*start), "reentry_sample": record(*end), "difference_s": str(reported)}
        records[method] = summary
    assert {name: rec["samples"] for name, rec in records.items()} == {"PPO": 28, "Hybrid-DGRL": 27, "PID": 48}
    return {"paper_doi": "10.3390/drones10010002", "archive_sha256": archive_sha, "member": MEMBER,
            "member_sha256": sha256(raw).hexdigest(), "band_cm": [95, 105],
            "altitude_unit_note": "CSV header says m; values are read as cm to match the experimental setup and plotted target.",
            "scope": "The released data have no gust-onset field. Matching sample differences do not verify the gust anchor or continuous in-band residence.",
            "methods": records}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(audit(args.archive), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
