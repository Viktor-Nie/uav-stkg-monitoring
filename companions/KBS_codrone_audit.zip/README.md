# CoDrone observation audit

Download the supplementary archive for https://doi.org/10.3390/drones10010002
from the publisher at
https://pub.mdpi-res.com/drones/drones-10-00002/article_deploy/drones-10-00002-s001.zip

With Python 3.10 or later, pass that ZIP to the audit script.

    python -B audit_codrone.py drones-10-00002-s001.zip rerun.json

Check rerun.json against codrone_observations.json. The CSV altitude heading
says m. The script interprets the values in cm to match the source experiment.
The CSV gives sampled aircraft response and has no gust-onset field.
