"""Recover a recorded VTOL phase limit and its source-row evidence."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from pyulog import ULog


LOG_ID = "352f7e94-1670-4036-b5f7-9e936042b1d1"
SHA = "8d2c992def4f4d2f219a0a41f517ed41b10e50040d13a02d3c382a9088f3a229"
BUILD = "99c40407ffd7ac184e2d7b4b293f36f10fe561ef"
CONFIG = {"VT_TRANS_MIN_TM": 2.0, "VT_TRANS_TIMEOUT": 20.0, "VT_ARSP_TRANS": 20.0,
          "VT_F_TR_OL_TM": 15.0, "VT_ARSP_BLEND": 15.0, "FW_USE_AIRSPD": 1,
          "WEIGHT_BASE": -1.0, "WEIGHT_GROSS": -1.0, "SYS_HITL": 0, "VT_TYPE": 2}
TOPICS = ("vtol_vehicle_status", "airspeed_validated", "vehicle_air_data", "vehicle_land_detected", "vehicle_status")


def audit(source):
    assert source.stat().st_size == 4_280_589 and sha256(source.read_bytes()).hexdigest() == SHA
    log = ULog(str(source), list(TOPICS))
    assert log.msg_info_dict["ver_sw"] == BUILD
    assert {name: log.initial_parameters[name] for name in CONFIG} == CONFIG
    assert all(name not in CONFIG for _, name, _ in log.changed_parameters)
    vtol, air, baro, ground, status = (log.get_dataset(name).data for name in TOPICS)
    assert not status["hil_state"].any()
    states = vtol["vehicle_vtol_state"]
    start = int(np.flatnonzero(states == 1)[0])
    end = int(np.flatnonzero(states == 4)[0])
    assert states[start - 1] == 3 and np.all(states[start:end] == 1)
    state_time = vtol["timestamp"]
    t0, t1 = (int(state_time[i]) for i in (start, end))
    before_land = np.searchsorted(ground["timestamp"], t0, side="right") - 1
    after_land = np.searchsorted(ground["timestamp"], t1, side="right")
    assert not ground["landed"][before_land:after_land].any()
    assert all(d.timestamp + 1000 * d.duration < t0 or d.timestamp > t1 for d in log.dropouts)

    times, speeds = air["timestamp"], air["calibrated_airspeed_m_s"]
    left = np.searchsorted(times, t0)
    right = np.searchsorted(times, t1, side="right")
    phase = slice(left, right)
    assert np.all(air["airspeed_sensor_measurement_valid"][phase]) and np.all(air["selected_airspeed_index"][phase] == 1)
    assert np.isfinite(speeds[phase]).all()
    threshold = CONFIG["VT_ARSP_TRANS"]
    high = np.flatnonzero(speeds[phase] >= threshold)
    assert len(high) == 1
    edge = int(left + high[0])
    assert speeds[edge - 1] < threshold and speeds[edge + 1] < threshold
    t_hit = int(times[edge])

    density_times = baro["timestamp"]
    density = baro["rho"][(density_times >= t0) & (density_times <= t1)]
    assert np.isfinite(density).all()
    rho_min, rho_max = float(min(density)), float(max(density))
    assert 0.7 <= rho_min <= rho_max <= 1.5
    factors = [(1.225 / rho) ** 1.5 for rho in (rho_max, rho_min)]
    minima = [CONFIG["VT_TRANS_MIN_TM"] * factor for factor in factors]
    limits = [CONFIG["VT_TRANS_TIMEOUT"] * factor for factor in factors]
    assert max(minima) < (t_hit - t0) / 1e6 < min(limits)

    return {
        "log_id": LOG_ID, "sha256": SHA, "firmware": BUILD, "configured_parameters": CONFIG,
        "start_phase": {"topic_row": start + 1, "publish_us": t0},
        "fixed_wing_mode": {"topic_row": end + 1, "publish_us": t1},
        "neighboring_airspeed_rows": [{"topic_row": i + 1, "publish_us": int(times[i]), "calibrated_m_s": float(speeds[i])}
                                      for i in (edge - 1, edge, edge + 1)],
        "phase_airspeed_rows": int(right - left), "qualifying_rows_in_phase": len(high),
        "phase_to_qualifying_row_us": t_hit - t0, "qualifying_row_to_fixed_wing_us": t1 - t_hit,
        "phase_duration_us": t1 - t0,
        "adjacent_airspeed_publication_span_us": int(times[edge + 1]) - int(times[edge - 1]),
        "published_phase_density_kg_m3": [rho_min, rho_max],
        "density_scaled_minimum_seconds_from_logged_rows": minima,
        "density_scaled_timeout_seconds_from_logged_rows": limits,
        "scope": "Logged phase transition and indicated gate. No independent airspeed or within-gap sensor timing."
    }


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("ulog", type=Path)
    cli.add_argument("receipt", type=Path)
    args = cli.parse_args()
    args.receipt.write_text(json.dumps(audit(args.ulog), indent=2) + "\n", encoding="utf-8", newline="\n")
