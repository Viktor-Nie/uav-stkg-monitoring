# PX4 VTOL phase audit

Obtain the original flight log from https://cdn.logs.px4.io/352f7e94-1670-4036-b5f7-9e936042b1d1.ulg .
Use Python with numpy and pyulog.

    python -B audit_vtol.py LOG.ulg comparison.json

Compare comparison.json to vtol_receipt.json. Topic row numbers are one-based
and timestamps are onboard publications. The density-scaled bounds use the
published density rows during the observed transition. The trace evaluates
the indicated airspeed gate and the phase clock.
