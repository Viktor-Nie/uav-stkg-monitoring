"""Matched, post-inspection probes of the frozen STKG verification pipeline."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path
from types import FunctionType

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = next((parent for parent in HERE.parents if (parent / "HANDOFF.md").is_file()), HERE)
SNAPSHOT = ROOT / "docs/最终论文/latex_kbs_v77_advisor_revision_20261110/research"
SOURCE_AUDIT = ROOT / "analysis/results/96_kbs_full_checklist_20261014/github_v34_checkout/research/historical_audits"
CHECKS = ("threshold_role", "signal_scope", "execution_context", "source_pointer")
MODES = ("full", *CHECKS)
PARAM_FIELDS = (
    "value", "unit", "source_type", "source_reference", "source_version",
    "adoption_status", "platform_context", "vehicle_context",
    "flight_mode_context", "firmware_context", "applicability_status",
)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_graph_checkers(directory):
    frozen_path = directory / "frozen_validator_reference.py"
    frozen = load_module("frozen_validator_reference", frozen_path)
    extension = load_module("validation_extension", directory / "validation_extension.py")
    edited = frozen_path.read_text(encoding="utf-8-sig")
    replacements = (
        ("if str(parameter.get(\"policy\")) != expected_policy:",
         "if 'threshold_role' not in disabled and str(parameter.get(\"policy\")) != expected_policy:"),
        ("if str(parameter.get(\"signal_scope\")) != signal_id.removeprefix(\"signal:\"):",
         "if 'signal_scope' not in disabled and str(parameter.get(\"signal_scope\")) != signal_id.removeprefix(\"signal:\"):"),
        ("or str(parameter.get(\"signal_scope\"))\n                        != signal_id.removeprefix(\"signal:\")",
         "or ('signal_scope' not in disabled and str(parameter.get(\"signal_scope\"))\n                            != signal_id.removeprefix(\"signal:\"))"),
    )
    for original, changed in replacements:
        assert edited.count(original) == 1, original
        edited = edited.replace(original, changed)
    namespace = {}
    exec(compile(edited, str(frozen_path), "exec"), namespace)
    targeted_check = namespace["validate_variant"]

    def graph_for(mode):
        if mode == "execution_context":
            return lambda nodes, edges: extension.validate_extended(
                nodes, edges, frozenset({"context_consistency"})
            )
        if mode in ("threshold_role", "signal_scope"):
            def frozen_gate(nodes, edges):
                return targeted_check(nodes, edges, frozenset({mode}))
            function = extension.validate_extended
            return FunctionType(
                function.__code__,
                {**function.__globals__, "validate_variant": frozen_gate},
                function.__name__,
                function.__defaults__,
            )
        return extension.validate_extended

    return frozen, extension, {mode: graph_for(mode) for mode in MODES}


def change_node(nodes, identifier, **fields):
    index, = nodes.index[nodes["id"].eq(identifier)]
    row = json.loads(nodes.at[index, "properties_json"])
    nodes.at[index, "properties_json"] = json.dumps({**row, **fields}, sort_keys=True)


def rebind(base_nodes, base_edges, base_bindings, row, replacement, parameter):
    nodes, edges, bindings = base_nodes.copy(), base_edges.copy(), base_bindings.copy()
    binding_id = "binding:" + row.binding_id
    change_node(nodes, binding_id, parameter_id=replacement)
    index, = edges.index[edges["source"].eq(binding_id) & edges["relation"].eq("BINDS_PARAMETER")]
    edges.at[index, "target"] = replacement
    index, = bindings.index[bindings["binding_id"].eq(row.binding_id)]
    bindings.at[index, "parameter_id"] = replacement.removeprefix("parameter:")
    for field in PARAM_FIELDS:
        bindings.at[index, field] = parameter[field]
    return nodes, edges, bindings


def numerical_order_preserved(row, replacement, base_bindings):
    if row.role not in ("trigger_upper", "recovery_upper"):
        return True
    other_role = "recovery_upper" if row.role == "trigger_upper" else "trigger_upper"
    peer = base_bindings.loc[
        base_bindings["formula_id"].eq(row.formula_id) & base_bindings["role"].eq(other_role), "value"
    ].item()
    if row.role == "trigger_upper":
        return replacement["value"] >= peer
    return replacement["value"] <= peer


def build_pairs(base, meta, context_fields, ref_by_type):
    nodes, edges, bindings = base
    parameters = {key: value for key, value in meta.items() if key.startswith("parameter:")}
    pairs, excluded = [], []

    for row in bindings.itertuples(index=False):
        identifier = "parameter:" + row.parameter_id
        current = parameters[identifier]
        if current["parameter_kind"] == "threshold":
            replacement, = [
                key for key, value in parameters.items()
                if value["parameter_kind"] == "threshold"
                and value["signal_scope"] == current["signal_scope"]
                and value["policy"] != current["policy"]
            ]
            assert numerical_order_preserved(row, parameters[replacement], bindings)
            pairs.append(("threshold_role", row.binding_id, identifier, replacement, base,
                          rebind(*base, row, replacement, parameters[replacement])))

        if current["parameter_kind"] not in ("threshold", "numeric_tolerance"):
            continue
        for replacement, candidate in parameters.items():
            if (candidate["parameter_kind"], candidate["unit"], candidate.get("policy")) != (
                    current["parameter_kind"], current["unit"], current.get("policy")):
                continue
            if candidate["signal_scope"] == current["signal_scope"]:
                continue
            if not numerical_order_preserved(row, candidate, bindings):
                excluded.append({"binding_id": row.binding_id, "alternative": replacement,
                                 "reason": "response_threshold_order"})
                continue
            pairs.append(("signal_scope", row.binding_id, identifier, replacement, base,
                          rebind(*base, row, replacement, candidate)))

    for field in context_fields:
        affected = "parameter:speed_3d_p99_train"
        equal_nodes = nodes.copy()
        for participant in ("formula:N06", "signal:speed_3d_mps", affected):
            change_node(equal_nodes, participant, **{field: "TEST_ONLY_A"})
        conflict_nodes = equal_nodes.copy()
        change_node(conflict_nodes, affected, **{field: "TEST_ONLY_B"})
        pairs.append(("execution_context", "N06:trigger_upper." + field, "TEST_ONLY_A", "TEST_ONLY_B",
                      (equal_nodes, edges, bindings), (conflict_nodes, edges, bindings)))

    used = sorted(set(bindings["parameter_id"]))
    for identifier in used:
        parameter_id = "parameter:" + identifier
        good = parameters[parameter_id]["source_reference"]
        wrong = next(ref for ref in sorted(set(ref_by_type.values())) if ref != good)
        corrupt_nodes = nodes.copy()
        change_node(corrupt_nodes, parameter_id, source_reference=wrong)
        corrupt_bindings = bindings.copy()
        corrupt_bindings.loc[corrupt_bindings["parameter_id"].eq(identifier), "source_reference"] = wrong
        pairs.append(("source_pointer", parameter_id, good, wrong, base,
                      (corrupt_nodes, edges, corrupt_bindings)))
    return pairs, excluded


def write_case_results(result_rows, out):
    pd.DataFrame(result_rows).to_csv(out / "matched_pairs.csv", index=False, lineterminator="\n")
    summaries = []
    for check in CHECKS:
        for mode in MODES:
            rows = [row for row in result_rows if row["check"] == check and row["mode"] == mode]
            summary = {
                "check": check, "mode": mode, "pairs": len(rows),
                "graph_positive_rejected": sum(not r["positive_graph"] for r in rows),
                "graph_negative_accepted": sum(r["negative_graph"] for r in rows),
                "graph_pairs_both_accepted": sum(r["positive_graph"] and r["negative_graph"] for r in rows),
                "combined_positive_rejected": sum(not r["positive_combined"] for r in rows),
                "combined_negative_accepted": sum(r["negative_combined"] for r in rows),
                "combined_pairs_both_accepted": sum(
                    r["positive_combined"] and r["negative_combined"] for r in rows
                ),
            }
            summaries.append(summary)
    pd.DataFrame(summaries).to_csv(out / "summary.csv", index=False, lineterminator="\n")
    return summaries


def run(snapshot, source_audit_directory, out):
    out.mkdir(parents=True, exist_ok=True)
    neo4j = snapshot / "neo4j"
    frozen, extension, graph_checkers = load_graph_checkers(neo4j)
    audit_path = source_audit_directory / "source_binding_verifier.py"
    source = load_module("source_binding_verifier", audit_path)

    graph_paths = tuple(neo4j / "data" / name for name in (
        "frozen_graph_nodes.csv", "frozen_graph_relationships.csv", "frozen_formula_parameter_bindings.csv",
    ))
    nodes = pd.read_csv(graph_paths[0], encoding="utf-8-sig", dtype=str, keep_default_na=False)
    edges = pd.read_csv(graph_paths[1], encoding="utf-8-sig", dtype=str, keep_default_na=False)
    bindings = pd.read_csv(graph_paths[2], encoding="utf-8-sig")
    frozen.validate_flat_binding_export(nodes, edges, bindings)
    known = extension.validate_extended(nodes, edges)
    assert known["accepted"] and known["execution_context_fully_known_equal_checks"] == 0
    assert source.run(graph_paths[2])["status"] == "passed"
    meta = frozen.properties(nodes)
    ref_by_type = {
        "derived_statistical_reference": source.THRESHOLD_REF,
        "prototype_runtime_configuration": source.RUNTIME_REF,
        "semantic_default": source.SEMANTIC_REF,
    }
    assert bindings["source_type"].map(ref_by_type).equals(bindings["source_reference"])
    pairs, excluded = build_pairs((nodes, edges, bindings), meta, extension.EXECUTION_CONTEXT_FIELDS, ref_by_type)
    inventory = pd.DataFrame([
        {"check": check, "site": site, "original": original, "alternative": alternative}
        for check, site, original, alternative, _, _ in pairs
    ])
    inventory.to_csv(out / "fixture_inventory.csv", index=False, lineterminator="\n")
    pd.DataFrame(excluded).to_csv(out / "excluded_alternatives.csv", index=False, lineterminator="\n")
    print("Fixture counts", inventory.groupby("check").size().to_dict(), "Excluded", len(excluded), flush=True)

    graph_cache, source_cache = {}, {}
    results = []
    with tempfile.TemporaryDirectory(prefix="paired-stkg-") as tmp:
        source_input = Path(tmp) / "bindings.csv"

        def evaluate(fixture, mode):
            n, e, b = fixture
            graph_mode = "full" if mode == "source_pointer" else mode
            graph_key = (id(n), id(e), graph_mode)
            if graph_key not in graph_cache:
                graph_cache[graph_key] = graph_checkers[graph_mode](n, e)
            graph_result = graph_cache[graph_key]

            if mode == "source_pointer":
                # Omit only the pointer comparison. The auditor still checks every
                # other field with the original source catalogs and declared rules.
                b = b.assign(source_reference=b["source_type"].map(ref_by_type))
            payload = b.to_csv(index=False, lineterminator="\n")
            if payload not in source_cache:
                source_input.write_text(payload, encoding="utf-8", newline="")
                source_cache[payload] = source.run(source_input)
            source_result = source_cache[payload]
            graph_pass = graph_result["accepted"]
            source_pass = source_result["status"] == "passed"
            return {
                "graph": graph_pass, "source": source_pass, "combined": graph_pass and source_pass,
                "graph_reasons": json.dumps(graph_result["errors"], ensure_ascii=False, separators=(",", ":")),
                "source_reasons": json.dumps(source_result["errors"], ensure_ascii=False, separators=(",", ":")),
            }

        for check, site, original, alternative, positive, negative in pairs:
            for mode in MODES:
                results.append({
                    "check": check, "site": site, "mode": mode, "original": original, "alternative": alternative,
                    **{f"positive_{k}": v for k, v in evaluate(positive, mode).items()},
                    **{f"negative_{k}": v for k, v in evaluate(negative, mode).items()},
                })

    summary = write_case_results(results, out)
    for row in summary:
        assert row["combined_positive_rejected"] == 0, row
        graph_expectation = row["pairs"] if row["mode"] == row["check"] or row["check"] == "source_pointer" else 0
        assert row["graph_negative_accepted"] == graph_expectation, row
        combined_expectation = (
            row["pairs"] if row["mode"] == row["check"] and row["check"] != "signal_scope" else 0
        )
        assert row["combined_negative_accepted"] == combined_expectation, row

    history_path = snapshot / "ablation" / "v4_graph_mutation_ablation_details.csv"
    historical = pd.read_csv(history_path, encoding="utf-8-sig")
    full_history = historical.loc[historical["validator_variant"].eq("full_validator")]
    assert len(full_history) == 354 and int(full_history["mutant_accepted"].sum()) == 0
    input_paths = [
        *graph_paths, neo4j / "frozen_validator_reference.py", neo4j / "validation_extension.py",
        history_path, audit_path, source.THRESHOLDS, source.RUNTIME, source.SIGNALS, source.GENERATOR,
        source.ROOT / source.SEMANTIC_REF, source.ROOT / "specification/run_all.py",
        Path(__file__).resolve(), Path(__file__).resolve().with_name("protocol.md"),
    ]
    input_hashes = {}
    for path in input_paths:
        for prefix, directory in (("snapshot", snapshot), ("source_audit", source_audit_directory), ("study", HERE)):
            if path.is_relative_to(directory):
                label = prefix + "/" + path.relative_to(directory).as_posix()
                input_hashes[label] = sha(path)
                break
        else:
            raise ValueError(f"input lies outside the declared study directories: {path}")
    evidence = {
        "status": "passed",
        "design": "post-inspection matched probes using the same frozen catalog",
        "pandas_version": pd.__version__,
        "fixture_pairs": len(pairs),
        "logical_case_settings": len(results) * 2,
        "unique_graph_inputs_executed": len(graph_cache),
        "unique_source_audit_inputs_executed": len(source_cache),
        "baseline_graph_nodes": len(nodes), "baseline_graph_edges": len(edges),
        "baseline_bindings": len(bindings), "baseline_fully_known_context_checks": 0,
        "baseline_unknown_or_not_applicable_context_checks": known["execution_context_unknown_or_not_applicable_checks"],
        "excluded_signal_alternatives": len(excluded),
        "historical_reference": {"replayed": False, "mutants": len(full_history), "accepted": 0},
        "files_sha256": input_hashes,
        "output_sha256": {
            name: sha(out / name) for name in (
                "matched_pairs.csv", "summary.csv", "fixture_inventory.csv", "excluded_alternatives.csv"
            )
        },
        "summaries": summary,
    }
    (out / "receipt.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Results", [r for r in summary if r["check"] == r["mode"]], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, default=SNAPSHOT)
    parser.add_argument("--source-audit", type=Path, default=SOURCE_AUDIT)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    run(args.snapshot.resolve(), args.source_audit.resolve(), args.output.resolve())

