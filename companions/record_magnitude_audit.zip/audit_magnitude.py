"""Measure every retained source cell and every above-bound adjacency group."""
from pathlib import Path
from hashlib import sha256
import argparse
import csv
import itertools
import json
import math


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def write_rows(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ['protocol', 'input', 'output']:
        parser.add_argument('--' + key, required=True, type=Path)
    args = parser.parse_args()
    protocol = json.loads(args.protocol.read_text(encoding='utf-8'))
    assert protocol['protocol_id'] == 'v61-record-magnitude-20261105'
    assert not args.output.exists()
    for name, h in protocol['input_sha256'].items():
        # The frozen provenance snapshot is supplied beside the protocol. A
        # newly generated manifest has machine-specific paths and is distinct.
        source = args.protocol.parent / name if name == 'source_manifest.json' else args.input / name
        assert sha256(source.read_bytes()).hexdigest() == h, name
    records = read(args.input / 'capture_records.csv')
    scalar_rows = read(args.input / 'values_for_verification.csv')
    parameters = {(r['case_id'], r['signal']): r for r in read(args.input / 'predicate_parameters.csv')}
    old_groups = {(r['case_id'], r['signal'], int(r['group_id'])): r for r in read(args.input / 'group_details.csv')}
    old_cells = {(r['case_id'], r['signal']): r for r in read(args.input / 'capture_summary.csv')}
    assert len(records) == len(scalar_rows) == 196320
    for r, v in zip(records, scalar_rows):
        assert all(r[k] == v[k] for k in ['case_id', 'signal', 'record_index'])
        r['value'] = float(v['value'])
        assert math.isfinite(r['value'])
        for key in ['record_index', 'source_csv_line', 'timestamp_us', 'selected', 'above_bound', 'group_id']:
            r[key] = int(r[key])
    cells, groups = [], []
    for key, iterator in itertools.groupby(records, lambda r: (r['case_id'], r['signal'])):
        rs = list(iterator)
        p = parameters[key]
        bound, eps = float(p['upper_bound']), float(p['value_epsilon'])
        threshold = bound + eps
        assert bound > 0 and eps == 0
        assert [r['record_index'] for r in rs] == list(range(len(rs)))
        selected = [r for r in rs if r['selected']]
        maximum = max(r['value'] for r in rs)
        selected_maximum = max(r['value'] for r in selected)
        peak = next(r for r in rs if r['value'] == maximum)
        selected_peak = next(r for r in selected if r['value'] == selected_maximum)
        old = old_cells[key]
        assert len(rs) == int(old['native_records']) and len(selected) == int(old['selected_records'])
        assert sum(r['value'] > threshold for r in rs) == int(old['native_above_bound'])
        cells.append(dict(case_id=key[0], signal=key[1], unit=protocol['units'][key[1]],
                          bound=bound, native_records=len(rs), selected_records=len(selected),
                          native_peak=maximum, selected_peak=selected_maximum,
                          native_peak_to_bound=maximum/bound, selected_peak_to_bound=selected_maximum/bound,
                          native_above_bound=int(old['native_above_bound']),
                          selected_above_bound=int(old['selected_above_bound']),
                          native_peak_first_csv_line=peak['source_csv_line'],
                          native_peak_first_timestamp_us=peak['timestamp_us'],
                          selected_peak_first_csv_line=selected_peak['source_csv_line'],
                          selected_peak_first_timestamp_us=selected_peak['timestamp_us']))
        gid, previous_above = 0, False
        observed_groups = {}
        for r in rs:
            above = r['value'] > threshold
            if above and not previous_above:
                gid += 1
            assert int(above) == r['above_bound']
            assert (gid if above else 0) == r['group_id']
            if above:
                observed_groups.setdefault(gid, []).append(r)
            previous_above = above
        for group_id, gr in observed_groups.items():
            old = old_groups[(*key, group_id)]
            peak_value = max(r['value'] for r in gr)
            peaks = [r for r in gr if r['value'] == peak_value]
            picked = [r for r in gr if r['selected']]
            assert len(gr) == int(old['above_bound_records']) and len(picked) == int(old['selected_above_bound_records'])
            assert gr[0]['timestamp_us'] == int(old['first_timestamp_us'])
            assert gr[-1]['timestamp_us'] == int(old['last_timestamp_us'])
            groups.append(dict(case_id=key[0], signal=key[1], group_id=group_id, unit=protocol['units'][key[1]],
                               bound=bound, above_bound_records=len(gr), selected_above_bound_records=len(picked),
                               first_timestamp_us=gr[0]['timestamp_us'], last_timestamp_us=gr[-1]['timestamp_us'],
                               observed_span_us=gr[-1]['timestamp_us']-gr[0]['timestamp_us'],
                               peak=peak_value, peak_excess=peak_value-threshold, peak_to_bound=peak_value/bound,
                               peak_record_count=len(peaks), selected_peak_records=sum(r['selected'] for r in peaks),
                               first_peak_csv_line=peaks[0]['source_csv_line'], first_peak_timestamp_us=peaks[0]['timestamp_us']))
    assert len(cells) == 15 and len(groups) == 11
    assert {(r['case_id'], r['signal']) for r in cells} == set(itertools.product(protocol['cases'], protocol['signals']))
    assert set(old_groups) == {(r['case_id'], r['signal'], r['group_id']) for r in groups}
    args.output.mkdir(parents=True)
    write_rows(args.output / 'cell_magnitudes.csv', cells)
    write_rows(args.output / 'group_magnitudes.csv', groups)
    receipt = dict(status='passed', cells=15, groups=11, record_signal_rows=196320,
                   pinned_input_sha256=protocol['input_sha256'], protocol_sha256=sha256(args.protocol.read_bytes()).hexdigest(),
                   source_authentication_this_run='sealed_v59_derived_values_only_not_fresh_raw_authentication',
                   all_old_counts_groups_coordinates_preserved=True, thresholds_unchanged=True,
                   new_monitor_verdicts=0, new_human_labels=0, new_flights=0,
                   results_sha256={n:sha256((args.output/n).read_bytes()).hexdigest()
                                   for n in ['cell_magnitudes.csv','group_magnitudes.csv']})
    (args.output / 'magnitude_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    for r in groups:
        print(json.dumps(r, ensure_ascii=False))


if __name__ == '__main__':
    main()
