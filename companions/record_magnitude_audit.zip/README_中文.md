# v61记录幅度及观察跨度核查

只使用Python标准库。先按原名v59_source_capture_audit.zip说明，从外部原日志重建5份科学CSV：capture_records.csv、values_for_verification.csv、predicate_parameters.csv、capture_summary.csv、group_details.csv。必须与本包协议中的SHA逐字节一致。原始及派生逐点数值未装入本包，只有聚合结果。

source_manifest.json是随包冻结的v59来源声明快照，校验它保存在本包中的原字节；新重建manifest的本机路径会不同，应另行保存。两个程序从协议同目录读冻结快照，从--input目录读5份科学CSV，不拿新manifest的路径差异冒充数值差异。该快照与相同派生CSV不构成本轮重新认证原始传感器文件。完整原始认证需执行v59原始来源核查流程。

在新输出目录运行：
python audit_magnitude.py --protocol magnitude_protocol.json --input <已重建的v59目录> --output recalculated
python verify_magnitude_sqlite.py --protocol magnitude_protocol.json --input <已重建的v59目录> --results recalculated

固定全部15格、11组；首末记录跨度不是物理越界持续时间；研究阈值不是已标定安全界限。无新监测判决、标签或飞行。旧结果不改。
