"""Independently regroup the pinned scalar records and verify every magnitude."""
from pathlib import Path
from hashlib import sha256
import argparse
import csv
import json
import sqlite3


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['protocol', 'input', 'results']:
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    protocol = json.loads(args.protocol.read_text(encoding='utf-8'))
    for name, expected in protocol['input_sha256'].items():
        source = args.protocol.parent / name if name == 'source_manifest.json' else args.input / name
        assert sha256(source.read_bytes()).hexdigest() == expected, name
    records = read(args.input / 'capture_records.csv')
    values = read(args.input / 'values_for_verification.csv')
    db = sqlite3.connect(':memory:')
    db.executescript('''CREATE TABLE r(case_id TEXT, signal TEXT, idx INTEGER, csv_line INTEGER,
                      t INTEGER, selected INTEGER, value REAL, PRIMARY KEY(case_id,signal,idx));
                      CREATE TABLE p(case_id TEXT, signal TEXT, bound REAL, eps REAL, PRIMARY KEY(case_id,signal));''')
    inputs = []
    assert len(records) == len(values) == 196320
    for r, v in zip(records, values):
        assert all(r[k] == v[k] for k in ['case_id', 'signal', 'record_index'])
        inputs.append((r['case_id'], r['signal'], int(r['record_index']), int(r['source_csv_line']),
                       int(r['timestamp_us']), int(r['selected']), float(v['value'])))
    db.executemany('INSERT INTO r VALUES(?,?,?,?,?,?,?)', inputs)
    db.executemany('INSERT INTO p VALUES(?,?,?,?)', [
        (r['case_id'], r['signal'], float(r['upper_bound']), float(r['value_epsilon']))
        for r in read(args.input / 'predicate_parameters.csv')])
    db.executescript('''CREATE TABLE z AS
        WITH flags AS (SELECT r.*, p.bound, p.eps, value>bound+eps AS above,
            LAG(value>bound+eps,1,0) OVER(PARTITION BY r.case_id,r.signal ORDER BY idx) AS prev
            FROM r JOIN p USING(case_id,signal)),
        starts AS (SELECT *, CASE WHEN above AND NOT prev THEN 1 ELSE 0 END AS begins FROM flags)
        SELECT *, CASE WHEN above THEN SUM(begins) OVER(PARTITION BY case_id,signal ORDER BY idx) ELSE 0 END AS gid
        FROM starts;
        CREATE INDEX z_group ON z(case_id,signal,gid);
        CREATE TABLE g AS SELECT case_id,signal,gid,MAX(value) AS peak,COUNT(*) AS n,
            SUM(selected) AS chosen,MIN(t) AS first_t,MAX(t) AS last_t,MAX(bound) AS bound
            FROM z WHERE above GROUP BY case_id,signal,gid;''')
    cell_count = 0
    for row in read(args.results / 'cell_magnitudes.csv'):
        key = (row['case_id'], row['signal'])
        got = db.execute('''SELECT COUNT(*),SUM(selected),MAX(value),MAX(CASE WHEN selected THEN value END),
            SUM(above),SUM(above*selected),MAX(bound) FROM z WHERE case_id=? AND signal=?''', key).fetchone()
        n, chosen, peak, selected_peak, above, selected_above, bound = got
        expected = dict(native_records=n, selected_records=chosen, native_peak=peak, selected_peak=selected_peak,
                        native_peak_to_bound=peak/bound, selected_peak_to_bound=selected_peak/bound,
                        native_above_bound=above, selected_above_bound=selected_above, bound=bound)
        first_peak = db.execute('''SELECT csv_line,t FROM z WHERE case_id=? AND signal=? AND value=? ORDER BY idx LIMIT 1''', (*key,peak)).fetchone()
        first_selected = db.execute('''SELECT csv_line,t FROM z WHERE case_id=? AND signal=? AND selected=1 AND value=? ORDER BY idx LIMIT 1''', (*key,selected_peak)).fetchone()
        expected.update(native_peak_first_csv_line=first_peak[0], native_peak_first_timestamp_us=first_peak[1],
                        selected_peak_first_csv_line=first_selected[0], selected_peak_first_timestamp_us=first_selected[1])
        for field, value in expected.items():
            assert float(row[field]) == value, (key, field, row[field], value)
        assert row['unit'] == protocol['units'][key[1]]
        cell_count += 1
    group_count = 0
    for row in read(args.results / 'group_magnitudes.csv'):
        key = (row['case_id'], row['signal'], int(row['group_id']))
        peak, n, chosen, first_t, last_t, bound = db.execute(
            'SELECT peak,n,chosen,first_t,last_t,bound FROM g WHERE case_id=? AND signal=? AND gid=?', key).fetchone()
        peaks, selected_peaks = db.execute('''SELECT COUNT(*),SUM(selected) FROM z
            WHERE case_id=? AND signal=? AND gid=? AND value=?''', (*key,peak)).fetchone()
        first_peak = db.execute('''SELECT csv_line,t FROM z WHERE case_id=? AND signal=? AND gid=? AND value=? ORDER BY idx LIMIT 1''', (*key,peak)).fetchone()
        expected = dict(bound=bound, above_bound_records=n, selected_above_bound_records=chosen,
                        first_timestamp_us=first_t, last_timestamp_us=last_t, observed_span_us=last_t-first_t,
                        peak=peak, peak_excess=peak-bound, peak_to_bound=peak/bound,
                        peak_record_count=peaks, selected_peak_records=selected_peaks,
                        first_peak_csv_line=first_peak[0], first_peak_timestamp_us=first_peak[1])
        for field, value in expected.items():
            assert float(row[field]) == value, (key, field, row[field], value)
        assert row['unit'] == protocol['units'][key[1]]
        group_count += 1
    assert cell_count == db.execute('SELECT COUNT(*) FROM p').fetchone()[0] == 15
    assert group_count == db.execute('SELECT COUNT(*) FROM g').fetchone()[0] == 11
    # The independent regrouping must also agree with all archived v59 flags/IDs.
    got = db.execute('SELECT case_id,signal,idx,above,gid FROM z ORDER BY case_id,signal,idx').fetchall()
    archived = sorted((r['case_id'],r['signal'],int(r['record_index']),int(r['above_bound']),int(r['group_id'])) for r in records)
    assert got == archived
    receipt = dict(status='passed', independent_engine='SQLite window grouping and aggregates',
                   record_signal_rows=196320, cells=15, groups=11,
                   all_peak_values_ratios_counts_spans_and_coordinates_exact=True,
                   authentication='pinned_v59_scalar_reconstruction_not_fresh_raw_or_sensor_authentication',
                   original_v59_predicate_and_group_ids_exact=True,
                   output_sha256={name:sha256((args.results/name).read_bytes()).hexdigest()
                                  for name in ['cell_magnitudes.csv','group_magnitudes.csv']})
    target = args.results / 'independent_magnitude_verification.json'
    assert not target.exists()
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
