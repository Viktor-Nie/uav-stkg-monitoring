# 网格选择覆盖核查附件

完整核查原3案例×5信号的15格、196320条记录—信号行及11个连续越界观察组；这不是新增独立飞行或物理故障标签。两种集合使用同一原始支持区间：首个网格点选中的前驱源行到末个网格点选中的前驱源行，含中间每行。它与v58按网格首末时刻截取的原消息窗口不同。

包内包括程序、协议、冻结参数、6份原网格指纹、完整11139来源映射、81行旧配置对照、全记录坐标/选择标志/越界布尔值、15格汇总和11组精确位置。不含原始状态值或现场核验需要的values_for_verification.csv；完整重算须提供指纹所列materials原始文件，包括Real-Motor.zip。先生成fresh_results，再运行SQL复核，不能对缺少重建数值的归档results直接认证源数据。

```powershell
python -B audit_capture.py --protocol capture_protocol.json --fingerprints frozen_replay_fingerprints.json --source-helper audit_sources.py --value-helper run_native_sensitivity.py --configurations configurations.json --mappings point_source_coordinates.csv --grid-controls configuration_results.csv --raw-root C:/实际路径/materials --output fresh_results
python -B verify_capture_sqlite.py --results fresh_results --mappings point_source_coordinates.csv --grid-controls configuration_results.csv
```

Python需要已有numpy/pandas/scipy；SQLite核验使用标准库。程序不会下载、训练或调用模型，不改原监测策略、预算或科研结果。7份文件（含未打包的现场数值CSV）应能逐字节复现；source_manifest的本机路径差异另列，不冒称整个manifest字节一致。

“连续组”只按相邻原始记录中越界布尔值分组，并不推断观测间物理连续性，也不等于真实故障次数。选择覆盖不是检测召回率，0越界的格不解释成100%捕获。原两次分析保留在capture_run001/002；第二次只增加全部组的精确位置输出，方案和已有汇总不变。
