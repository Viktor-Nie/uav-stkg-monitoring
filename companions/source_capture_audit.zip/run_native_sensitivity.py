"""Run a fixed exploratory grid/native comparison without changing old results."""
from __future__ import annotations
import argparse
from dataclasses import asdict
from decimal import Decimal
from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


SIGNAL_TOPIC = {'speed_3d_mps': 'local_position', 'height_m': 'local_position',
                'abs_roll_rad': 'vehicle_attitude', 'abs_pitch_rad': 'vehicle_attitude',
                'ang_rate_norm_rps': 'vehicle_angular_velocity'}


def native_values(case, topic, frame):
    """Use each topic independently, retaining the historical conversion boundary."""
    if topic == 'local_position':
        online = frame[['z', 'vx', 'vy', 'vz']].rename(columns={
            'z': 'pos_d', 'vx': 'vel_n', 'vy': 'vel_e', 'vz': 'vel_d'}).reset_index(drop=True)
    elif topic == 'vehicle_attitude':
        q = frame[['q[1]', 'q[2]', 'q[3]', 'q[0]']].to_numpy(float)
        if case == '407_1':
            x, y, z, w = q.T
            roll = np.arctan2(2*(w*x+y*z), 1-2*(x*x+y*y))
            pitch = np.arcsin(np.clip(2*(w*y-z*x), -1, 1))
            online = pd.DataFrame({'roll': roll, 'pitch': pitch})
        else:
            angles = Rotation.from_quat(q).as_euler('xyz', degrees=False)
            online = pd.DataFrame(angles[:, :2], columns=['roll', 'pitch'])
    else:
        online = frame[['xyz[0]', 'xyz[1]', 'xyz[2]']].reset_index(drop=True)
    # Both historical grid and new native routes cross the same float CSV boundary.
    online = pd.read_csv(io.BytesIO(online.to_csv(index=False, lineterminator='\r\n').encode('utf-8-sig')))
    result = pd.DataFrame({'timestamp_us': frame.timestamp.to_numpy(np.int64),
                           'source_csv_line': frame['_source_csv_line'].to_numpy(np.int64)})
    if topic == 'local_position':
        result['speed_3d_mps'] = (online.vel_n**2 + online.vel_e**2 + online.vel_d**2)**.5
        result['height_m'] = online.pos_d.abs()
    elif topic == 'vehicle_attitude':
        result['abs_roll_rad'] = online.roll.abs()
        result['abs_pitch_rad'] = online.pitch.abs()
    else:
        result['ang_rate_norm_rps'] = (online['xyz[0]']**2 + online['xyz[1]']**2 + online['xyz[2]']**2)**.5
    assert np.isfinite(result.to_numpy()).all()
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['protocol', 'fingerprints', 'source_helper', 'monitor_dir', 'raw_root', 'output']:
        p.add_argument('--' + name.replace('_', '-'), type=Path, required=True)
    args = p.parse_args()
    assert not args.output.exists(), 'Frozen outputs are never overwritten'
    protocol = load(args.protocol)
    assert protocol['protocol_id'] == 'v58-native-time-sensitivity-20261105'
    helper = module('native_source_helper', args.source_helper)
    sys.path.insert(0, str(args.monitor_dir.resolve()))
    import sampled_monitor as monitor
    import monitor_from_traceability_graph as graph
    from sampled_data_contract import SamplingContract, EventTimeObservationContract
    fingerprints = load(args.fingerprints)
    configurations = {}
    for identifier in sorted(graph.node_properties()):
        if not identifier.startswith('formula:'):
            continue
        spec = graph.instantiate_formula(identifier)
        template = 'invariant_upper' if isinstance(spec, monitor.InvariantSpecification) else 'bounded_response'
        signature = json.dumps({'template': template, **asdict(spec)}, sort_keys=True)
        if signature not in configurations:
            configurations[signature] = {'formula_id': identifier.removeprefix('formula:'),
                                         'template': template, 'specification': asdict(spec), 'aliases': []}
        configurations[signature]['aliases'].append(identifier.removeprefix('formula:'))
    configs = list(configurations.values())
    assert len(configs) == 9 and sum(len(c['aliases']) for c in configs) == 24
    args.output.mkdir(parents=True)
    traces = args.output / 'traces'
    traces.mkdir()
    input_receipts, native_members, reconstructions, support_rows = {}, [], [], []
    all_rows, signatures, trace_manifest = [], [], []
    for case in protocol['cases']:
        source = fingerprints['raw_sources'][case]
        frames, members, start, end = helper.source_frames(case, args.raw_root, source, input_receipts)
        native_members.extend(members)
        grid = np.arange(start, end+1, 50000, dtype=np.int64)
        online, observed, _ = helper.rebuild_observations(case, frames, grid)
        for suffix, value in [('online_input', online), ('observable_trace', observed)]:
            expected = next(r for r in fingerprints['derived_outputs']
                            if r['file'] == f'multi_real_motor_replay/{case}_{suffix}.csv')
            actual = sha256(helper.csv_bytes(value)).hexdigest()
            assert actual == expected['sha256'], (case, suffix)
            reconstructions.append({'case_id': case, 'kind': suffix, 'sha256': actual})
        grid_trace = observed.drop(columns='time_seconds').copy()
        grid_trace.insert(0, 'timestamp_us', grid)
        inputs = {'grid': grid_trace}
        for topic, frame in frames.items():
            clipped = frame[(frame.timestamp >= int(grid[0])) & (frame.timestamp <= int(grid[-1]))].copy()
            assert len(clipped) >= 2
            value = native_values(case, topic, clipped)
            inputs[topic] = value
            gaps = np.diff(value.timestamp_us.to_numpy(np.int64))
            support_rows.append({'case_id': case, 'topic': topic, 'samples': len(value),
                                 'first_timestamp_us': int(value.timestamp_us.iloc[0]),
                                 'last_timestamp_us': int(value.timestamp_us.iloc[-1]),
                                 'window_start_us': int(grid[0]), 'window_end_us': int(grid[-1]),
                                 'maximum_gap_us': int(max(gaps)),
                                 'gaps_gt_100ms': int(np.sum(gaps > 100000)),
                                 'gaps_gt_1s': int(np.sum(gaps > 1000000))})
        # Round-trip diagnostic CSVs once, so both independent implementations consume identical values.
        for route, value in inputs.items():
            target = traces / f'{case}_{route}.csv'
            value.to_csv(target, index=False, encoding='utf-8-sig')
            inputs[route] = pd.read_csv(target, encoding='utf-8-sig')
            trace_manifest.append({'case_id': case, 'route': route,
                                   'file': target.relative_to(args.output).as_posix(), 'sha256': digest(target)})
        for profile, description in protocol['profiles'].items():
            for c in configs:
                data = inputs['grid' if profile == 'grid_frozen' else SIGNAL_TOPIC[c['specification']['signal']]]
                trace = data.drop(columns=['source_csv_line'], errors='ignore').copy()
                trace['time_seconds'] = trace.pop('timestamp_us').astype(str)
                spec = graph.instantiate_formula(c['formula_id'])
                settings = {k: v for k, v in description.items() if k != 'kind'}
                settings.update(timestamp_epsilon_seconds=1e-9, minimum_sample_count=2)
                contract = SamplingContract(**settings) if profile == 'grid_frozen' else EventTimeObservationContract(**settings)
                fn = monitor.monitor_invariant if c['template'] == 'invariant_upper' else monitor.monitor_bounded_response
                result = fn(trace, spec, contract, timestamp_scale_seconds='0.000001')
                row = {'case_id': case, 'profile': profile, 'formula_id': c['formula_id'],
                       'template': c['template'], 'signal': spec.signal, 'samples': len(trace),
                       'first_timestamp_us': int(data.timestamp_us.iloc[0]),
                       'last_timestamp_us': int(data.timestamp_us.iloc[-1]),
                       'verdict': result.verdict.value, 'violations': len(result.violating_sample_indices),
                       'triggered': len(result.created_obligations), 'recovered': len(result.recovered_obligation_ids),
                       'expired': len(result.expired_obligation_ids), 'pending': len(result.pending_obligation_ids),
                       'input_reasons': ';'.join(result.sampling_audit.reasons)}
                all_rows.append(row)
                signatures.append({'case_id': case, 'profile': profile, 'formula_id': c['formula_id'],
                                   'violating_indices': result.violating_sample_indices,
                                   'trigger_indices': [v.trigger_index for v in result.created_obligations],
                                   'recovered_ids': result.recovered_obligation_ids,
                                   'expired_ids': result.expired_obligation_ids,
                                   'pending_ids': result.pending_obligation_ids})
    results = pd.DataFrame(all_rows)
    assert len(results) == 81 and not results[['case_id', 'profile', 'formula_id']].duplicated().any()
    summaries = []
    for (case, profile), group in results.groupby(['case_id', 'profile'], sort=True):
        summaries.append({'case_id': case, 'profile': profile, 'configurations': len(group),
                          **{name: int((group.verdict == verdict).sum()) for name, verdict in {
                              'satisfied': 'satisfied', 'violated': 'violated',
                              'inconclusive': 'inconclusive_end_of_trace', 'rejected': 'rejected_input_contract'}.items()},
                          **{k: int(group[k].sum()) for k in ['violations', 'triggered', 'recovered', 'expired', 'pending']}})
    summary = pd.DataFrame(summaries)
    expected = {'406_1': (8, 1, 3, 3, 0), '406_2': (7, 2, 14, 14, 0), '407_1': (6, 3, 271, 75, 196)}
    for case, values in expected.items():
        row = summary[(summary.case_id == case) & (summary.profile == 'grid_frozen')].iloc[0]
        assert tuple(int(row[k]) for k in ['satisfied', 'violated', 'triggered', 'recovered', 'expired']) == values
    results.to_csv(args.output / 'configuration_results.csv', index=False, encoding='utf-8-sig')
    summary.to_csv(args.output / 'case_profile_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(support_rows).to_csv(args.output / 'native_support.csv', index=False, encoding='utf-8-sig')
    write(args.output / 'configurations.json', configs)
    write(args.output / 'obligation_signatures.json', signatures)
    write(args.output / 'input_manifest.json', {'protocol_sha256': digest(args.protocol),
          'fingerprints_sha256': digest(args.fingerprints), 'whole_inputs': list(input_receipts.values()),
          'native_members': native_members, 'reconstructed_frozen_files': reconstructions,
          'diagnostic_traces': trace_manifest,
          'monitor_files': {p.name: digest(p) for p in args.monitor_dir.glob('*.py')},
          'graph_files': {p.name: digest(p) for p in (args.monitor_dir / 'data/traceability_graph').glob('*.csv')}})
    write(args.output / 'run_receipt.json', {'status': 'passed', 'attempts': 81, 'cases': 3,
          'unique_configurations': 9, 'native_streams': 9, 'baseline_frozen_files_exact': 6,
          'baseline_summaries_exact': True, 'new_flights': 0, 'new_human_labels': 0,
          'new_model_calls': 0, 'original_results_unchanged': True,
          'exploratory_gap_is_not_calibrated': True})
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
