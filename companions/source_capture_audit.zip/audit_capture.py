"""Account for all source-record selections and above-bound observation groups."""
from __future__ import annotations
import argparse
import csv
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['protocol', 'fingerprints', 'source_helper', 'value_helper', 'configurations',
                 'mappings', 'grid_controls', 'raw_root', 'output']:
        parser.add_argument('--' + name.replace('_', '-'), required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), 'Never overwrite a frozen result'
    protocol = load(args.protocol)
    assert protocol['protocol_id'] == 'v59-source-record-capture-20261105'
    source_helper = module('v59_source_helper', args.source_helper)
    value_helper = module('v59_value_helper', args.value_helper)
    fingerprints = load(args.fingerprints)
    configs = {r['specification']['signal']: r for r in load(args.configurations)
               if r['template'] == 'invariant_upper'}
    assert set(configs) == set(protocol['signals']) and len(configs) == 5
    mappings = pd.read_csv(args.mappings, encoding='utf-8-sig')
    controls = pd.read_csv(args.grid_controls, encoding='utf-8-sig')
    controls = controls[(controls.profile == 'grid_frozen') & (controls.template == 'invariant_upper')]
    assert len(mappings) == 11139 and len(controls) == 15
    args.output.mkdir(parents=True)
    records_path = args.output / 'capture_records.csv'
    values_path = args.output / 'values_for_verification.csv'
    summary, reconstructions, inputs, native_members, group_details = [], [], {}, [], []
    count = 0
    with records_path.open('w', encoding='utf-8', newline='') as rf, values_path.open('w', encoding='utf-8', newline='') as vf:
        record_fields = ['case_id', 'signal', 'topic', 'record_index', 'source_csv_line', 'timestamp_us',
                         'selected', 'above_bound', 'group_id']
        rw = csv.DictWriter(rf, fieldnames=record_fields); rw.writeheader()
        vw = csv.writer(vf); vw.writerow(['case_id', 'signal', 'record_index', 'value'])
        for case in protocol['cases']:
            frames, members, start, end = source_helper.source_frames(case, args.raw_root, fingerprints['raw_sources'][case], inputs)
            native_members.extend(members)
            grid = np.arange(start, end+1, 50000, dtype=np.int64)
            online, observed, used = source_helper.rebuild_observations(case, frames, grid)
            for kind, data in [('online_input', online), ('observable_trace', observed)]:
                expected = next(r for r in fingerprints['derived_outputs']
                                if r['file'] == f'multi_real_motor_replay/{case}_{kind}.csv')
                actual = sha256(source_helper.csv_bytes(data)).hexdigest()
                assert actual == expected['sha256']
                reconstructions.append({'case_id': case, 'kind': kind, 'sha256': actual})
            for signal in protocol['signals']:
                topic = protocol['topic_for_signal'][signal]
                frame = frames[topic]
                indices = used[topic]
                support = frame.iloc[int(indices[0]):int(indices[-1])+1].copy()
                values = value_helper.native_values(case, topic, support)
                assert len(values) == int(indices[-1])-int(indices[0])+1
                lines = frame['_source_csv_line'].to_numpy(np.int64)[indices]
                mapped = mappings[(mappings.case_id == case) & (mappings.topic == topic)].sort_values('grid_index')
                assert np.array_equal(mapped.grid_timestamp_us.to_numpy(), grid)
                assert np.array_equal(mapped.source_csv_line.to_numpy(), lines)
                assert np.array_equal(mapped.source_timestamp_us.to_numpy(), frame.timestamp.to_numpy()[indices])
                selected = values.source_csv_line.isin(set(lines)).to_numpy(bool)
                spec = configs[signal]['specification']
                threshold = spec['upper_bound'] + spec['value_epsilon']
                above = values[signal].to_numpy() > threshold
                starts = above & ~np.r_[False, above[:-1]]
                group_ids = np.cumsum(starts) * above
                selected_above = above & selected
                captured_groups = set(int(x) for x in group_ids[selected_above])
                native_groups = int(starts.sum())
                source_predicate = dict(zip(values.source_csv_line.astype(int), above.astype(bool)))
                grid_from_source = np.array([source_predicate[int(line)] for line in lines])
                grid_actual = observed[signal].to_numpy() > threshold
                assert np.array_equal(grid_from_source, grid_actual), (case, signal)
                control = controls[(controls.case_id == case) & (controls.signal == signal)].iloc[0]
                assert int(grid_actual.sum()) == int(control.violations)
                row = {'case_id': case, 'signal': signal, 'topic': topic,
                       'formula_id': configs[signal]['formula_id'],
                       'upper_bound': spec['upper_bound'], 'value_epsilon': spec['value_epsilon'],
                       'support_first_timestamp_us': int(values.timestamp_us.iloc[0]),
                       'support_last_timestamp_us': int(values.timestamp_us.iloc[-1]),
                       'native_records': len(values), 'selected_records': int(selected.sum()),
                       'native_above_bound': int(above.sum()), 'selected_above_bound': int(selected_above.sum()),
                       'omitted_above_bound': int((above & ~selected).sum()),
                       'grid_above_bound': int(grid_actual.sum()),
                       'native_groups': native_groups, 'captured_groups': len(captured_groups),
                       'uncaptured_groups': native_groups-len(captured_groups)}
                summary.append(row)
                source_group = dict(zip(values.source_csv_line.astype(int), group_ids.astype(int)))
                grid_groups = np.array([source_group[int(line)] for line in lines])
                for gid in range(1, native_groups+1):
                    mask = group_ids == gid
                    positions = np.flatnonzero(mask)
                    first, last = int(positions[0]), int(positions[-1])
                    group_details.append({'case_id': case, 'signal': signal, 'group_id': gid,
                        'first_source_csv_line': int(values.source_csv_line.iloc[first]),
                        'last_source_csv_line': int(values.source_csv_line.iloc[last]),
                        'first_timestamp_us': int(values.timestamp_us.iloc[first]),
                        'last_timestamp_us': int(values.timestamp_us.iloc[last]),
                        'first_relative_to_grid_us': int(values.timestamp_us.iloc[first])-int(grid[0]),
                        'last_relative_to_grid_us': int(values.timestamp_us.iloc[last])-int(grid[0]),
                        'above_bound_records': int(mask.sum()),
                        'selected_above_bound_records': int((mask & selected).sum()),
                        'grid_above_bound_observations': int((grid_groups == gid).sum())})
                for i in range(len(values)):
                    rw.writerow({'case_id': case, 'signal': signal, 'topic': topic, 'record_index': i,
                                 'source_csv_line': int(values.source_csv_line.iloc[i]),
                                 'timestamp_us': int(values.timestamp_us.iloc[i]), 'selected': int(selected[i]),
                                 'above_bound': int(above[i]), 'group_id': int(group_ids[i])})
                    vw.writerow([case, signal, i, format(float(values[signal].iloc[i]), '.17g')])
                count += len(values)
    table = pd.DataFrame(summary)
    assert len(table) == 15 and not table[['case_id', 'signal']].duplicated().any()
    table.to_csv(args.output / 'capture_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(group_details).to_csv(args.output / 'group_details.csv', index=False, encoding='utf-8-sig')
    selected_cols = ['case_id', 'signal', 'formula_id', 'upper_bound', 'value_epsilon']
    table[selected_cols].to_csv(args.output / 'predicate_parameters.csv', index=False, encoding='utf-8-sig', float_format='%.17g')
    write(args.output / 'source_manifest.json', {
        'inputs': [{'name': k, 'path': str(getattr(args, k)), 'sha256': digest(getattr(args, k))}
                   for k in ['protocol', 'fingerprints', 'source_helper', 'value_helper', 'configurations', 'mappings', 'grid_controls']],
        'whole_files': list(inputs.values()), 'native_members': native_members,
        'frozen_grid_reconstructions': reconstructions,
        'derived_files_sha256': {name: digest(args.output / name) for name in
          ['capture_records.csv', 'values_for_verification.csv', 'capture_summary.csv', 'predicate_parameters.csv', 'group_details.csv']}})
    write(args.output / 'audit_receipt.json', {'status': 'passed', 'case_signal_cells': 15,
          'source_record_signal_rows': count, 'frozen_grid_reconstructions_exact': 6,
          'observed_above_bound_groups': len(group_details),
          'grid_invariant_controls_exact': 15, 'grid_predicate_vs_source_selection_exact': True,
          'matched_native_source_endpoints': True, 'new_monitor_verdicts': 0,
          'new_flights': 0, 'new_human_labels': 0, 'new_model_calls': 0,
          'capture_is_not_diagnostic_recall': True, 'groups_do_not_assert_physical_continuity': True})
    print(table[['case_id', 'signal', 'native_records', 'selected_records', 'native_above_bound',
                 'selected_above_bound', 'grid_above_bound', 'native_groups', 'captured_groups']].to_string(index=False))


if __name__ == '__main__':
    main()
