"""Audit all three frozen RflyMAD replay grids against native record timestamps.

No downloads, monitor calls, labels or parameter changes. Refuses overwrite.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import io
import json
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation

CASES = ('406_1', '406_2', '407_1')
TOPICS = ('local_position', 'vehicle_attitude', 'vehicle_angular_velocity')
SIGNALS = {
    'local_position': 'speed_3d_mps;height_m',
    'vehicle_attitude': 'abs_roll_rad;abs_pitch_rad',
    'vehicle_angular_velocity': 'ang_rate_norm_rps',
}

def digest(path):
    h = sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def csv_bytes(frame):
    # Fingerprints describe the original Windows CSV serialization boundary.
    return frame.to_csv(index=False, lineterminator='\r\n').encode('utf-8-sig')

def source_frames(case, root, source, input_receipts):
    frames = {}
    bounds = []
    source_rows = []
    for record in source['input_records']:
        path = root / record['path']
        if str(path) not in input_receipts:
            print(json.dumps({'checking': str(path), 'bytes': path.stat().st_size}), flush=True)
            actual = digest(path)
            assert actual == record['sha256'], path
            assert path.stat().st_size == record['bytes']
            input_receipts[str(path)] = {**record, 'absolute_path': str(path), 'verified_sha256': actual}
        if path.suffix != '.zip':
            topic = next((t for t in TOPICS if t in path.name), None)
            # The first two cases name their position topic estimator_local_position.
            if 'estimator_local_position' in path.name:
                topic = 'local_position'
            if topic is None:
                control = pd.read_csv(path, usecols=['timestamp'])
                bounds.append(control['timestamp'])
                continue
            raw = path.read_bytes()
            source_rows.append({'case_id': case, 'topic': topic, 'path': record['path'],
                                'member': None, 'sha256': sha256(raw).hexdigest()})
            frames[topic] = pd.read_csv(io.BytesIO(raw))
        else:
            with zipfile.ZipFile(path) as archive:
                matches = [name for name in archive.namelist()
                           if name.startswith('acce/407_1/log_') and name.endswith('_vehicle_local_position_0.csv')]
                assert len(matches) == 1, matches
                prefix = matches[0].removesuffix('vehicle_local_position_0.csv')
                for topic, actual in zip(TOPICS, ['vehicle_local_position', *TOPICS[1:]]):
                    member = prefix + actual + '_0.csv'
                    raw = archive.read(member)
                    source_rows.append({'case_id': case, 'topic': topic, 'path': record['path'],
                                        'member': member, 'sha256': sha256(raw).hexdigest()})
                    frames[topic] = pd.read_csv(io.BytesIO(raw))
    for topic, frame in frames.items():
        frame['_source_csv_line'] = np.arange(len(frame), dtype=np.int64) + 2
        ts = frame['timestamp'].to_numpy()
        assert np.issubdtype(ts.dtype, np.integer) and np.all(np.diff(ts) > 0), (case, topic)
        assert np.all(np.isfinite(ts))
        bounds.append(frame['timestamp'])
    start = int(max(x.min() for x in bounds))
    end = int(min(x.max() for x in bounds))
    assert (start, end) == (source['grid_start_us'], source['grid_end_us']), case
    return frames, source_rows, start, end

def rebuild_observations(case, frames, grid):
    # Reproduce the historical adapter, independently located by searchsorted.
    state = pd.DataFrame({'timestamp': grid})
    used = {}
    columns = {
        'local_position': ['x', 'y', 'z', 'vx', 'vy', 'vz'],
        'vehicle_attitude': ['q[0]', 'q[1]', 'q[2]', 'q[3]'],
        'vehicle_angular_velocity': ['xyz[0]', 'xyz[1]', 'xyz[2]'],
    }
    for topic, frame in frames.items():
        ts = frame.timestamp.to_numpy(np.int64)
        indices = np.searchsorted(ts, grid, side='right') - 1
        assert np.all(indices >= 0)
        # Separate pandas as-of implementation must choose every identical source row.
        test = pd.merge_asof(pd.DataFrame({'timestamp': grid}), frame[['timestamp', '_source_csv_line']],
                             on='timestamp', direction='backward')
        assert np.array_equal(test['_source_csv_line'], frame['_source_csv_line'].to_numpy()[indices])
        for name in columns[topic]:
            state[name] = frame[name].to_numpy()[indices]
        used[topic] = indices
    q = state[['q[1]', 'q[2]', 'q[3]', 'q[0]']].to_numpy(float)
    if case == '407_1':
        x, y, z, w = q.T
        state['roll'] = np.arctan2(2*(w*x+y*z), 1-2*(x*x+y*y))
        state['pitch'] = np.arcsin(np.clip(2*(w*y-z*x), -1, 1))
        state['yaw'] = np.arctan2(2*(w*z+x*y), 1-2*(y*y+z*z))
    else:
        state[['roll', 'pitch', 'yaw']] = Rotation.from_quat(q).as_euler('xyz', degrees=False)
    state = state.rename(columns={'x':'pos_n','y':'pos_e','z':'pos_d','vx':'vel_n','vy':'vel_e','vz':'vel_d',
                                  'xyz[0]':'ang_rate_x','xyz[1]':'ang_rate_y','xyz[2]':'ang_rate_z'})
    online = state[['pos_n','pos_e','pos_d','vel_n','vel_e','vel_d','roll','pitch','yaw',
                    'ang_rate_x','ang_rate_y','ang_rate_z']].copy()
    online['time_seconds'] = (grid - grid[0])/1e6
    raw = pd.read_csv(io.BytesIO(csv_bytes(online)))
    observed = pd.DataFrame({'time_seconds':raw['time_seconds'],
        'speed_3d_mps':(raw['vel_n']**2+raw['vel_e']**2+raw['vel_d']**2)**.5,
        'height_m':raw['pos_d'].abs(), 'abs_roll_rad':raw['roll'].abs(), 'abs_pitch_rad':raw['pitch'].abs(),
        'ang_rate_norm_rps':(raw['ang_rate_x']**2+raw['ang_rate_y']**2+raw['ang_rate_z']**2)**.5})
    assert np.all(np.isfinite(observed.to_numpy()))
    return online, observed, used

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, required=True, help='Existing materials directory')
    parser.add_argument('--reference-fingerprints', type=Path, required=True)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}')
    protocol = json.loads(args.protocol.read_text(encoding='utf-8'))
    assert protocol['protocol_id'] == 'v55-native-record-age-20261104'
    assert protocol['descriptive_age_cutoff_us'] == 100000
    expected = json.loads(args.reference_fingerprints.read_text(encoding='utf-8'))
    args.output.mkdir(parents=True)
    inputs = {}; members = []; summaries = []; mappings = []; reconstruct = []
    for case in CASES:
        source = expected['raw_sources'][case]
        frames, rows, start, end = source_frames(case, args.input_root, source, inputs)
        members.extend(rows)
        grid = np.arange(start, end+1, 50000, dtype=np.int64)
        online, observed, used = rebuild_observations(case, frames, grid)
        for suffix, frame in [('online_input', online), ('observable_trace', observed)]:
            record = next(r for r in expected['derived_outputs']
                          if r['file'] == f'multi_real_motor_replay/{case}_{suffix}.csv')
            actual = sha256(csv_bytes(frame)).hexdigest()
            assert actual == record['sha256'], (case, suffix, actual, record['sha256'])
            reconstruct.append({'case_id':case, 'type':suffix, 'rows':len(frame), 'sha256':actual,
                                'byte_exact_to_frozen':True})
        for topic, frame in frames.items():
            indices = used[topic]
            ts = frame.timestamp.to_numpy(np.int64)
            source_ts = ts[indices]
            age = grid - source_ts
            assert np.all(age >= 0)
            support = ts[indices[0]:indices[-1]+1]
            gaps = np.diff(support)
            assert len(gaps) > 0 and np.all(gaps > 0)
            summaries.append({'case_id':case, 'topic':topic, 'derived_signals':SIGNALS[topic],
                'grid_observations':len(grid), 'native_support_records':len(support),
                'distinct_used_records':len(np.unique(indices)),
                'reused_grid_observations':len(grid)-len(np.unique(indices)),
                'age_median_us':float(np.median(age)), 'age_p95_us':float(np.quantile(age,.95)),
                'age_max_us':int(max(age)), 'age_at_least_100ms_count':int(np.sum(age>=100000)),
                'native_gap_max_us':int(max(gaps)), 'native_gap_gt_100ms_count':int(np.sum(gaps>100000)),
                'native_20hz_jitter_profile_pass':bool(np.all(abs(gaps-50000)<=2500.001) and np.all(gaps<=100000.001)),
                'native_100ms_event_gap_pass':bool(np.all(gaps<=100000.001)),
                'grid_20hz_timing_pass':bool(np.all(np.diff(grid)==50000)),
                'record_age_not_physical_sensor_age':True})
            mappings.extend({'case_id':case, 'topic':topic, 'grid_index':j, 'grid_timestamp_us':int(g),
                             'source_csv_line':int(frame['_source_csv_line'].iloc[k]),
                             'source_timestamp_us':int(ts[k]), 'record_age_us':int(g-ts[k])}
                            for j,(g,k) in enumerate(zip(grid,indices)))
    pd.DataFrame(summaries).to_csv(args.output/'topic_summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(mappings).to_csv(args.output/'point_source_coordinates.csv',index=False,encoding='utf-8-sig')
    write(args.output/'reconstruction_exactness.json', reconstruct)
    write(args.output/'source_inputs.json', {'protocol_sha256':digest(args.protocol),
          'reference_fingerprints_sha256':digest(args.reference_fingerprints),
          'whole_files':list(inputs.values()),'native_members':members})
    write(args.output/'audit_receipt.json', {'status':'passed', 'cases':3, 'native_topic_streams':9,
          'grid_rows':sum(r['rows'] for r in reconstruct if r['type']=='observable_trace'),
          'point_topic_mappings':len(mappings), 'frozen_derived_files_byte_exact':len(reconstruct),
          'cross_checked_lookup_methods':['numpy.searchsorted','pandas.merge_asof'],
          'new_flights':0,'new_labels':0,'new_predictions':0,'monitor_parameters_changed':False,
          'monitor_verdicts_recomputed':False,'source_age_diagnostic_not_admission_policy':True})
    print(pd.DataFrame(summaries).to_string(index=False))
    print(json.dumps({'status':'passed','output':str(args.output),'point_mappings':len(mappings)}),flush=True)

if __name__ == '__main__':
    main()
