"""Reconstruct source selection, threshold truth and groups with SQL windows."""
from __future__ import annotations
import argparse
import csv
from hashlib import sha256
import json
import math
from pathlib import Path
import sqlite3


def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        yield from csv.DictReader(stream)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', required=True, type=Path)
    parser.add_argument('--mappings', required=True, type=Path)
    parser.add_argument('--grid-controls', required=True, type=Path)
    args = parser.parse_args()
    target = args.results / 'independent_sql_verification.json'
    assert not target.exists()
    manifest = json.loads((args.results / 'source_manifest.json').read_text(encoding='utf-8'))
    original = {r['name']: r for r in manifest['inputs']}
    assert digest(args.mappings) == original['mappings']['sha256']
    assert digest(args.grid_controls) == original['grid_controls']['sha256']
    for name, h in manifest['derived_files_sha256'].items():
        assert digest(args.results / name) == h
    db = sqlite3.connect(':memory:')
    db.executescript('''
    CREATE TABLE r(case_id TEXT, signal TEXT, topic TEXT, ordinal INTEGER, source_line INTEGER,
                   timestamp_us INTEGER, selected INTEGER, above INTEGER, group_id INTEGER,
                   PRIMARY KEY(case_id,signal,ordinal));
    CREATE TABLE v(case_id TEXT, signal TEXT, ordinal INTEGER, value REAL,
                   PRIMARY KEY(case_id,signal,ordinal));
    CREATE TABLE p(case_id TEXT, signal TEXT, upper_bound REAL, epsilon REAL,
                   PRIMARY KEY(case_id,signal));
    CREATE TABLE maps(case_id TEXT, topic TEXT, grid_index INTEGER, source_line INTEGER,
                      timestamp_us INTEGER, source_timestamp_us INTEGER,
                      PRIMARY KEY(case_id,topic,grid_index));
    CREATE INDEX source_map ON maps(case_id,topic,source_line);
    ''')
    record_fields = ['case_id', 'signal', 'topic', 'record_index', 'source_csv_line', 'timestamp_us', 'selected', 'above_bound', 'group_id']
    db.executemany('INSERT INTO r VALUES(?,?,?,?,?,?,?,?,?)',
                   ([r[k] for k in record_fields] for r in rows(args.results / 'capture_records.csv')))
    def values():
        for r in rows(args.results / 'values_for_verification.csv'):
            value = float(r['value'])
            assert math.isfinite(value)
            yield r['case_id'], r['signal'], int(r['record_index']), value
    db.executemany('INSERT INTO v VALUES(?,?,?,?)', values())
    db.executemany('INSERT INTO p VALUES(?,?,?,?)',
                   ((r['case_id'], r['signal'], float(r['upper_bound']), float(r['value_epsilon']))
                    for r in rows(args.results / 'predicate_parameters.csv')))
    db.executemany('INSERT INTO maps VALUES(?,?,?,?,?,?)',
                   ((r['case_id'], r['topic'], int(r['grid_index']), int(r['source_csv_line']),
                     int(r['grid_timestamp_us']), int(r['source_timestamp_us'])) for r in rows(args.mappings)))
    n = db.execute('SELECT count(*) FROM r').fetchone()[0]
    assert n == db.execute('SELECT count(*) FROM v').fetchone()[0]
    assert db.execute('SELECT count(*) FROM maps').fetchone()[0] == 11139
    assert db.execute('SELECT count(*) FROM p').fetchone()[0] == 15
    db.executescript('''
    CREATE TEMP TABLE computed AS
    WITH truth AS (
      SELECT r.*, CASE WHEN v.value > p.upper_bound+p.epsilon THEN 1 ELSE 0 END AS true_above,
        EXISTS(SELECT 1 FROM maps m WHERE m.case_id=r.case_id AND m.topic=r.topic
               AND m.source_line=r.source_line) AS true_selected
      FROM r JOIN v USING(case_id,signal,ordinal) JOIN p USING(case_id,signal)
    ), previous AS (
      SELECT *, lag(true_above,1,0) OVER(PARTITION BY case_id,signal ORDER BY ordinal) AS prev
      FROM truth
    ), numbered AS (
      SELECT *, sum(CASE WHEN true_above=1 AND prev=0 THEN 1 ELSE 0 END)
        OVER(PARTITION BY case_id,signal ORDER BY ordinal ROWS UNBOUNDED PRECEDING) AS run
      FROM previous
    )
    SELECT *, CASE WHEN true_above=1 THEN run ELSE 0 END AS true_group FROM numbered;
    CREATE INDEX computed_source ON computed(case_id,topic,source_line);
    ''')
    assert db.execute('SELECT count(*) FROM computed').fetchone()[0] == n
    assert db.execute('SELECT count(*) FROM computed WHERE above!=true_above OR selected!=true_selected OR group_id!=true_group').fetchone()[0] == 0
    db.row_factory = sqlite3.Row
    aggregate = { (r['case_id'], r['signal']): dict(r) for r in db.execute('''
      SELECT case_id,signal,count(*) AS native_records,sum(true_selected) AS selected_records,
       sum(true_above) AS native_above_bound,sum(true_above*true_selected) AS selected_above_bound,
       sum(true_above*(1-true_selected)) AS omitted_above_bound,
       count(DISTINCT CASE WHEN true_above=1 THEN true_group END) AS native_groups,
       count(DISTINCT CASE WHEN true_above=1 AND true_selected=1 THEN true_group END) AS captured_groups,
       min(timestamp_us) AS support_first_timestamp_us,max(timestamp_us) AS support_last_timestamp_us
      FROM computed GROUP BY case_id,signal''') }
    for r in db.execute('''SELECT c.case_id,c.signal,sum(c.true_above) AS total FROM maps m
                          JOIN computed c ON c.case_id=m.case_id AND c.topic=m.topic AND c.source_line=m.source_line
                          GROUP BY c.case_id,c.signal'''):
        aggregate[(r['case_id'], r['signal'])]['grid_above_bound'] = r['total']
    controls = {(r['case_id'], r['signal']): int(r['violations']) for r in rows(args.grid_controls)
                if r['profile'] == 'grid_frozen' and r['template'] == 'invariant_upper'}
    for r in rows(args.results / 'capture_summary.csv'):
        key = r['case_id'], r['signal']
        expected = aggregate[key]
        expected['uncaptured_groups'] = expected['native_groups']-expected['captured_groups']
        for k, value in expected.items():
            if k not in ['case_id', 'signal']:
                assert int(r[k]) == value, (key, k, r[k], value)
        assert expected['grid_above_bound'] == controls[key]
    assert len(aggregate) == len(controls) == 15
    # Exact locators for every above-bound group, including completely unselected groups.
    group_details = {(r['case_id'], r['signal'], r['group_id']): dict(r) for r in db.execute('''
      SELECT case_id,signal,true_group AS group_id,min(source_line) AS first_source_csv_line,
       max(source_line) AS last_source_csv_line,min(timestamp_us) AS first_timestamp_us,
       max(timestamp_us) AS last_timestamp_us,count(*) AS above_bound_records,
       sum(true_selected) AS selected_above_bound_records
      FROM computed WHERE true_above=1 GROUP BY case_id,signal,true_group''')}
    for r in db.execute('''SELECT c.case_id,c.signal,c.true_group AS group_id,count(*) AS n
                           FROM maps m JOIN computed c ON c.case_id=m.case_id AND c.topic=m.topic
                           AND c.source_line=m.source_line WHERE c.true_above=1
                           GROUP BY c.case_id,c.signal,c.true_group'''):
        group_details[(r['case_id'], r['signal'], r['group_id'])]['grid_above_bound_observations'] = r['n']
    group_rows = list(rows(args.results / 'group_details.csv'))
    assert len(group_rows) == len(group_details)
    for r in group_rows:
        key = r['case_id'], r['signal'], int(r['group_id'])
        expected = group_details[key]
        expected.setdefault('grid_above_bound_observations', 0)
        for field, value in expected.items():
            if field not in ['case_id', 'signal']:
                assert int(r[field]) == value, (key, field)
        origin = db.execute('SELECT min(timestamp_us) FROM maps WHERE case_id=?', (r['case_id'],)).fetchone()[0]
        assert int(r['first_relative_to_grid_us']) == expected['first_timestamp_us']-origin
        assert int(r['last_relative_to_grid_us']) == expected['last_timestamp_us']-origin
    # Every native row between the two selected endpoint rows is present, without gaps in row numbers.
    for r in db.execute('''SELECT case_id,signal,topic,count(*) AS n,min(source_line) AS lo,max(source_line) AS hi
                          FROM computed GROUP BY case_id,signal,topic'''):
        assert r['n'] == r['hi']-r['lo']+1
        endpoints = db.execute('SELECT min(source_line),max(source_line) FROM maps WHERE case_id=? AND topic=?',
                               (r['case_id'], r['topic'])).fetchone()
        assert (r['lo'], r['hi']) == tuple(endpoints)
    receipt = {'status': 'passed', 'case_signal_cells': 15, 'record_signal_rows_checked': n,
               'source_mapping_rows_checked': 11139, 'threshold_truth_checked_all_rows': True,
               'exact_observed_group_locators_checked': len(group_details),
               'selection_membership_checked_all_rows': True, 'groups_rebuilt_with_sql_windows': True,
               'matched_native_support_endpoints_checked': True, 'grid_invariant_controls_checked': 15,
               'zero_exceedance_cells_retained': sum(r['native_above_bound'] == 0 for r in aggregate.values()),
               'scope': 'Consistency of freshly regenerated derived values and source coordinates; raw-data regeneration is an external-input prerequisite.',
               'new_monitor_verdicts': 0, 'new_physical_fault_labels': 0}
    target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
