"""Draw the N06 publication view from the frozen, reconciled Neo4j export.

This is a vector redraw, not a Neo4j Browser screenshot. The native PDF/PNG
remain unchanged. No database or Docker process is opened by this script.
Run with the bundled Python runtime, which includes ReportLab.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_PAPER = ROOT / "docs/最终论文/latex_kbs_v38_du_review_20261024"
RELATIONS = {
    "FORMALIZED_AS": (1, "formalized as"),
    "USES_TEMPLATE": (2, "uses template"),
    "IMPLEMENTED_BY": (3, "implemented by"),
    "EXECUTED_BY": (4, "executed by"),
    "HAS_PARAMETER_BINDING": (5, "has parameter", "binding"),
    "BINDS_PARAMETER": (6, "binds parameter"),
    "APPLIES_TO_SIGNAL": (7, "applies to signal"),
    "READS_SIGNAL": (8, "reads signal"),
}
ROLE_ORDER = ["trigger_upper", "recovery_upper", "deadline_seconds", "dwell_seconds", "value_epsilon"]
EXPECTED_RELATIONS = {name: (5 if num in (5, 6, 7) else 1)
                      for name, (num, *_) in RELATIONS.items()}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def extract(paper):
    research = paper / "research/neo4j"
    node_path = research / "data/frozen_graph_nodes.csv"
    edge_path = research / "data/frozen_graph_relationships.csv"
    full_nodes = {n["id"]: n for n in rows(node_path)}
    full_edges = rows(edge_path)
    assert len(full_nodes) == 158 and len(full_edges) == 350
    req = "requirement:N06"
    req_edges = [e for e in full_edges if e["source"] == req and e["relation"] == "FORMALIZED_AS"]
    assert len(req_edges) == 1
    formula = req_edges[0]["target"]
    formula_edges = [e for e in full_edges if e["source"] == formula and e["relation"] in RELATIONS]
    bindings = [e["target"] for e in formula_edges if e["relation"] == "HAS_PARAMETER_BINDING"]
    templates = [e["target"] for e in formula_edges if e["relation"] == "USES_TEMPLATE"]
    edges = req_edges + formula_edges + [
        e for e in full_edges
        if (e["source"] in bindings and e["relation"] in ("BINDS_PARAMETER", "APPLIES_TO_SIGNAL"))
        or (e["source"] in templates and e["relation"] == "IMPLEMENTED_BY")
    ]
    edges.sort(key=lambda e: (e["source"], e["relation"], e["target"]))
    ids = {e[k] for e in edges for k in ("source", "target")}
    nodes = {i: full_nodes[i] for i in sorted(ids)}
    assert len(nodes) == 15 and len(edges) == 20
    assert dict(Counter(e["relation"] for e in edges)) == EXPECTED_RELATIONS
    assert len(set((e["source"], e["relation"], e["target"]) for e in edges)) == 20
    props = {i: json.loads(n["properties_json"]) for i, n in nodes.items()}
    native_rows = json.loads((research / "n06_binding_query_result.json").read_text(encoding="utf-8"))
    native_receipt = json.loads((research / "neo4j_final_after_export_receipt.json").read_text(encoding="utf-8"))
    assert native_receipt["status"] == "passed"
    assert native_receipt["roundtrip"]["all_source_labels_properties_and_endpoints_equal"] is True
    assert native_receipt["queries"]["n06_query_nodes"] == len(nodes)
    assert native_receipt["queries"]["n06_query_relationships"] == len(edges)
    for filename in ("fig04_neo4j_n06.pdf", "fig04_neo4j_n06.png"):
        assert sha256(paper / "figures" / filename) == native_receipt["native_figures_sha256"][filename]
    native_by_role = {r["role"]: r for r in native_rows}
    binding_rows = []
    for role in ROLE_ORDER:
        b = f"binding:N06:{role}"
        p = props[b]["parameter_id"]
        assert (b, "BINDS_PARAMETER", p) in {(e["source"], e["relation"], e["target"]) for e in edges}
        assert (b, "APPLIES_TO_SIGNAL", "signal:speed_3d_mps") in {(e["source"], e["relation"], e["target"]) for e in edges}
        query = native_by_role[role]
        assert query["parameter_id"] == p
        assert query["value"] == props[p]["value"] and query["unit"] == props[p]["unit"]
        assert float(format(props[p]["value"], ".15g")) == props[p]["value"]
        binding_rows.append({"binding_id": b, "role": role, "parameter_id": p,
                             "value": props[p]["value"], "unit": props[p]["unit"],
                             "display_value": format(props[p]["value"], ".15g")})
    assert set(native_by_role) == set(ROLE_ORDER)
    return nodes, edges, props, binding_rows, [node_path, edge_path,
        research / "n06_graph.cypher", research / "n06_binding_query_result.json",
        research / "neo4j_final_after_export_receipt.json"]


def draw(paper, nodes, edges, props, binding_rows):
    out = paper / "figures/fig04_neo4j_n06_publication.pdf"
    pdfmetrics.registerFont(TTFont("FigureArial", "C:/Windows/Fonts/arial.ttf"))
    pdfmetrics.registerFont(TTFont("FigureArialBold", "C:/Windows/Fonts/arialbd.ttf"))
    width, height = 576, 606
    c = canvas.Canvas(str(out), pagesize=(width, height), pageCompression=1, invariant=1)
    c.setTitle("N06 traceability graph: publication view from the frozen Neo4j export")
    c.setSubject("15 nodes and 20 directed relationships; original Browser exports retained separately")
    c.setAuthor("STKG manuscript research artifacts")
    ink = HexColor("#172532")
    muted = HexColor("#526472")
    line = HexColor("#596773")
    fills = {"Requirement": "#E8F0F7", "STLFormula": "#DFEAF4", "STLTemplate": "#E8F0F7",
             "RuntimeMonitor": "#E8F0F7", "Signal": "#E1EFEA", "ParameterBinding": "#FFF0D2",
             "FormulaParameter": "#E4EFE9"}
    positions = {
        "requirement:N06": (64, 550, 84, 40),
        "formula:N06": (64, 350, 84, 40),
        "template:bounded_response": (64, 218, 84, 52),
        "monitor:sampled_point_bounded_response_v2": (64, 95, 84, 64),
        "signal:speed_3d_mps": (364, 350, 84, 52),
    }
    for i, r in enumerate(binding_rows):
        y = 550 - i * 100
        positions[r["binding_id"]] = (215, y, 114, 36)
        positions[r["parameter_id"]] = (215, y - 54, 122, 42)

    def text(x, y, value, size=10.8, bold=False, align="center", color=ink):
        c.setFillColor(color)
        c.setFont("FigureArialBold" if bold else "FigureArial", size)
        {"center": c.drawCentredString, "left": c.drawString, "right": c.drawRightString}[align](x, y, value)

    def edge_number(x, y, n):
        c.setFillColor(white)
        c.roundRect(x - 5.2, y - 5.2, 10.4, 10.4, 2.5, fill=1, stroke=0)
        text(x, y - 3.45, str(n), 10.0)

    def arrow(points, number, label):
        c.setStrokeColor(line)
        c.setFillColor(line)
        c.setLineWidth(0.78)
        p = c.beginPath()
        p.moveTo(*points[0])
        for q in points[1:]:
            p.lineTo(*q)
        c.drawPath(p)
        x0, y0 = points[-2]
        x1, y1 = points[-1]
        a = math.atan2(y1 - y0, x1 - x0)
        length, halfwidth = 4.1, 1.65
        ah = c.beginPath()
        ah.moveTo(x1, y1)
        ah.lineTo(x1 - length * math.cos(a) + halfwidth * math.sin(a),
                  y1 - length * math.sin(a) - halfwidth * math.cos(a))
        ah.lineTo(x1 - length * math.cos(a) - halfwidth * math.sin(a),
                  y1 - length * math.sin(a) + halfwidth * math.cos(a))
        ah.close()
        c.drawPath(ah, fill=1, stroke=0)
        edge_number(*label, number)

    drawn = []
    for e in edges:
        src, rel, dst = e["source"], e["relation"], e["target"]
        sx, sy, sw, sh = positions[src]
        tx, ty, tw, th = positions[dst]
        num = RELATIONS[rel][0]
        if rel == "FORMALIZED_AS":
            pts, lab = [(sx, sy-sh/2), (tx, ty+th/2)], (sx, 446)
        elif rel in ("USES_TEMPLATE", "IMPLEMENTED_BY"):
            pts, lab = [(sx, sy-sh/2), (tx, ty+th/2)], (sx, (sy-sh/2+ty+th/2)/2)
        elif rel == "EXECUTED_BY":
            pts = [(sx-sw/2, sy), (16, sy), (16, ty), (tx-tw/2, ty)]
            lab = (16, 274)
        elif rel == "READS_SIGNAL":
            pts = [(sx-sw/2, sy-10), (8, sy-10), (8, 38), (tx, 38), (tx, ty-th/2)]
            lab = (tx, 202)
        elif rel == "HAS_PARAMETER_BINDING":
            pts = [(sx+sw/2, sy), (tx-tw/2, ty)]
            lab = ((sx+sw/2+tx-tw/2)/2, (sy+ty)/2)
        elif rel == "BINDS_PARAMETER":
            pts = [(sx, sy-sh/2), (tx, ty+th/2)]
            lab = (sx+13, (sy-sh/2+ty+th/2)/2)
        elif rel == "APPLIES_TO_SIGNAL":
            pts = [(sx+sw/2, sy), (tx-tw/2, ty)]
            lab = ((sx+sw/2+tx-tw/2)/2, (sy+ty)/2)
        else:
            raise AssertionError(rel)
        arrow(pts, num, lab)
        drawn.append({"source": src, "relation": rel, "target": dst, "number": num,
                      "path_points_pt": pts})

    def box(node_id, kind, lines):
        x, y, w, h = positions[node_id]
        c.setFillColor(HexColor(fills[kind]))
        c.setStrokeColor(HexColor("#738392"))
        c.setLineWidth(0.75)
        c.roundRect(x-w/2, y-h/2, w, h, 7, fill=1, stroke=1)
        for dy, label, size, bold in lines:
            assert pdfmetrics.stringWidth(label, "FigureArialBold" if bold else "FigureArial", size) <= w-8, (node_id, label)
            text(x, y+dy, label, size, bold)

    box("requirement:N06", "Requirement", [(5, "Requirement", 9.5, False), (-10, "N06", 12.0, True)])
    box("formula:N06", "STLFormula", [(5, "STLFormula", 9.5, False), (-10, "N06", 12.0, True)])
    box("template:bounded_response", "STLTemplate", [(12, "STLTemplate", 9.4, False), (-3, "bounded", 11.0, True), (-17, "response", 11.0, True)])
    box("monitor:sampled_point_bounded_response_v2", "RuntimeMonitor", [(18, "RuntimeMonitor", 9.3, False), (3, "sampled-point", 10.6, True), (-11, "bounded", 10.6, True), (-25, "response v2", 10.6, True)])
    box("signal:speed_3d_mps", "Signal", [(12, "Signal", 9.5, False), (-3, "3D speed", 11.4, True), (-17, "m/s", 10.8, False)])
    for r in binding_rows:
        box(r["binding_id"], "ParameterBinding", [(5, "ParameterBinding", 9.4, False), (-10, r["role"], 11.2, True)])
        box(r["parameter_id"], "FormulaParameter", [(10, "FormulaParameter", 9.4, False), (-4, r["display_value"], 11.2, True), (-18, r["unit"], 10.8, False)])

    # This legend is part of the vector figure, so readers need no caption lookup.
    c.setStrokeColor(HexColor("#AEB9C1"))
    c.setLineWidth(0.65)
    c.line(418, 62, 418, 574)
    text(430, 563, "RELATION KEY", 11.2, True, "left")
    y = 537
    for relation, (num, *labels) in RELATIONS.items():
        edge_number(434, y+3, num)
        for j, value in enumerate(labels):
            text(448, y-j*13, value, 10.7, align="left")
        y -= 39 if len(labels) == 1 else 47
    text(430, y-6, "Arrows show direction.", 9.5, align="left", color=muted)
    text(430, y-22, "15 nodes; 20 relations", 9.5, align="left", color=muted)
    text(430, y-59, "Node types appear", 10.0, align="left", color=muted)
    text(430, y-73, "inside every box.", 10.0, align="left", color=muted)
    text(430, y-110, "Parameter values use", 9.5, align="left", color=muted)
    text(430, y-124, "stored precision.", 9.5, align="left", color=muted)
    text(430, y-161, "Publication view of", 9.5, align="left", color=muted)
    text(430, y-175, "frozen Neo4j export", 9.5, align="left", color=muted)
    c.showPage()
    c.save()
    assert len(drawn) == 20 and set(positions) == set(nodes)
    return out, drawn, {"width_pt": width, "height_pt": height,
                        "recommended_latex_width": "0.98\\textwidth",
                        "font_sizes_pt_at_native_size": {"type_labels": "9.3-9.5", "binding_roles": 11.2,
                            "parameter_values": 11.2, "parameter_units": 10.8,
                            "relationship_key": 10.7, "edge_numbers": 10.0}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-dir", type=Path, default=DEFAULT_PAPER)
    args = parser.parse_args()
    paper = args.paper_dir.resolve()
    original_paths = [paper / f"figures/fig04_neo4j_n06.{ext}" for ext in ("pdf", "png")]
    originals_before = {str(p.relative_to(paper)): sha256(p) for p in original_paths}
    nodes, edges, props, bindings, sources = extract(paper)
    output, drawn, rendering = draw(paper, nodes, edges, props, bindings)
    originals_after = {str(p.relative_to(paper)): sha256(p) for p in original_paths}
    assert originals_before == originals_after
    receipt = {
        "status": "passed", "review_comment": "D14", "figure": "Figure 4",
        "method": "Vector publication view redrawn from frozen CSV export reconciled with actual Neo4j; not a native Browser screenshot",
        "database_started": False, "native_browser_sources_preserved": originals_after,
        "sources_sha256": {str(p.relative_to(paper)): sha256(p) for p in sources},
        "checks": {"full_export_nodes": 158, "full_export_relationships": 350,
                   "selected_nodes": len(nodes), "selected_relationships": len(edges),
                   "relationship_counts": dict(sorted(Counter(e["relation"] for e in edges).items())),
                   "distinct_binding_nodes": 5, "distinct_parameter_nodes": 5,
                   "five_values_units_parameter_ids_match_native_query": True,
                   "every_selected_edge_drawn_once": len(drawn) == len(edges),
                   "every_selected_node_drawn_once": True},
        "nodes": [{"id": i, "labels": n["labels"]} for i, n in nodes.items()],
        "edges": drawn, "parameter_display": bindings, "rendering": rendering,
        "output": str(output.relative_to(paper)), "output_sha256": sha256(output),
        "limitations": ["Presentation layout and shortened display captions are newly drawn; source records, endpoints, and parameter values are unchanged.",
                        "Thresholds and the 2 s deadline remain research references, not deployment-calibrated safety limits."]
    }
    audit = Path(__file__).with_name("figure4_publication_audit.json")
    audit.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": receipt["status"], "output": str(output), "audit": str(audit),
                      "nodes": len(nodes), "relationships": len(edges)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
