# Figure 4 离线重绘证据附件（v38，2026-10-24）

这是本地核验附件，保留内部项目路径与审计信息，不作为公开数据包，不上传 GitHub。
新图是根据已与真实 Neo4j 查询核对的冻结图数据制作的矢量出版视图，不是新的数据库实验，也不是原生 Browser 截图。原 Browser PDF/PNG 保留在 figures/ 下。

## 解压与运行

在 Windows 中完整解压此 ZIP，打开解压根目录的终端，然后运行：

    python build_figure4.py --paper-dir .

请保留 --paper-dir . 参数。脚本只读取附件内冻结资料，重写解压目录下的 publication PDF 与 figure4_publication_audit.json，不连接网络、不启动 Neo4j 或 Docker、不运行其他论文实验。

依赖：Python 3 与已安装的 ReportLab；本次独立验证使用 Python 3.12.14 / ReportLab 4.4.9。脚本读取 Windows 自带 Arial 字体 C:/Windows/Fonts/arial.ttf 和 arialbd.ttf。离线运行前须已有这些依赖。本次依赖来自已有工作区运行时，没有安装新依赖。
按字节完全一致的 PDF 复现还依赖相同的 ReportLab 版本与字体文件；本次字体 SHA-256 和依赖版本记录在 MANIFEST.json。其他环境可用附带图和审计核对内容。

## 文件与范围

- build_figure4.py：图4重绘及15节点/20关系自动核查脚本。
- figures/fig04_neo4j_n06.pdf、.png：已验收的原生 Browser 导出，原样保留。
- figures/fig04_neo4j_n06_publication.pdf、.png：正式稿使用的新矢量出版图与其预览；脚本重建 PDF，PNG 为交付预览。
- research/neo4j/data/：完整冻结图的两个 CSV（158节点、350关系），脚本选择 N06 的15节点、20条有向边。
- research/neo4j/n06_graph.cypher：归档的实际 N06 查询文本。
- research/neo4j/n06_binding_query_result.json：五绑定的实际 Neo4j 查询结果。
- research/neo4j/neo4j_final_after_export_receipt.json：现有真实数据库核验收据，包含原 Browser 图的哈希与15/20查询规模。
- figure4_publication_audit.json、figure4_visual_qa.json：重绘内容与矢量/视觉审计。
- MANIFEST.json：除清单自身以外的所有文件大小与 SHA-256；ZIP 根目录无额外套层。

自动核查包含：完整图158/350规模、N06的15节点/20关系、20条边各绘一次、5个独立绑定与5个独立参数、参数ID/值/单位与实际查询逐项一致、原Browser PDF/PNG哈希匹配历史收据。两个阈值保留6.62613257694774 m/s和5.82665111059551 m/s；另有2 s、0 s和0 m/s。重绘只改变排布和显示，不改变冻结值。
阈值与两秒期限仍属于研究参考/原型配置，现有论文中的适用边界继续有效。
