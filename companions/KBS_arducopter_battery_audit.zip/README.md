# ArduCopter low-voltage persistence audit

Obtain the original DataFlash log from the operator's report (https://discuss.ardupilot.org/t/145352).
The direct download is https://drive.usercontent.google.com/download?id=1fltx_zpFtINmDIvJlHw_liMBPMYpIqvr&export=download&confirm=t
Save the file as LOG.bin and use Python with pymavlink.

    python -B audit_ardupilot_battery.py LOG.bin comparison.json

Compare comparison.json to ardupilot_battery_receipt.json. BAT row numbers
are one-based. The check uses logged battery timestamps rather than internal
firmware check timestamps and validates the pre-arm settings and mode change.
