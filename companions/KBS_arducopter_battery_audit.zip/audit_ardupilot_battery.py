"""Reproduce the two low-voltage episodes in a published ArduCopter flight."""

import argparse
import json
from collections import defaultdict
from hashlib import sha256
from itertools import groupby
from pathlib import Path

from pymavlink.DFReader import DFReader_binary


FLIGHT = "https://discuss.ardupilot.org/t/145352"
DATAFLASH = "https://drive.usercontent.google.com/download?id=1fltx_zpFtINmDIvJlHw_liMBPMYpIqvr&export=download&confirm=t"
SHA256 = "4513ff8823bb1992b56d7d50065aaa21ce8697944c5cc275c8a44089f6549f50"
COMMIT = "1511f27194f1dcc3728270883047bdf022b3fd53"
SETTINGS = {
    "BATT_MONITOR": 4,
    "BATT_FS_VOLTSRC": 0,
    "BATT_LOW_VOLT": 21.600000381469727,
    "BATT_LOW_TIMER": 10,
    "BATT_LOW_MAH": 0,
    "BATT_CRT_VOLT": 21,
    "BATT_CRT_MAH": 0,
    "BATT_FS_LOW_ACT": 4,
}


def read_log(path):
    if sha256(path.read_bytes()).hexdigest() != SHA256:
        raise ValueError("DataFlash SHA-256 mismatch")
    log = DFReader_binary(str(path))
    result = defaultdict(list)
    while (message := log.recv_match(type=["PARM", "BAT", "ARM", "EV", "MSG", "MODE", "CTUN"])) is not None:
        result[message.get_type()].append(message.to_dict())
    return result


def audit(path):
    log = read_log(path)
    params = {key: [row for row in log["PARM"] if row["Name"] == key] for key in SETTINGS}
    arm_time = next(row["TimeUS"] for row in log["ARM"] if row["ArmState"] == 1)
    disarm_time = next(row["TimeUS"] for row in log["ARM"] if row["ArmState"] == 0)
    takeoff_time = next(row["TimeUS"] for row in log["EV"] if row["Id"] == 15)
    land_time = next(row["TimeUS"] for row in log["EV"] if row["Id"] == 18)
    if any(
        not rows or any(row["Value"] != SETTINGS[key] or row["TimeUS"] >= arm_time for row in rows)
        for key, rows in params.items()
    ):
        raise ValueError("Unexpected preflight configuration or parameter change")
    firmware = "ArduCopter V4.7.0 (1511f271)"
    if not any(row["Message"] == firmware for row in log["MSG"]):
        raise ValueError("Firmware identification is missing")
    if any(row["Inst"] != 0 for row in log["BAT"]):
        raise ValueError("Expected a single BAT instance")

    battery = log["BAT"]
    flight_voltage = [row for row in battery if arm_time <= row["TimeUS"] < disarm_time]
    if any(row["H"] != 1 or row["Volt"] <= SETTINGS["BATT_CRT_VOLT"] for row in flight_voltage):
        raise ValueError("Unhealthy or critical voltage reported")
    limit = SETTINGS["BATT_LOW_VOLT"]
    timer_ms = SETTINGS["BATT_LOW_TIMER"] * 1_000
    trip = next(row for row in log["MSG"] if row["Message"].startswith("Battery 1 is low"))
    change = next(row for row in log["MODE"] if row["Rsn"] == 4)

    def observation(index):
        row = battery[index]
        state = min(log["CTUN"], key=lambda obs: abs(obs["TimeUS"] - row["TimeUS"]))
        return {
            "bat_row": index + 1,
            "time_us": row["TimeUS"],
            "voltage_v": row["Volt"],
            "after_takeoff_before_land": takeoff_time <= row["TimeUS"] < land_time,
            "nearest_ctun_time_us": state["TimeUS"],
            "nearest_ctun_alt_m": state["Alt"],
        }

    episodes = []
    for below, rows in groupby(enumerate(battery), lambda item: 0 < item[1]["Volt"] < limit):
        if not below:
            continue
        low_rows = list(rows)
        start = low_rows[0][0]
        last = low_rows[-1][0]
        start_us = battery[start]["TimeUS"]
        first_past = next(
            (index for index, row in low_rows if row["TimeUS"] // 1000 - start_us // 1000 > timer_ms),
            None,
        )
        episodes.append(
            {
                "preceding": observation(start - 1),
                "trigger": observation(start),
                "last_below": observation(last),
                "return": observation(last + 1),
                "first_still_low_past_timer_on_logged_ms_clock": (
                    observation(first_past) if first_past is not None else None
                ),
                "return_elapsed_us": battery[last + 1]["TimeUS"] - start_us,
                "max_adjacent_gap_us": max(
                    battery[index + 1]["TimeUS"] - battery[index]["TimeUS"]
                    for index in range(start - 1, last + 1)
                ),
            }
        )
    if [episode["trigger"]["bat_row"] for episode in episodes] != [2007, 2012]:
        raise ValueError("Unexpected voltage episodes")
    if not episodes[0]["return"]["time_us"] < trip["TimeUS"] < land_time:
        raise ValueError("Unexpected failsafe timeline")
    return {
        "primary_flight_report": FLIGHT,
        "dataflash_url": DATAFLASH,
        "dataflash_sha256": SHA256,
        "firmware": firmware,
        "firmware_commit": COMMIT,
        "preflight_parameters": {key: rows[-1]["Value"] for key, rows in params.items()},
        "armed_us": arm_time,
        "takeoff_event_us": takeoff_time,
        "land_event_us": land_time,
        "disarmed_us": disarm_time,
        "battery_rows": len(battery),
        "low_battery_message": trip,
        "battery_failsafe_mode": change,
        "episodes": episodes,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataflash", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()
    args.output_json.write_text(json.dumps(audit(args.dataflash), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
