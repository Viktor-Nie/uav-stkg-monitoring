# External physical recovery replay

The research rule N09 is unchanged. These replays use version 2 of
https://doi.org/10.4121/0530be90-cc6c-4029-9774-670657882906.v2
(CC BY 4.0, Blaha, Smeur, and Remes). Download the authors' ZIP from that
record and pass its path as DATASET_ZIP. The source archive is checked against
the publisher's MD5. All inputs from this project used by the verifier are
included. The dataset itself is a separate download.

Use Python 3.11 or later with pandas. After extracting this companion, run

    python -B -X utf8 replay_delft_open_flight.py DATASET_ZIP . full.json
    python -B -X utf8 replay_delft_open_flight.py DATASET_ZIP . window.json --analysis-window

Compare each output to its corresponding delft_*_receipt.json. Both commands
verify the monitor against an integer-clock witness check. The physical logs
do not provide an independently issued N09 operating rule.


To reproduce the source-row attribution after those two commands, run

    python -B -X utf8 audit_delft_window.py DATASET_ZIP full.json window.json attribution.json

Compare attribution.json to delft_window_attribution.json. This checks each
member hash and classifies the full-record outcomes by trigger location.
