"""Replay an unchanged N09 research rule over published physical IROS logs."""
from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from hashlib import md5, sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import math
import sys

import pandas as pd


def digest(path, algorithm):
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            algorithm.update(block)
    return algorithm.hexdigest()


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("paper_source", type=Path, help="Unmodified v81 LaTeX source directory")
    parser.add_argument("output", type=Path)
    parser.add_argument("--analysis-window", action="store_true", help="Use the authors' 1.4 s sample-to-manual-takeover analysis window")
    args = parser.parse_args()
    archive_md5 = digest(args.archive, md5())
    assert archive_md5 == "4ce2a19780d6dc4511e1fe717cfd9ce8"

    research = args.paper_source.resolve() / "research"
    sys.path.insert(0, str(research))
    from monitor.sampled_monitor import (
        BoundedResponseSpecification, EventTimeObservationContract, monitor_bounded_response,
    )

    binding_path = research / "neo4j/data/frozen_formula_parameter_bindings.csv"
    all_bindings = pd.read_csv(binding_path, dtype=str)
    frozen = all_bindings.loc[all_bindings["formula_id"] == "N09"]
    assert set(frozen["signal_id"]) == {"ang_rate_norm_rps"}
    values = {row.role: float(row.value) for row in frozen.itertuples()}
    assert values["deadline_seconds"] == 2.0 and values["dwell_seconds"] == values["value_epsilon"] == 0.0
    specification = BoundedResponseSpecification("ang_rate_norm_rps", **values)
    contract = EventTimeObservationContract(maximum_observation_gap_seconds=0.01, timestamp_epsilon_seconds=0.0)

    files, examples = [], []
    with ZipFile(args.archive) as zip_file:
        names = [name for name in zip_file.namelist() if "/IROS2024_ExperimentData/" in name and name.endswith(".csv")]
        assert len(names) == 20
        members = set(zip_file.namelist())
        for name in sorted(names):
            raw = zip_file.read(name)
            components = [f"gyroADC[{i}]" for i in range(3)]
            frame = pd.read_csv(BytesIO(raw), usecols=["timeUs", "flightModeFlags", *components], dtype={"timeUs": str}, float_precision="round_trip")
            start, end = 0, len(frame) - 1
            if args.analysis_window:
                # The authors' Figure script uses the nearest sample to 1400 ms and
                # the first falling edge of mode bit 9 to delimit its min-height metric.
                ticks = list(map(int, frame["timeUs"]))
                start = min(range(len(ticks)), key=lambda i: abs(ticks[i] - 1_400_000))
                mask = 1 << 9
                flags = frame["flightModeFlags"].tolist()
                end = next(i for i, (a, b) in enumerate(zip(flags, flags[1:]), 1) if a & mask and not b & mask)
                assert end > start, name
                frame = frame.iloc[start:end + 1]
            times = list(map(int, frame["timeUs"]))
            gaps = [b - a for a, b in zip(times, times[1:])]
            assert min(gaps) > 0 and max(gaps) <= 10_000
            norms = [math.hypot(*xyz) for xyz in frame[components].itertuples(index=False, name=None)]
            assert all(map(math.isfinite, norms))
            trace = pd.DataFrame({"time_seconds": frame["timeUs"], "ang_rate_norm_rps": norms})
            result = monitor_bounded_response(trace, specification, contract, timestamp_scale_seconds="0.000001")
            expected = {}
            witness_indices = [i for i, value in enumerate(norms) if value <= specification.recovery_upper]
            for index, value in enumerate(norms):
                if value <= specification.trigger_upper:
                    continue
                witness_pos = bisect_right(witness_indices, index)
                witness = witness_indices[witness_pos] if witness_pos < len(witness_indices) else len(times)
                due = times[index] + 2_000_000
                first_after_due = bisect_right(times, due)
                if witness < first_after_due:
                    expected[index] = ("obligation_recovered", witness)
                elif first_after_due < len(times):
                    expected[index] = ("obligation_expired", first_after_due)
                else:
                    expected[index] = ("obligation_pending_at_end", len(times) - 1)
            triggers = [event for event in result.events if event.event_type == "obligation_triggered"]
            finals = [event for event in result.events if event.event_type != "obligation_triggered"]
            assert [event.observed_index for event in triggers] == list(expected), name
            assert len(finals) == len(expected), name
            assert {event.trigger_index: (event.event_type, event.observed_index) for event in finals} == expected, name
            counts = Counter(kind for kind, _ in expected.values())
            verdict = ("violated" if counts["obligation_expired"] else
                       "inconclusive_end_of_trace" if counts["obligation_pending_at_end"] else "satisfied")
            assert result.verdict.value == verdict, name
            files.append({"member": name, "member_sha256": sha256(raw).hexdigest(),
                          "paired_blackbox_member": name.removesuffix(".csv") + ".BFL" in members,
                          "rows": len(times), "first_source_csv_line": start + 2, "last_source_csv_line": end + 2,
                          "maximum_gap_us": max(gaps), "maximum_norm_rad_s": max(norms),
                          "verdict": verdict, "created_obligations": len(expected), "terminal_counts": dict(counts)})
            if expected:
                trigger = next(iter(expected))
                kind, observed = expected[trigger]
                examples.append({"member": name, "first_trigger_source_csv_line": start + trigger + 2,
                                 "first_trigger_us": times[trigger], "trigger_norm_rad_s": norms[trigger],
                                 "outcome": kind, "outcome_source_csv_line": start + observed + 2,
                                 "outcome_us": times[observed], "outcome_norm_rad_s": norms[observed],
                                 "elapsed_us": times[observed] - times[trigger]})
    summary = Counter()
    for file in files:
        summary.update(file["terminal_counts"])
    result = {
        "dataset_doi": "10.4121/0530be90-cc6c-4029-9774-670657882906.v2", "dataset_license": "CC BY 4.0",
        "archive_md5": archive_md5, "archive_sha256": digest(args.archive, sha256()),
        "input_scope": ("All released IROS2024_ExperimentData CSVs, nearest sample to 1.4 s through the manual-takeover row inclusive"
                        if args.analysis_window else "All released IROS2024_ExperimentData CSVs, full record spans, no flight-phase labels or cropping"),
        "scope": "External physical telemetry under the existing N09 research rule. The rule is not a Delft acceptance requirement.",
        "rule_id": "N09", "frozen_binding_csv_sha256": digest(binding_path, sha256()), "rule": values,
        "clock": "Integer microseconds from timeUs; all samples retained; no interpolation or hold",
        "signal": "Euclidean norm of the published gyroADC[0:3] values in rad/s",
        "maximum_admitted_gap_seconds": contract.maximum_observation_gap_seconds,
        "files": len(files), "rows": sum(file["rows"] for file in files),
        "file_verdicts": dict(Counter(file["verdict"] for file in files)),
        "files_with_triggers": len(examples), "created_obligations": sum(file["created_obligations"] for file in files),
        "terminal_counts": dict(summary), "file_details": files, "first_trigger_examples": examples,
    }
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("files", "rows", "file_verdicts", "files_with_triggers", "created_obligations", "terminal_counts")}, indent=2))


if __name__ == "__main__":
    main()
