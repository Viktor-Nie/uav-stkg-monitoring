"""Attribute the full-versus-window Delft replay differences to source rows."""

from argparse import ArgumentParser
from bisect import bisect_right
from collections import Counter
from hashlib import sha256
from io import StringIO
from pathlib import Path
from zipfile import ZipFile
import csv
import json
import math


RECOVERED = "obligation_recovered"
EXPIRED = "obligation_expired"
PENDING = "obligation_pending_at_end"


def terminal_counts(events):
    return Counter(kind for kind, _ in events.values())


def summarize(events):
    counts = terminal_counts(events)
    verdict = "satisfied"
    if counts[EXPIRED]:
        verdict = "violated"
    elif counts[PENDING]:
        verdict = "inconclusive_end_of_trace"
    return {"triggers": len(events), "outcomes": dict(sorted(counts.items())),
            "distinct_recovery_rows": len({row for kind, row in events.values() if kind == RECOVERED}),
            "verdict": verdict}


def read_records(raw):
    rows = csv.DictReader(StringIO(raw.decode("utf-8-sig"), newline=""), skipinitialspace=True)
    times, flags, norms = [], [], []
    axes = tuple(f"gyroADC[{axis}]" for axis in range(3))
    for row in rows:
        times.append(int(row["timeUs"]))
        flags.append(int(row["flightModeFlags"]))
        norms.append(math.hypot(*(float(row[axis]) for axis in axes)))
    assert all(0 < right - left <= 10_000 for left, right in zip(times, times[1:]))
    assert all(map(math.isfinite, norms))
    return times, flags, norms


def audit_member(raw, full, window, rule):
    assert sha256(raw).hexdigest() == full["member_sha256"] == window["member_sha256"]
    times, flags, norms = read_records(raw)
    last = len(times) - 1
    start = min(range(len(times)), key=lambda row: abs(times[row] - 1_400_000))
    end = next(row for row in range(1, len(flags)) if flags[row - 1] & 512 and not flags[row] & 512)
    assert 0 <= start < end <= last
    assert (full["first_source_csv_line"], full["last_source_csv_line"]) == (2, last + 2)
    assert (window["first_source_csv_line"], window["last_source_csv_line"]) == (start + 2, end + 2)

    trigger_upper = rule["trigger_upper"]
    recovery_upper = rule["recovery_upper"]
    deadline_us = int(rule["deadline_seconds"] * 1_000_000)
    full_events, through_end = {}, {}
    next_witness = len(times)
    for row in range(last, -1, -1):
        if norms[row] <= recovery_upper:
            next_witness = row
        if norms[row] <= trigger_upper:
            continue
        first_late = bisect_right(times, times[row] + deadline_us)
        if next_witness < first_late:
            event = RECOVERED, next_witness
        elif first_late <= last:
            event = EXPIRED, first_late
        else:
            event = PENDING, last
        full_events[row] = event
        if row <= end:
            through_end[row] = event if event[1] <= end else (PENDING, end)

    phases = {
        "before": {row: event for row, event in full_events.items() if row < start},
        "inside": {row: event for row, event in full_events.items() if start <= row <= end},
        "after": {row: event for row, event in full_events.items() if row > end},
    }
    intervals = {
        "full": full_events,
        "from_window_start": {row: event for row, event in full_events.items() if row >= start},
        "through_window_end": through_end,
        "analysis_window": {row: event for row, event in through_end.items() if row >= start},
    }
    assert set(intervals["analysis_window"]) == set(phases["inside"])
    for key, receipt in (("full", full), ("analysis_window", window)):
        summary = summarize(intervals[key])
        assert summary["outcomes"] == receipt["terminal_counts"]
        assert summary["triggers"] == receipt["created_obligations"]
        assert summary["verdict"] == receipt["verdict"]

    carried = {row: through_end[row] for row, event in phases["before"].items() if event[1] >= start}
    end_changes = Counter(f"{event[0]} -> {through_end[row][0]}" for row, event in full_events.items()
                          if row <= end and through_end[row][0] != event[0])
    return {
        "member": full["member"], "member_sha256": full["member_sha256"],
        "window_source_csv_lines": [start + 2, end + 2], "window_us": [times[start], times[end]],
        "full_outcomes_by_trigger_region": {key: summarize(events) for key, events in phases.items()},
        "intervals": {key: summarize(events) for key, events in intervals.items()},
        "retained_trigger_event_changes": sum(phases["inside"][row] != event
                                             for row, event in intervals["analysis_window"].items()),
        "retained_triggers_with_full_followup": sum(times[row] + deadline_us <= times[end] for row in phases["inside"]),
        "carried_into_window_at_start": summarize(carried),
        "outcomes_changed_by_end_cut": dict(sorted(end_changes.items())),
    }


def aggregate(parts):
    outcomes = Counter()
    for part in parts:
        outcomes.update(part["outcomes"])
    return {"triggers": sum(part["triggers"] for part in parts), "outcomes": dict(sorted(outcomes.items())),
            "distinct_recovery_rows": sum(part["distinct_recovery_rows"] for part in parts),
            "file_verdicts": dict(sorted(Counter(part["verdict"] for part in parts).items()))}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("archive", "full_receipt", "window_receipt", "output"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    full, window = (json.loads(path.read_text(encoding="utf-8"))
                    for path in (args.full_receipt, args.window_receipt))
    rule = full["rule"]
    assert full["rule_id"] == window["rule_id"] == "N09" and rule == window["rule"]
    assert rule["trigger_upper"] > rule["recovery_upper"]
    assert rule["deadline_seconds"] == 2.0 and rule["dwell_seconds"] == rule["value_epsilon"] == 0.0
    with args.archive.open("rb") as source:
        archive_hash = sha256()
        for block in iter(lambda: source.read(1 << 20), b""):
            archive_hash.update(block)
    assert archive_hash.hexdigest() == full["archive_sha256"] == window["archive_sha256"]
    by_name = {item["member"]: item for item in window["file_details"]}
    assert len(full["file_details"]) == len(by_name) == 20
    with ZipFile(args.archive) as archive:
        data = [audit_member(archive.read(item["member"]), item, by_name[item["member"]], rule)
                for item in full["file_details"]]
    assert len({item["member"] for item in data}) == len(data)
    ends = Counter()
    for item in data:
        ends.update(item["outcomes_changed_by_end_cut"])
    result = {
        "dataset_doi": full["dataset_doi"], "archive_sha256": archive_hash.hexdigest(), "rule": rule,
        "scope": "Observed source rows and unchanged research rule. File verdicts use the declared interval.",
        "files": len(data),
        "full_outcomes_by_trigger_region": {
            key: {field: value for field, value in aggregate(
                [item["full_outcomes_by_trigger_region"][key] for item in data]).items() if field != "file_verdicts"}
            for key in ("before", "inside", "after")},
        "intervals": {key: aggregate([item["intervals"][key] for item in data]) for key in data[0]["intervals"]},
        "retained_trigger_event_changes": sum(item["retained_trigger_event_changes"] for item in data),
        "retained_triggers_with_full_followup": sum(item["retained_triggers_with_full_followup"] for item in data),
        "carried_into_window_at_start": aggregate([item["carried_into_window_at_start"] for item in data]),
        "outcomes_changed_by_end_cut": dict(sorted(ends.items())), "file_details": data,
    }
    assert result["intervals"]["full"]["outcomes"] == full["terminal_counts"]
    assert result["intervals"]["analysis_window"]["outcomes"] == window["terminal_counts"]
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "file_details"}, indent=2))


if __name__ == "__main__":
    main()
